/* ==========================================================================
   MineCommand Studio - Generator Compiler
   ========================================================================= */

const Generator = {
    // Utility: Parse formatting codes § into raw text, or escape JSON
    escapeString(str) {
        if (!str) return "";
        return str.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    },

    parseSummonCommand(cmd) {
        if (!cmd) return null;
        let clean = cmd.trim();
        if (clean.startsWith("/")) clean = clean.substring(1);
        const match = clean.match(/^summon\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)(?:\s+(.*))?$/s);
        if (!match) {
            const fallback = clean.match(/^summon\s+([^\s]+)(?:\s+(.*))?$/s);
            if (fallback) {
                return {
                    id: fallback[1],
                    nbt: fallback[2] ? fallback[2].trim() : ""
                };
            }
            return null;
        }
        return {
            id: match[1],
            nbt: match[5] ? match[5].trim() : ""
        };
    },

    // Convert Minecraft color codes (e.g., §cText) into simple JSON components for display
    textToJsonComponent(str) {
        if (!str) return '""';
        // If it starts with §, parse colors
        if (str.includes("§")) {
            let parts = [];
            let currentText = "";
            let currentColor = "white";
            let bold = false;
            let italic = false;

            const colorMap = {
                '0': 'black', '1': 'dark_blue', '2': 'dark_green', '3': 'dark_aqua',
                '4': 'dark_red', '5': 'dark_purple', '6': 'gold', '7': 'gray',
                '8': 'dark_gray', '9': 'blue', 'a': 'green', 'b': 'aqua',
                'c': 'red', 'd': 'light_purple', 'e': 'yellow', 'f': 'white'
            };

            for (let i = 0; i < str.length; i++) {
                if (str[i] === '§' && i + 1 < str.length) {
                    if (currentText) {
                        parts.push({ text: currentText, color: currentColor, bold, italic });
                        currentText = "";
                    }
                    const code = str[i + 1].toLowerCase();
                    if (colorMap[code]) {
                        currentColor = colorMap[code];
                        bold = false;
                        italic = false;
                    } else if (code === 'l') {
                        bold = true;
                    } else if (code === 'o') {
                        italic = true;
                    } else if (code === 'r') {
                        currentColor = "white";
                        bold = false;
                        italic = false;
                    }
                    i++; // skip code char
                } else {
                    currentText += str[i];
                }
            }
            if (currentText) {
                parts.push({ text: currentText, color: currentColor, bold, italic });
            }
            return JSON.stringify(parts.length === 1 ? parts[0] : parts);
        }

        return JSON.stringify({ text: str, italic: false });
    },

    // 1. GENERATE CUSTOM ITEM COMMAND (/give)
    generateItem(config, version) {
        const itemId = config.id || "minecraft:diamond_sword";
        const customName = config.name ? config.name.trim() : "";
        const loreLines = config.lore ? config.lore.split("\n").filter(l => l.trim() !== "") : [];
        const isUnbreakable = !!config.unbreakable;
        const hideFlags = !!config.hideFlags;
        const isGlint = !!config.glint;
        const count = parseInt(config.count) || 1;
        const enchantments = config.enchantments || []; // Array of {id, lvl}
        const attributes = config.attributes || {}; // Object: attack_damage, etc.

        // --- MODERN JAVA (1.20.5+) ---
        if (version === "java_modern") {
            let components = [];

            // Custom Name
            if (customName) {
                components.push(`minecraft:custom_name='${this.textToJsonComponent(customName)}'`);
            }

            // Lore
            if (loreLines.length > 0) {
                const jsonLines = loreLines.map(l => `'${this.textToJsonComponent(l)}'`);
                components.push(`minecraft:lore=[${jsonLines.join(",")}]`);
            }

            // Unbreakable
            if (isUnbreakable) {
                components.push(hideFlags ? "minecraft:unbreakable={show_in_tooltip:false}" : "minecraft:unbreakable={}");
            }

            // Glint Override
            if (isGlint) {
                components.push("minecraft:enchantment_glint_override=true");
            }

            // Enchantments
            if (enchantments.length > 0) {
                let levelsObj = [];
                enchantments.forEach(e => {
                    levelsObj.push(`"minecraft:${e.id}":${e.lvl}`);
                });
                components.push(hideFlags 
                    ? `minecraft:enchantments={levels:{${levelsObj.join(",")}},show_in_tooltip:false}`
                    : `minecraft:enchantments={levels:{${levelsObj.join(",")}}}`
                );
            }

            // Attributes
            let attrModifiers = [];
            if (attributes.attack_damage > 0) {
                attrModifiers.push(`{type:"minecraft:generic.attack_damage",amount:${attributes.attack_damage},operation:"add_value",id:"custom_atk",slot:"any"}`);
            }
            if (attributes.attack_speed !== undefined && attributes.attack_speed !== 0) {
                attrModifiers.push(`{type:"minecraft:generic.attack_speed",amount:${attributes.attack_speed},operation:"add_value",id:"custom_speed",slot:"any"}`);
            }
            if (attributes.max_health > 0) {
                attrModifiers.push(`{type:"minecraft:generic.max_health",amount:${attributes.max_health},operation:"add_value",id:"custom_health",slot:"any"}`);
            }
            if (attributes.knockback_resistance > 0) {
                attrModifiers.push(`{type:"minecraft:generic.knockback_resistance",amount:${attributes.knockback_resistance},operation:"add_value",id:"custom_kb",slot:"any"}`);
            }
            if (attributes.movement_speed > 0) {
                attrModifiers.push(`{type:"minecraft:generic.movement_speed",amount:${attributes.movement_speed},operation:"add_value",id:"custom_mv",slot:"any"}`);
            }

            if (attrModifiers.length > 0) {
                components.push(hideFlags
                    ? `minecraft:attribute_modifiers={modifiers:[${attrModifiers.join(",")}],show_in_tooltip:false}`
                    : `minecraft:attribute_modifiers={modifiers:[${attrModifiers.join(",")}]}`
                );
            }

            // Container presets compilation
            if (config.containerConfig) {
                const cConf = config.containerConfig;
                if (cConf.lootTable && cConf.lootTable !== "none") {
                    components.push(`minecraft:container_loot={loot_table:"${cConf.lootTable}"}`);
                } else if (cConf.contents) {
                    let slotItems = [];
                    for (const [slotStr, item] of Object.entries(cConf.contents)) {
                        const slot = parseInt(slotStr);
                        const id = item.id || "minecraft:stone";
                        const count = item.count || 1;

                        if (item.isPreset && item.command) {
                            const parsed = this.parseGiveCommand(item.command);
                            let itemComps = parsed.components.map(c => {
                                const eqIdx = c.indexOf("=");
                                if (eqIdx !== -1) {
                                    return c.substring(0, eqIdx) + ":" + c.substring(eqIdx + 1);
                                }
                                return c;
                            });
                            if (parsed.tag && parsed.tag.includes("EntityTag:")) {
                                const match = parsed.tag.match(/EntityTag:\s*(\{.*\})/s);
                                if (match) {
                                    itemComps.push(`"minecraft:entity_data":${match[1]}`);
                                }
                            } else if (parsed.tag && parsed.tag !== "{}") {
                                itemComps.push(`"minecraft:custom_data":${parsed.tag}`);
                            }
                            const compStr = itemComps.length > 0 ? `,components:{${itemComps.join(",")}}` : "";
                            slotItems.push(`{slot:${slot},item:{id:"${parsed.id}",count:${count}${compStr}}}`);
                        } else {
                            slotItems.push(`{slot:${slot},item:{id:"${id}",count:${count}}}`);
                        }
                    }
                    if (slotItems.length > 0) {
                        components.push(`minecraft:container=[${slotItems.join(",")}]`);
                    }
                }
            }

            const compString = components.length > 0 ? `[${components.join(",")}]` : "";
            return `/give @p ${itemId}${compString} ${count}`;
        }

        // --- LEGACY JAVA (1.16 - 1.20.4) ---
        if (version === "java_legacy") {
            let nbtTags = [];
            let displayTags = [];

            // Custom Name
            if (customName) {
                displayTags.push(`Name:'${this.textToJsonComponent(customName)}'`);
            }

            // Lore
            if (loreLines.length > 0) {
                const jsonLines = loreLines.map(l => `'${this.textToJsonComponent(l)}'`);
                displayTags.push(`Lore:[${jsonLines.join(",")}]`);
            }

            if (displayTags.length > 0) {
                nbtTags.push(`display:{${displayTags.join(",")}}`);
            }

            // Unbreakable
            if (isUnbreakable) {
                nbtTags.push("Unbreakable:1b");
            }

            // Glint / Force Glow
            if (isGlint && enchantments.length === 0) {
                nbtTags.push("Enchantments:[{}]");
            }

            // Enchantments
            if (enchantments.length > 0) {
                const enchList = enchantments.map(e => `{id:"minecraft:${e.id}",lvl:${e.lvl}s}`);
                nbtTags.push(`Enchantments:[${enchList.join(",")}]`);
            }

            // Attributes
            let attrList = [];
            if (attributes.attack_damage > 0) {
                attrList.push(`{AttributeName:"generic.attack_damage",Name:"custom_atk",Amount:${attributes.attack_damage},Operation:0,UUID:[I;1,2,3,4]}`);
            }
            if (attributes.attack_speed !== undefined && attributes.attack_speed !== 0) {
                attrList.push(`{AttributeName:"generic.attack_speed",Name:"custom_spd",Amount:${attributes.attack_speed},Operation:0,UUID:[I;5,6,7,8]}`);
            }
            if (attributes.max_health > 0) {
                attrList.push(`{AttributeName:"generic.max_health",Name:"custom_hp",Amount:${attributes.max_health},Operation:0,UUID:[I;9,10,11,12]}`);
            }
            if (attributes.knockback_resistance > 0) {
                attrList.push(`{AttributeName:"generic.knockback_resistance",Name:"custom_kb",Amount:${attributes.knockback_resistance},Operation:0,UUID:[I;13,14,15,16]}`);
            }
            if (attributes.movement_speed > 0) {
                attrList.push(`{AttributeName:"generic.movement_speed",Name:"custom_mv",Amount:${attributes.movement_speed},Operation:0,UUID:[I;17,18,19,20]}`);
            }

            if (attrList.length > 0) {
                nbtTags.push(`AttributeModifiers:[${attrList.join(",")}]`);
            }

            // Hide Flags bitmask
            if (hideFlags) {
                // 1=Enchants, 2=Modifiers, 4=Unbreakable, etc. Set to 127 to hide everything
                nbtTags.push("HideFlags:127");
            }

            // Container presets compilation (Legacy NBT)
            if (config.containerConfig) {
                const cConf = config.containerConfig;
                if (cConf.lootTable && cConf.lootTable !== "none") {
                    nbtTags.push(`BlockEntityTag:{LootTable:"${cConf.lootTable}"}`);
                } else if (cConf.contents) {
                    let slotItems = [];
                    for (const [slotStr, item] of Object.entries(cConf.contents)) {
                        const slot = parseInt(slotStr);
                        const id = item.id || "minecraft:stone";
                        const count = item.count || 1;
                        if (item.isPreset && item.command) {
                            const parsed = this.parseGiveCommand(item.command);
                            let tagPart = parsed.tag && parsed.tag !== "{}" ? `,tag:${parsed.tag}` : "";
                            slotItems.push(`{Slot:${slot}b,id:"${parsed.id}",Count:${count}b${tagPart}}`);
                        } else {
                            slotItems.push(`{Slot:${slot}b,id:"${id}",Count:${count}b}`);
                        }
                    }
                    if (slotItems.length > 0) {
                        nbtTags.push(`BlockEntityTag:{Items:[${slotItems.join(",")}]}`);
                    }
                }
            }

            const nbtString = nbtTags.length > 0 ? `{${nbtTags.join(",")}}` : "";
            return `/give @p ${itemId}${nbtString} ${count}`;
        }

        // --- BEDROCK EDITION ---
        if (version === "bedrock") {
            // Bedrock `/give` does not support inline NBT tags directly.
            // We output a clean `/give` command followed by `/enchant` calls for convenience.
            let commands = [];
            
            if (config.containerConfig) {
                commands.push("# Note: Bedrock Edition does not support custom container contents in the /give command directly. Use the setblock / custom container tab if you want to place containers with loot.");
            }

            commands.push(`/give @p ${itemId.replace("minecraft:", "")} ${count}`);
            
            if (enchantments.length > 0) {
                commands.push("# Apply Enchantments (Run while holding item):");
                enchantments.forEach(e => {
                    commands.push(`/enchant @p ${e.id} ${e.lvl}`);
                });
            }

            if (customName || isUnbreakable || loreLines.length > 0 || isGlint) {
                commands.push("\n# NOTE: Custom Name, Lore, Unbreakable NBTs require Anvils or external Loot Tables in Bedrock!");
            }
            
            return commands.join("\n");
        }

        return "";
    },

    // Auxiliary compiler for items in equipment slots
    compileEquipItem(itemId, enchants, version) {
        if (itemId === "none") return null;

        let parsedId = itemId;
        let parsed = null;

        // Check if itemId is actually a command (starts with / or give or setblock)
        if (itemId.startsWith("/") || itemId.startsWith("give") || itemId.startsWith("setblock")) {
            parsed = this.parseGiveCommand(itemId);
            parsedId = parsed.id;
        }

        const actualEnchants = Array.isArray(enchants) 
            ? enchants 
            : (enchants ? [{ id: "protection", lvl: 3 }] : []);

        if (version === "java_modern") {
            let comps = [];
            if (parsed && parsed.components && parsed.components.length > 0) {
                comps = [...parsed.components];
            }
            if (parsed && parsed.tag && parsed.tag.includes("EntityTag:")) {
                const match = parsed.tag.match(/EntityTag:\s*(\{.*\})/s);
                if (match) {
                    comps.push(`minecraft:entity_data=${match[1]}`);
                }
            } else if (parsed && parsed.tag && parsed.tag !== "{}") {
                comps.push(`minecraft:custom_data=${parsed.tag}`);
            }

            if (actualEnchants.length > 0) {
                comps = comps.filter(c => !c.startsWith("minecraft:enchantments"));
                let levelsObj = [];
                actualEnchants.forEach(e => {
                    levelsObj.push(`"minecraft:${e.id}":${e.lvl}`);
                });
                comps.push(`minecraft:enchantments={levels:{${levelsObj.join(",")}}}`);
            }
            return `{id:"${parsedId}",count:1${comps.length > 0 ? `,components:{${comps.join(",")}}` : ""}}`;
        } else {
            // Java Legacy
            let tagStr = "";
            if (parsed && parsed.tag) {
                tagStr = parsed.tag;
            } else if (parsed && parsed.components && parsed.components.length > 0) {
                const entityDataComp = parsed.components.find(c => c.includes("entity_data="));
                if (entityDataComp) {
                    const eqIdx = entityDataComp.indexOf("=");
                    const val = entityDataComp.substring(eqIdx + 1);
                    tagStr = `{EntityTag:${val}}`;
                }
            }

            if (actualEnchants.length > 0) {
                const enchList = actualEnchants.map(e => `{id:"minecraft:${e.id}",lvl:${e.lvl}s}`);
                const enchNbt = `Enchantments:[${enchList.join(",")}]`;
                if (!tagStr) {
                    tagStr = `{${enchNbt}}`;
                } else {
                    tagStr = `{${enchNbt},${tagStr.substring(1)}`;
                }
            }

            let tagPart = tagStr ? `,tag:${tagStr}` : "";
            return `{id:"${parsedId}",Count:1b${tagPart}}`;
        }
    },

    // 2. GENERATE CUSTOM MOB SUMMON (/summon)
    generateMob(config, version) {
        const mobType = config.type || "minecraft:zombie";
        const customName = config.name ? config.name.trim() : "";
        const maxHealth = parseInt(config.health) || 20;
        const movementSpeed = parseFloat(config.speed) || 1.0;
        const isSilent = !!config.silent;
        const noAI = !!config.noAI;
        const isGlowing = !!config.glowing;
        const isInvulnerable = !!config.invulnerable;
        const noGravity = !!config.noGravity;
        const fireImmune = !!config.fireImmune;
        const activeEffects = config.activeEffects || [];

        // Gear slots
        const gear = config.gear || { hand: "none", offhand: "none", head: "none", chest: "none", legs: "none", feet: "none" };
        const gearEnch = config.gearEnch || {}; // hand, offhand, head, chest, legs, feet: boolean

        // Specials
        const specials = config.specials || {};

        // --- BEDROCK ---
        if (version === "bedrock") {
            const rawName = customName ? `"${this.escapeString(customName)}"` : "";
            let spawnEvent = "";
            if (config.isBaby) {
                const animals = ["cow", "sheep", "pig", "chicken", "wolf", "cat", "ocelot", "fox", "polar_bear", "horse", "donkey", "mule", "llama", "trader_llama", "panda", "goat", "sniffer", "camel", "rabbit", "turtle", "frog", "bee", "axolotl", "strider", "hoglin", "mooshroom"];
                const baseType = mobType.replace("minecraft:", "");
                const isAnimal = animals.includes(baseType);
                spawnEvent = isAnimal ? "minecraft:entity_born" : "minecraft:as_baby";
            }
            
            let baseCmd = "";
            if (spawnEvent) {
                baseCmd = `/summon ${mobType.replace("minecraft:", "")} ~ ~ ~ ~ ~ ${spawnEvent}${rawName ? " " + rawName : ""}`;
            } else {
                baseCmd = `/summon ${mobType.replace("minecraft:", "")} ~ ~ ~ ${rawName}`;
            }

            if (activeEffects.length > 0) {
                const effectCmds = activeEffects.map(eff => {
                    const cleanId = eff.id.replace("minecraft:", "");
                    const ampVal = Math.max(0, Math.min(255, (parseInt(eff.amplifier) || 1) - 1));
                    const durationVal = eff.infinite ? 99999 : (eff.duration || 60);
                    const targetSelector = customName 
                        ? `@e[type=${mobType.replace("minecraft:", "")},name="${this.escapeString(customName)}",c=1]`
                        : `@e[type=${mobType.replace("minecraft:", "")},c=1]`;
                    const hideP = eff.hideParticles ? " true" : "";
                    return `/effect ${targetSelector} ${cleanId} ${durationVal} ${ampVal}${hideP}`;
                });
                baseCmd = [baseCmd].concat(effectCmds).join("\n");
            }
            if (config.mountType && config.mountType !== "none") {
                baseCmd = `# Note: Bedrock Edition does not support entity mounting/passengers in the /summon command.\n` + baseCmd;
            }
            return baseCmd;
        }

        // --- JAVA (Legacy & Modern share summon base NBT, but equipment items differ) ---
        let nbt = [];

        // Base tags
        if (customName) {
            nbt.push(`CustomName:'${this.textToJsonComponent(customName)}'`);
            nbt.push("CustomNameVisible:1b");
        }
        if (isSilent) nbt.push("Silent:1b");
        if (noAI) nbt.push("NoAI:1b");
        if (isGlowing) nbt.push("Glowing:1b");
        if (isInvulnerable) nbt.push("Invulnerable:1b");
        if (noGravity) nbt.push("NoGravity:1b");
        if (fireImmune) nbt.push("FireImmune:1b");
        if (config.isBaby) {
            nbt.push("IsBaby:1b");
            nbt.push("Age:-24000");
        }

        // HP and Attributes
        let attributesList = [];
        if (maxHealth !== 20) {
            nbt.push(`Health:${maxHealth}.0f`);
            const hpAttr = version === "java_modern" ? "minecraft:generic.max_health" : "generic.max_health";
            attributesList.push(`{Name:"${hpAttr}",Base:${maxHealth}.0f}`);
        }
        if (movementSpeed !== 1.0) {
            const speedVal = 0.23 * movementSpeed; // 0.23 is average default speed
            const speedAttr = version === "java_modern" ? "minecraft:generic.movement_speed" : "generic.movement_speed";
            attributesList.push(`{Name:"${speedAttr}",Base:${speedVal.toFixed(3)}f}`);
        }
        if (version === "java_modern") {
            const scale = parseFloat(config.scale);
            const stepHeight = parseFloat(config.stepHeight);
            if (!isNaN(scale) && scale !== 1.0) {
                attributesList.push(`{Name:"minecraft:generic.scale",Base:${scale}f}`);
            }
            if (!isNaN(stepHeight) && stepHeight !== 0.6) {
                attributesList.push(`{Name:"minecraft:generic.step_height",Base:${stepHeight}f}`);
            }
        }

        if (attributesList.length > 0) {
            nbt.push(`Attributes:[${attributesList.join(",")}]`);
        }

        // Active Potion Effects
        let effectsList = [];
        if (version === "java_modern") {
            activeEffects.forEach(eff => {
                const ampVal = Math.max(0, Math.min(255, (parseInt(eff.amplifier) || 1) - 1));
                const showParticles = (eff.hideParticles || eff.id === "minecraft:invisibility") ? "0b" : "1b";
                const durVal = eff.infinite ? -1 : (parseInt(eff.duration) || 60) * 20;
                effectsList.push(`{id:"${eff.id}",amplifier:${ampVal},duration:${durVal},show_particles:${showParticles}}`);
            });
            if (effectsList.length > 0) {
                nbt.push(`active_effects:[${effectsList.join(",")}]`);
            }
        } else {
            // Java Legacy
            const effectsDb = (typeof MC_DATA !== "undefined" && MC_DATA.effects) || [];
            activeEffects.forEach(eff => {
                const ampVal = Math.max(0, Math.min(255, (parseInt(eff.amplifier) || 1) - 1));
                const dbEff = effectsDb.find(e => e.id === eff.id);
                const numId = dbEff ? dbEff.numeric_id : 1;
                const showParticles = (eff.hideParticles || eff.id === "minecraft:invisibility") ? ",ShowParticles:0b" : "";
                const durVal = eff.infinite ? 199999 : (parseInt(eff.duration) || 60) * 20;
                effectsList.push(`{Id:${numId}b,Amplifier:${ampVal}b,Duration:${durVal}${showParticles}}`);
            });
            if (effectsList.length > 0) {
                nbt.push(`ActiveEffects:[${effectsList.join(",")}]`);
            }
        }

        // Equipment Lists (ArmorItems & HandItems)
        const compiledHead = this.compileEquipItem(gear.head, gearEnch.head, version);
        const compiledChest = this.compileEquipItem(gear.chest, gearEnch.chest, version);
        const compiledLegs = this.compileEquipItem(gear.legs, gearEnch.legs, version);
        const compiledFeet = this.compileEquipItem(gear.feet, gearEnch.feet, version);
        const compiledHand = this.compileEquipItem(gear.hand, gearEnch.hand, version);
        const compiledOffhand = this.compileEquipItem(gear.offhand, gearEnch.offhand, version);

        if (compiledHead || compiledChest || compiledLegs || compiledFeet) {
            const boots = compiledFeet || "{}";
            const legs = compiledLegs || "{}";
            const chest = compiledChest || "{}";
            const head = compiledHead || "{}";
            nbt.push(`ArmorItems:[${boots},${legs},${chest},${head}]`);
        }

        if (compiledHand || compiledOffhand) {
            const hand = compiledHand || "{}";
            const offhand = compiledOffhand || "{}";
            nbt.push(`HandItems:[${hand},${offhand}]`);
        }

        // Special Entities properties
        if (mobType === "minecraft:creeper") {
            if (specials.creeperPowered) nbt.push("powered:1b");
            if (specials.creeperRadius && specials.creeperRadius !== 3) nbt.push(`ExplosionRadius:${specials.creeperRadius}b`);
            if (specials.creeperFuse && specials.creeperFuse !== 30) nbt.push(`Fuse:${specials.creeperFuse}s`);
        } else if (mobType === "minecraft:slime") {
            if (specials.slimeSize && specials.slimeSize !== 1) nbt.push(`Size:${specials.slimeSize}`);
        } else if (mobType === "minecraft:villager") {
            if (specials.villagerProfession && specials.villagerProfession !== "none") {
                nbt.push(`VillagerData:{profession:"minecraft:${specials.villagerProfession}",level:1,type:"minecraft:plains"}`);
            }
        }

        // Passenger / Rider Mount Assembly (Java only)
        if (config.mountType && config.mountType !== "none") {
            const activePassengerNBT = `{id:"${mobType}"${nbt.length > 0 ? "," + nbt.join(",") : ""}}`;

            if (config.mountType === "default") {
                const mountMob = config.mountMob || "minecraft:chicken";
                let mountNBTs = [];
                if (config.mountIsBaby) {
                    mountNBTs.push("IsBaby:1b");
                    mountNBTs.push("Age:-24000");
                }
                mountNBTs.push(`Passengers:[${activePassengerNBT}]`);
                return `/summon ${mountMob} ~ ~ ~ {${mountNBTs.join(",")}}`;
            } else if (config.mountType === "preset") {
                const presetCmd = config.mountPresetCmd;
                const parsed = this.parseSummonCommand(presetCmd);
                if (parsed) {
                    const mountId = parsed.id;
                    const mountNbtStr = parsed.nbt;
                    
                    let finalNbt = "";
                    if (mountNbtStr && mountNbtStr.includes("Passengers:[{")) {
                        const index = mountNbtStr.lastIndexOf("Passengers:[{");
                        const insertPos = index + "Passengers:[{".length;
                        finalNbt = mountNbtStr.substring(0, insertPos) + `Passengers:[${activePassengerNBT}], ` + mountNbtStr.substring(insertPos);
                    } else {
                        if (mountNbtStr) {
                            const trimmed = mountNbtStr.trim();
                            if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
                                const inner = trimmed.substring(1, trimmed.length - 1).trim();
                                if (inner) {
                                    finalNbt = `{${inner},Passengers:[${activePassengerNBT}]}`;
                                } else {
                                    finalNbt = `{Passengers:[${activePassengerNBT}]}`;
                                }
                            } else {
                                finalNbt = `{${trimmed},Passengers:[${activePassengerNBT}]}`;
                            }
                        } else {
                            finalNbt = `{Passengers:[${activePassengerNBT}]}`;
                        }
                    }
                    return `/summon ${mountId} ~ ~ ~ ${finalNbt}`;
                } else {
                    const fallbackMount = "minecraft:pig";
                    return `/summon ${fallbackMount} ~ ~ ~ {Passengers:[${activePassengerNBT}]}`;
                }
            }
        }

        const nbtString = nbt.length > 0 ? ` {${nbt.join(",")}}` : "";
        return `/summon ${mobType} ~ ~ ~${nbtString}`;
    },

    // 3. GENERATE TROLL MENU COMMANDS
    generateTroll(trollId, targetPlayer, version) {
        const target = targetPlayer ? targetPlayer.trim() : "@p";
        const trollObj = MC_DATA.trolls.find(t => t.id === trollId);
        
        if (!trollObj) return "# Troll Prank not found.";

        let commandTemplate = trollObj.java_modern;
        if (version === "java_legacy") {
            commandTemplate = trollObj.java_legacy;
        } else if (version === "bedrock") {
            commandTemplate = trollObj.bedrock;
        }

        // Multiple commands can be split by newline
        let generated = commandTemplate.replace(/\[TARGET\]/g, target);

        return generated;
    },

    // 4. GENERATE CUSTOM EXECUTE TROLL COMMANDS
    translateSoundToBedrock(soundId) {
        const mapping = {
            "minecraft:entity.creeper.primed": "random.fuse",
            "minecraft:ambient.cave": "ambient.cave",
            "minecraft:block.anvil.land": "random.anvil_land",
            "minecraft:entity.ghast.warn": "mob.ghast.charge",
            "minecraft:entity.lightning_bolt.thunder": "ambient.weather.thunder",
            "minecraft:entity.ender_dragon.death": "mob.enderdragon.death",
            "minecraft:entity.warden.heartbeat": "mob.warden.heartbeat",
            "minecraft:entity.phantom.swoop": "mob.phantom.swoop",
            "minecraft:entity.witch.ambient": "mob.witch.say"
        };
        return mapping[soundId] || "random.click";
    },

    translateParticleToBedrock(particleId) {
        const mapping = {
            "minecraft:portal": "minecraft:portal_particle",
            "minecraft:smoke": "minecraft:basic_smoke_particle",
            "minecraft:flame": "minecraft:basic_flame_particle",
            "minecraft:cloud": "minecraft:cloud_particle",
            "minecraft:sonic_boom": "minecraft:sonic_explosion",
            "minecraft:explosion": "minecraft:huge_explosion_emitter",
            "minecraft:heart": "minecraft:heart_particle",
            "minecraft:electric_spark": "minecraft:sparkler_emitter"
        };
        return mapping[particleId] || "minecraft:portal_particle";
    },

    translateEffectToBedrock(effectId) {
        const clean = effectId.replace("minecraft:", "");
        return clean; // Bedrock matches standard effect names like blindness, slowness, etc.
    },

    colorCodeBedrock(color) {
        const mapping = {
            "white": "§f",
            "red": "§c",
            "yellow": "§e",
            "green": "§a",
            "blue": "§9",
            "purple": "§d",
            "gold": "§6",
            "dark_red": "§4",
            "gray": "§7"
        };
        return mapping[color] || "";
    },

    parseRangeForSelector(rangeStr, isBedrock) {
        const clean = (rangeStr || "").trim();
        if (!clean) return isBedrock ? "r=5" : "distance=..5";
        
        // Match min..max
        const matchMinMax = clean.match(/^(\d+)\.\.(\d+)$/);
        if (matchMinMax) {
            const min = matchMinMax[1];
            const max = matchMinMax[2];
            return isBedrock ? `rm=${min},r=${max}` : `distance=${min}..${max}`;
        }
        
        // Match ..max
        const matchMax = clean.match(/^\.\.(\d+)$/);
        if (matchMax) {
            const max = matchMax[1];
            return isBedrock ? `r=${max}` : `distance=..${max}`;
        }

        // Match min..
        const matchMin = clean.match(/^(\d+)\.\.$/);
        if (matchMin) {
            const min = matchMin[1];
            return isBedrock ? `rm=${min}` : `distance=${min}..`;
        }

        // Simple number
        const matchNum = clean.match(/^(\d+)$/);
        if (matchNum) {
            const num = matchNum[1];
            return isBedrock ? `r=${num}` : `distance=${num}`;
        }

        return isBedrock ? `r=${clean}` : `distance=${clean}`;
    },

    compileSelector(config, version) {
        let base = config.targetBase || "@a";
        let filters = [];

        if (base === "custom_mob") {
            base = "@e";
            if (config.targetCustomMobType) {
                const cleanType = version === "bedrock" ? config.targetCustomMobType.replace("minecraft:", "") : config.targetCustomMobType;
                filters.push(`type=${cleanType}`);
            }
            if (config.targetCustomMobName) {
                filters.push(`name="${config.targetCustomMobName}"`);
            }
        }

        // Exclude name
        if (config.targetExclude) {
            filters.push(`name=!${config.targetExclude.trim()}`);
        }

        // Gamemode
        if (config.targetGamemode && config.targetGamemode !== "none") {
            if (version === "bedrock") {
                const gmMap = { "survival": "s", "creative": "c", "adventure": "a", "spectator": "sp" };
                const bedrockGm = gmMap[config.targetGamemode] || "s";
                filters.push(`m=${bedrockGm}`);
            } else {
                filters.push(`gamemode=${config.targetGamemode}`);
            }
        }

        // Survival/Adventure Only
        if (config.targetSurvivalOnly) {
            if (version === "bedrock") {
                filters.push("m=!c");
                filters.push("m=!sp");
            } else {
                filters.push("gamemode=!creative");
                filters.push("gamemode=!spectator");
            }
        }

        // Tag
        if (config.targetTag) {
            filters.push(`tag=${config.targetTag.trim()}`);
        }

        // Target Limit
        if (config.targetLimit) {
            if (version === "bedrock") {
                filters.push("c=1");
            } else {
                filters.push("limit=1");
            }
        }

        // XP Level Range
        const hasMin = config.targetLevelMin !== undefined && !isNaN(config.targetLevelMin);
        const hasMax = config.targetLevelMax !== undefined && !isNaN(config.targetLevelMax);
        if (hasMin || hasMax) {
            if (version === "bedrock") {
                if (hasMin) filters.push(`lm=${config.targetLevelMin}`);
                if (hasMax) filters.push(`l=${config.targetLevelMax}`);
            } else {
                const minVal = hasMin ? config.targetLevelMin : "";
                const maxVal = hasMax ? config.targetLevelMax : "";
                filters.push(`level=${minVal}..${maxVal}`);
            }
        }

        // Bedrock location mapping for hasitem condition
        const slotMap = {
            "weapon.mainhand": "slot.weapon.mainhand",
            "weapon.offhand": "slot.weapon.offhand",
            "armor.head": "slot.armor.head",
            "armor.chest": "slot.armor.chest",
            "armor.legs": "slot.armor.legs",
            "armor.feet": "slot.armor.feet"
        };

        if (version === "bedrock" && config.condType === "if_items") {
            const itemRaw = (config.invItem || "minecraft:diamond_sword").replace("minecraft:", "");
            const slotRaw = slotMap[config.invSlot] || "slot.weapon.mainhand";
            const countVal = config.invCount !== undefined ? config.invCount : 1;
            filters.push(`hasitem={item=${itemRaw},location=${slotRaw},quantity=${countVal}..}`);
        }

        return filters.length > 0 ? `${base}[${filters.join(",")}]` : base;
    },

    generateExecute(config, version) {
        // --- 1. COMPILE SELECTOR ---
        const selector = this.compileSelector(config, version);

        // --- 2. COMPILE EXECUTE ANCHOR PREAMBLE ---
        let preamble = "";
        if (version === "bedrock") {
            // Bedrock supports modern execute since 1.19.50+
            if (config.anchor === "at") {
                preamble = `execute at ${selector}`;
            } else if (config.anchor === "as") {
                preamble = `execute as ${selector}`;
            } else if (config.anchor === "as_at") {
                preamble = `execute as ${selector} at @s`;
            }
        } else {
            // Java Modern & Legacy execute
            if (config.anchor === "at") {
                preamble = `execute at ${selector}`;
            } else if (config.anchor === "as") {
                preamble = `execute as ${selector}`;
            } else if (config.anchor === "as_at") {
                preamble = `execute as ${selector} at @s`;
            }
        }

        // --- 3. COMPILE CONDITIONAL CLAUSE ---
        let condition = "";
        const cType = config.condType || "always";

        if (cType === "if_block" || cType === "unless_block") {
            const prefix = cType === "if_block" ? "if" : "unless";
            const offset = config.blockOffset || "~ ~-1 ~";
            const block = config.blockType || "minecraft:lava";
            const blockCompiled = version === "bedrock" ? block.replace("minecraft:", "") : block;
            condition = `${prefix} block ${offset} ${blockCompiled}`;
        } 
        else if (cType === "if_entity" || cType === "unless_entity") {
            const prefix = cType === "if_entity" ? "if" : "unless";
            const mob = config.mobType || "minecraft:creeper";
            const mobCompiled = version === "bedrock" ? mob.replace("minecraft:", "") : mob;
            const distFilter = this.parseRangeForSelector(config.distance, version === "bedrock");
            condition = `${prefix} entity @e[type=${mobCompiled},${distFilter}]`;
        } 
        else if (cType === "if_sneaking") {
            if (version === "bedrock") {
                condition = "positioned ~ ~1.6 ~ unless entity @s[dx=0,dy=0.4,dz=0] positioned ~ ~-1.6 ~";
            } else {
                condition = "if entity @s[pose=sneaking]";
            }
        }
        else if (cType === "if_items") {
            const slot = config.invSlot || "weapon.mainhand";
            const item = config.invItem || "minecraft:diamond_sword";
            const count = config.invCount !== undefined ? config.invCount : 1;
            
            if (version === "java_modern") {
                const countStr = count > 1 ? ` ${count}..` : "";
                condition = `if items entity @s ${slot} ${item}${countStr}`;
            } else if (version === "java_legacy") {
                if (slot === "weapon.mainhand") {
                    condition = `if entity @s[nbt={SelectedItem:{id:"${item}",Count:${count}b}}]`;
                } else {
                    const slotByteMap = {
                        "weapon.offhand": "-106b",
                        "armor.head": "103b",
                        "armor.chest": "102b",
                        "armor.legs": "101b",
                        "armor.feet": "100b"
                    };
                    const slotByte = slotByteMap[slot] || "0b";
                    condition = `if entity @s[nbt={Inventory:[{Slot:${slotByte},id:"${item}",Count:${count}b}]}]`;
                }
            } else if (version === "bedrock") {
                // Handled natively in selector via hasitem
                condition = "";
            }
        }
        else if (cType === "if_dimension") {
            if (version === "bedrock") {
                condition = ""; // Bedrock doesn't have dimension checks natively in execute
            } else {
                condition = `if dimension ${config.dimension || "minecraft:overworld"}`;
            }
        } 
        else if (cType === "if_weather") {
            if (version === "bedrock") {
                condition = ""; // Bedrock doesn't have weather checks natively in execute
            } else {
                condition = `if weather ${config.weather || "rain"}`;
            }
        } 
        else if (cType === "if_score") {
            const obj = config.scoreObj || "dummy";
            const val = config.scoreVal || "1..";
            let opString = `matches ${val}`;
            
            if (config.scoreOp && config.scoreOp !== "matches") {
                if (config.scoreOp === ">=") opString = `matches ${val}..`;
                else if (config.scoreOp === "<=") opString = `matches ..${val}`;
                else if (config.scoreOp === "=") opString = `matches ${val}`;
            }
            condition = `if score @s ${obj} ${opString}`;
        }
        else if (cType === "if_altitude") {
            const minY = config.altMin !== undefined ? config.altMin : 120;
            const dy = config.altHeight !== undefined ? config.altHeight : 50;
            condition = `if entity @s[y=${minY},dy=${dy}]`;
        }

        // --- 4. COMPILE PAYLOAD ACTION ---
        let actionCmd = "";
        const action = config.action || "summon";

        if (action === "give_preset") {
            const presetCmd = config.givePresetCmd || "";
            const target = config.givePresetTarget || "@s";
            const count = config.givePresetCount !== undefined ? config.givePresetCount : 1;

            if (presetCmd) {
                let cmd = presetCmd.trim();
                if (version === "bedrock") {
                    if (cmd.startsWith("/setblock") || cmd.startsWith("setblock")) {
                        if (cmd.startsWith("/")) cmd = cmd.substring(1);
                        actionCmd = cmd;
                    } else {
                        if (cmd.startsWith("/")) cmd = cmd.substring(1);
                        let parts = cmd.split(/\s+/);
                        if (parts[0] === "give") {
                            parts[1] = target;
                            parts[3] = count;
                            actionCmd = parts.join(" ");
                        } else {
                            actionCmd = cmd;
                        }
                    }
                } else {
                    const parsed = this.parseGiveCommand(presetCmd);
                    const itemId = parsed.id;
                    if (version === "java_modern") {
                        let comps = [...parsed.components];
                        if (parsed.tag && parsed.tag.includes("EntityTag:")) {
                            const match = parsed.tag.match(/EntityTag:\s*(\{.*\})/s);
                            if (match) {
                                comps.push(`minecraft:entity_data=${match[1]}`);
                            }
                        } else if (parsed.tag && parsed.tag !== "{}") {
                            comps.push(`minecraft:custom_data=${parsed.tag}`);
                        }
                        const compStr = comps.length > 0 ? `[${comps.join(",")}]` : "";
                        actionCmd = `give ${target} ${itemId}${compStr} ${count}`;
                    } else {
                        let tagStr = parsed.tag ? parsed.tag : "";
                        if (!tagStr && parsed.components && parsed.components.length > 0) {
                            const entityDataComp = parsed.components.find(c => c.includes("entity_data="));
                            if (entityDataComp) {
                                const eqIdx = entityDataComp.indexOf("=");
                                const val = entityDataComp.substring(eqIdx + 1);
                                tagStr = `{EntityTag:${val}}`;
                            }
                        }
                        actionCmd = `give ${target} ${itemId}${tagStr} ${count}`;
                    }
                }
            } else {
                actionCmd = `give ${target} minecraft:stone ${count}`;
            }
        }
        else if (action === "give_item") {
            const item = config.giveItem || "minecraft:diamond_sword";
            const target = config.giveItemTarget || "@s";
            const count = config.giveItemCount !== undefined ? config.giveItemCount : 1;
            
            if (version === "bedrock") {
                actionCmd = `give ${target} ${item.replace("minecraft:", "")} ${count}`;
            } else {
                actionCmd = `give ${target} ${item} ${count}`;
            }
        }
        else if (action === "summon_preset") {
            const presetCmd = config.summonPresetCmd || "";
            const offset = config.summonPresetOffset || "~ ~ ~";

            if (presetCmd) {
                let cmd = presetCmd.trim();
                if (cmd.startsWith("/")) cmd = cmd.substring(1);

                const match = cmd.match(/^(summon\s+[^\s]+)\s+([^\s]+\s+[^\s]+\s+[^\s]+)(.*)$/i);
                if (match) {
                    const prefix = match[1];
                    const suffix = match[3];
                    
                    let finalPrefix = prefix;
                    if (version === "bedrock") {
                        finalPrefix = prefix.replace("minecraft:", "");
                    }
                    actionCmd = `${finalPrefix} ${offset}${suffix}`;
                } else {
                    actionCmd = cmd;
                }
            } else {
                actionCmd = `summon minecraft:zombie ${offset}`;
            }
        }
        else if (action === "summon") {
            const mob = config.actionMob || "minecraft:creeper";
            const offset = config.summonOffset || "~ ~ ~";
            if (version === "java_modern") {
                actionCmd = `summon ${mob} ${offset}`;
            } else {
                actionCmd = `summon ${mob.replace("minecraft:", "")} ${offset}`;
            }
        } 
        else if (action === "playsound") {
            const sound = config.actionSound || "minecraft:entity.creeper.primed";
            const volume = config.soundVolume !== undefined ? config.soundVolume : 1.0;
            const pitch = config.soundPitch !== undefined ? config.soundPitch : 1.0;
            const category = config.soundCategory || "master";

            if (version === "bedrock") {
                const brSound = this.translateSoundToBedrock(sound);
                actionCmd = `playsound ${brSound} @s ~ ~ ~ ${volume} ${pitch}`;
            } else if (version === "java_legacy") {
                actionCmd = `playsound ${sound.replace("minecraft:", "")} ${category} @s ~ ~ ~ ${volume} ${pitch}`;
            } else {
                actionCmd = `playsound ${sound} ${category} @s ~ ~ ~ ${volume} ${pitch}`;
            }
        } 
        else if (action === "particle") {
            const particle = config.actionParticle || "minecraft:portal";
            const speed = config.particleSpeed !== undefined ? config.particleSpeed : 0.1;
            const count = config.particleCount !== undefined ? config.particleCount : 30;
            const offset = config.particleOffset || "~ ~1 ~";

            if (version === "bedrock") {
                const brPart = this.translateParticleToBedrock(particle);
                actionCmd = `particle ${brPart} ${offset}`;
            } else if (version === "java_legacy") {
                actionCmd = `particle ${particle.replace("minecraft:", "")} ${offset} 0.2 0.2 0.2 ${speed} ${count}`;
            } else {
                actionCmd = `particle ${particle} ${offset} 0.2 0.2 0.2 ${speed} ${count}`;
            }
        } 
        else if (action === "effect") {
            const effect = config.actionEffect || "minecraft:blindness";
            const duration = config.effectDuration !== undefined ? config.effectDuration : 10;
            const amp = config.effectAmp !== undefined ? config.effectAmp : 1;
            const hide = !!config.effectHideParticles;

            let durationVal = duration;
            if (typeof duration === "number" || !isNaN(duration)) {
                durationVal = Math.max(1, Math.min(1000000, parseInt(duration) || 10));
            }
            const ampVal = Math.max(0, Math.min(255, parseInt(amp) || 0));

            if (version === "bedrock") {
                const brEffect = this.translateEffectToBedrock(effect);
                actionCmd = `effect @s ${brEffect} ${durationVal} ${ampVal} ${hide ? "true" : "false"}`;
            } else if (version === "java_legacy") {
                actionCmd = `effect @s ${effect.replace("minecraft:", "")} ${durationVal} ${ampVal} ${hide ? "true" : "false"}`;
            } else {
                actionCmd = `effect give @s ${effect} ${durationVal} ${ampVal} ${hide ? "true" : "false"}`;
            }
        } 
        else if (action === "setblock") {
            const block = config.actionBlockPlace || "minecraft:lava";
            const offset = config.blockPlaceOffset || "~ ~ ~";
            const blockCompiled = version === "bedrock" ? block.replace("minecraft:", "") : block;
            actionCmd = `setblock ${offset} ${blockCompiled}`;
        } 
        else if (action === "tellraw") {
            const txt = config.tellrawText || "A weird chill runs down your spine...";
            const color = config.tellrawColor || "white";

            if (version === "bedrock") {
                const code = this.colorCodeBedrock(color);
                actionCmd = `tellraw @s {"rawtext":[{"text":"${code}${this.escapeString(txt)}"}]}`;
            } else {
                actionCmd = `tellraw @s {"text":"${this.escapeString(txt)}","color":"${color}"}`;
            }
        } 
        else if (action === "combust") {
            if (version === "java_modern") {
                actionCmd = "damage @s 1 minecraft:on_fire";
            } else if (version === "java_legacy") {
                actionCmd = "setblock ~ ~ ~ fire";
            } else if (version === "bedrock") {
                actionCmd = "damage @s 1 fire";
            }
        }
        else if (action === "wipe_inv") {
            const item = config.clearItem || "all";
            if (item === "all") {
                actionCmd = "clear @s";
            } else {
                const compiledItem = version === "bedrock" ? item.replace("minecraft:", "") : item;
                actionCmd = `clear @s ${compiledItem}`;
            }
        }
        else if (action === "custom") {
            let custom = (config.customCmd || "/say Hi!").trim();
            if (!custom.startsWith("/")) {
                custom = "/" + custom;
            }
            // Strip leading / since execute syntax runs command relative
            actionCmd = custom.substring(1);
        }

        // --- 5. COMBINE BLOCKS ---
        let compiled = preamble;
        if (condition) {
            compiled += ` ${condition}`;
        }
        compiled += ` run ${actionCmd}`;

        return compiled;
    },

    parseGiveCommand(cmd) {
        if (!cmd) return { id: "minecraft:stone", count: 1, components: [], tag: "" };
        let temp = cmd.trim();

        // Normalize /setblock container commands to /give commands for parsing
        if (temp.startsWith("/setblock") || temp.startsWith("setblock")) {
            const braceIdx = temp.indexOf("{");
            let nbt = "";
            if (braceIdx !== -1) {
                nbt = temp.substring(braceIdx);
            }
            let cmdClean = temp;
            if (cmdClean.startsWith("/")) cmdClean = cmdClean.substring(1);
            let subParts = cmdClean.split(/\s+/);
            let blockType = subParts[4] || "minecraft:chest";
            temp = `/give @p ${blockType}${nbt} 1`;
        }

        // Clean leading slash
        if (temp.startsWith("/")) temp = temp.substring(1);

        let parts = temp.split(/\s+/);
        if (parts[0] !== "give") {
            return { id: temp, count: 1, components: [], tag: "" };
        }

        let giveIdx = temp.indexOf("give");
        let afterGive = temp.substring(giveIdx + 4).trim();
        let selectorSpaceIdx = afterGive.indexOf(" ");
        if (selectorSpaceIdx === -1) {
            return { id: "minecraft:stone", count: 1, components: [], tag: "" };
        }
        let itemAndRest = afterGive.substring(selectorSpaceIdx + 1).trim();

        let itemPart = itemAndRest;
        let count = 1;
        
        let bracketLevel = 0;
        let braceLevel = 0;
        let inQuotes = null;
        let splitIdx = -1;

        for (let i = itemAndRest.length - 1; i >= 0; i--) {
            const char = itemAndRest[i];
            if (inQuotes) {
                if (char === inQuotes) {
                    let escapes = 0;
                    for (let j = i - 1; j >= 0; j--) {
                        if (itemAndRest[j] === "\\") escapes++;
                        else break;
                    }
                    if (escapes % 2 === 0) {
                        inQuotes = null;
                    }
                }
            } else if (char === "'" || char === '"') {
                let escapes = 0;
                for (let j = i - 1; j >= 0; j--) {
                    if (itemAndRest[j] === "\\") escapes++;
                    else break;
                }
                if (escapes % 2 === 0) {
                    inQuotes = char;
                }
            } else if (char === "]" || char === "}") {
                if (char === "]") bracketLevel++;
                else braceLevel++;
            } else if (char === "[" || char === "{") {
                if (char === "[") bracketLevel--;
                else braceLevel--;
            } else if (char === " " || char === "\t") {
                if (bracketLevel === 0 && braceLevel === 0) {
                    splitIdx = i;
                    break;
                }
            }
        }

        if (splitIdx !== -1) {
            itemPart = itemAndRest.substring(0, splitIdx).trim();
            const countPart = itemAndRest.substring(splitIdx + 1).trim();
            count = parseInt(countPart) || 1;
        }

        let id = itemPart;
        let components = [];
        let tag = "";

        const bracketStart = itemPart.indexOf("[");
        const bracketEnd = itemPart.lastIndexOf("]");
        const braceStart = itemPart.indexOf("{");
        
        const isModern = bracketStart !== -1 && (braceStart === -1 || bracketStart < braceStart);

        if (isModern && bracketEnd !== -1 && bracketEnd > bracketStart) {
            id = itemPart.substring(0, bracketStart);
            const compsRaw = itemPart.substring(bracketStart + 1, bracketEnd);
            components = this.splitTopLevelCommas(compsRaw, "[", "]", "{", "}");
        } else {
            const braceStartLocal = itemPart.indexOf("{");
            const braceEndLocal = itemPart.lastIndexOf("}");
            if (braceStartLocal !== -1 && braceEndLocal !== -1 && braceEndLocal > braceStartLocal) {
                id = itemPart.substring(0, braceStartLocal);
                tag = itemPart.substring(braceStartLocal);
            }
        }

        if (!id.includes(":")) {
            id = "minecraft:" + id;
        }

        return { id, count, components, tag };
    },

    splitTopLevelCommas(str, openB, closeB, openBrace, closeBrace) {
        let result = [];
        let current = "";
        let inQuotes = null;
        let bracketLevel = 0;
        let braceLevel = 0;

        for (let i = 0; i < str.length; i++) {
            const char = str[i];
            if (inQuotes) {
                if (char === inQuotes) {
                    let escapes = 0;
                    for (let j = i - 1; j >= 0; j--) {
                        if (str[j] === "\\") escapes++;
                        else break;
                    }
                    if (escapes % 2 === 0) {
                        inQuotes = null;
                    }
                }
                current += char;
            } else if (char === "'" || char === '"') {
                inQuotes = char;
                current += char;
            } else if (char === openB) {
                bracketLevel++;
                current += char;
            } else if (char === closeB) {
                bracketLevel--;
                current += char;
            } else if (char === openBrace) {
                braceLevel++;
                current += char;
            } else if (char === closeBrace) {
                braceLevel--;
                current += char;
            } else if (char === "," && bracketLevel === 0 && braceLevel === 0) {
                result.push(current.trim());
                current = "";
            } else {
                current += char;
            }
        }
        if (current.trim()) {
            result.push(current.trim());
        }
        return result;
    },

    generateContainer(config, version) {
        const type = config.type || "minecraft:chest";
        const title = config.title ? config.title.trim() : "";
        const contents = config.contents || {};
        const lootTable = config.lootTable || "none";

        // --- BEDROCK ---
        if (version === "bedrock") {
            const cleanType = type.replace("minecraft:", "");
            let slotItems = [];
            
            // Only add slot items if loot table is none
            if (lootTable === "none") {
                for (const [slotStr, item] of Object.entries(contents)) {
                    const slot = parseInt(slotStr);
                    const id = item.id || "minecraft:stone";
                    const count = item.count || 1;
                    const cleanId = id.replace("minecraft:", "");
                    slotItems.push(`{Slot:${slot}b,id:"${cleanId}",Count:${count}b}`);
                }
            }

            let blockTags = [];
            if (title) {
                blockTags.push(`CustomName:"${this.escapeString(title)}"`);
            }
            if (lootTable !== "none") {
                blockTags.push(`LootTable:"${lootTable}"`);
            } else if (slotItems.length > 0) {
                blockTags.push(`Items:[${slotItems.join(",")}]`);
            }
            const tagStr = blockTags.length > 0 ? ` {${blockTags.join(",")}}` : "";
            let cmd = `/setblock ~ ~ ~ ${cleanType} 0 destroy${tagStr}`;
            if (lootTable !== "none") {
                cmd = `// WARNING: Bedrock /setblock has limited NBT/LootTable support in vanilla commands. Consider using a structure block.\n` + cmd;
            }
            return cmd;
        }

        // --- MODERN JAVA (1.20.5+) ---
        if (version === "java_modern") {
            let containerComps = [];
            if (title) {
                containerComps.push(`minecraft:custom_name='${this.textToJsonComponent(title)}'`);
            }

            if (lootTable !== "none") {
                containerComps.push(`minecraft:container_loot={loot_table:"${lootTable}"}`);
            } else {
                let slotItems = [];
                for (const [slotStr, item] of Object.entries(contents)) {
                    const slot = parseInt(slotStr);
                    const id = item.id || "minecraft:stone";
                    const count = item.count || 1;

                    if (item.isPreset && item.command) {
                        const parsed = this.parseGiveCommand(item.command);
                        let itemComps = parsed.components.map(c => {
                            const eqIdx = c.indexOf("=");
                            if (eqIdx !== -1) {
                                return c.substring(0, eqIdx) + ":" + c.substring(eqIdx + 1);
                            }
                            return c;
                        });
                        if (parsed.tag && parsed.tag.includes("EntityTag:")) {
                            const match = parsed.tag.match(/EntityTag:\s*(\{.*\})/s);
                            if (match) {
                                itemComps.push(`"minecraft:entity_data":${match[1]}`);
                            }
                        } else if (parsed.tag && parsed.tag !== "{}") {
                            itemComps.push(`"minecraft:custom_data":${parsed.tag}`);
                        }
                        const compStr = itemComps.length > 0 ? `,components:{${itemComps.join(",")}}` : "";
                        slotItems.push(`{slot:${slot},item:{id:"${parsed.id}",count:${count}${compStr}}}`);
                    } else {
                        slotItems.push(`{slot:${slot},item:{id:"${id}",count:${count}}}`);
                    }
                }
                if (slotItems.length > 0) {
                    containerComps.push(`minecraft:container=[${slotItems.join(",")}]`);
                }
            }

            const compString = containerComps.length > 0 ? `[${containerComps.join(",")}]` : "";
            return `/give @p ${type}${compString} 1`;
        }

        // --- LEGACY JAVA (up to 1.20.4) ---
        let nbtTags = [];
        let displayTags = [];
        if (title) {
            displayTags.push(`Name:'${this.textToJsonComponent(title)}'`);
        }
        if (displayTags.length > 0) {
            nbtTags.push(`display:{${displayTags.join(",")}}`);
        }

        if (lootTable !== "none") {
            nbtTags.push(`BlockEntityTag:{LootTable:"${lootTable}"}`);
        } else {
            let slotItems = [];
            for (const [slotStr, item] of Object.entries(contents)) {
                const slot = parseInt(slotStr);
                const id = item.id || "minecraft:stone";
                const count = item.count || 1;

                if (item.isPreset && item.command) {
                    const parsed = this.parseGiveCommand(item.command);
                    let tagStr = (parsed.tag && parsed.tag !== "{}") ? parsed.tag : "";
                    if (!tagStr && parsed.components && parsed.components.length > 0) {
                        const entityDataComp = parsed.components.find(c => c.includes("entity_data="));
                        if (entityDataComp) {
                            const eqIdx = entityDataComp.indexOf("=");
                            const val = entityDataComp.substring(eqIdx + 1);
                            tagStr = `{EntityTag:${val}}`;
                        }
                    }
                    const tagPart = tagStr ? `,tag:${tagStr}` : "";
                    slotItems.push(`{Slot:${slot}b,id:"${parsed.id}",Count:${count}b${tagPart}}`);
                } else {
                    slotItems.push(`{Slot:${slot}b,id:"${id}",Count:${count}b}`);
                }
            }
            if (slotItems.length > 0) {
                nbtTags.push(`BlockEntityTag:{Items:[${slotItems.join(",")}]}`);
            }
        }

        const nbtString = nbtTags.length > 0 ? `{${nbtTags.join(",")}}` : "";
        return `/give @p ${type}${nbtString} 1`;
    },

    generatePotion(config, version) {
        const itemId = config.id || "minecraft:potion";
        const customName = config.name ? config.name.trim() : "";
        const colorHex = config.color || "#3498db";
        const decimalColor = parseInt(colorHex.replace("#", ""), 16);
        const effects = config.effects || [];
        const count = 1;

        if (version === "java_modern") {
            let components = [];
            
            // Name component
            if (customName) {
                components.push(`minecraft:custom_name='${this.textToJsonComponent(customName)}'`);
            }

            // Potion contents component
            let potionContents = [];
            if (colorHex && !isNaN(decimalColor)) {
                potionContents.push(`custom_color:${decimalColor}`);
            }

            if (effects.length > 0) {
                let effList = [];
                effects.forEach(eff => {
                    const ampVal = Math.max(0, Math.min(255, (parseInt(eff.amplifier) || 1) - 1));
                    const durVal = eff.infinite ? -1 : (parseInt(eff.duration) || 60) * 20;
                    const showParticles = eff.id === "minecraft:invisibility" ? "0b" : "1b";
                    effList.push(`{id:"${eff.id}",amplifier:${ampVal},duration:${durVal},show_particles:${showParticles}}`);
                });
                potionContents.push(`custom_effects:[${effList.join(",")}]`);
            }

            if (potionContents.length > 0) {
                components.push(`minecraft:potion_contents={${potionContents.join(",")}}`);
            }

            const compString = components.length > 0 ? `[${components.join(",")}]` : "";
            return `/give @p ${itemId}${compString} ${count}`;

        } else if (version === "java_legacy") {
            let nbtTags = [];
            
            if (customName) {
                nbtTags.push(`display:{Name:'${this.textToJsonComponent(customName)}'}`);
            }

            if (colorHex && !isNaN(decimalColor)) {
                nbtTags.push(`CustomPotionColor:${decimalColor}`);
            }

            if (effects.length > 0) {
                let effList = [];
                const effectsDb = (typeof MC_DATA !== "undefined" && MC_DATA.effects) || [];
                effects.forEach(eff => {
                    const ampVal = Math.max(0, Math.min(255, (parseInt(eff.amplifier) || 1) - 1));
                    const dbEff = effectsDb.find(e => e.id === eff.id);
                    const numId = dbEff ? dbEff.numeric_id : 1;
                    const showParticles = eff.id === "minecraft:invisibility" ? ",ShowParticles:0b" : "";
                    const durVal = eff.infinite ? 199999 : (parseInt(eff.duration) || 60) * 20;
                    effList.push(`{Id:${numId}b,Amplifier:${ampVal}b,Duration:${durVal}${showParticles}}`);
                });
                nbtTags.push(`CustomPotionEffects:[${effList.join(",")}]`);
            }

            const nbtString = nbtTags.length > 0 ? `{${nbtTags.join(",")}}` : "";
            return `/give @p ${itemId}${nbtString} ${count}`;

        } else {
            // Bedrock
            const cleanId = itemId.replace("minecraft:", "");
            let cmd = `/give @p ${cleanId} ${count}`;
            
            let warnings = [];
            warnings.push(`# WARNING: Bedrock Edition does not support custom status effects or custom colors directly inside items.`);
            
            if (effects.length > 0) {
                warnings.push(`# To apply these effects, run the following commands on the player or targets:`);
                effects.forEach(eff => {
                    const cleanEffId = eff.id.replace("minecraft:", "");
                    const ampVal = Math.max(0, Math.min(255, (parseInt(eff.amplifier) || 1) - 1));
                    const durVal = eff.infinite ? 99999 : (parseInt(eff.duration) || 60);
                    warnings.push(`/effect @p ${cleanEffId} ${durVal} ${ampVal}`);
                });
            }
            
            return warnings.join("\n") + "\n" + cmd;
        }
    },

    colorToLegacyCode(color) {
        const mapping = {
            "black": 0, "red": 1, "green": 2, "brown": 3,
            "blue": 4, "purple": 5, "cyan": 6, "light_gray": 7,
            "gray": 8, "pink": 9, "lime": 10, "yellow": 11,
            "light_blue": 12, "magenta": 13, "orange": 14, "white": 15
        };
        return mapping[color] !== undefined ? mapping[color] : 15;
    },

    patternToLegacyCode(patternId) {
        const mapping = {
            "minecraft:stripe_top": "ts",
            "minecraft:stripe_bottom": "bs",
            "minecraft:stripe_left": "ls",
            "minecraft:stripe_right": "rs",
            "minecraft:stripe_center": "ms",
            "minecraft:stripe_middle": "cs",
            "minecraft:stripe_downright": "drs",
            "minecraft:stripe_downleft": "dls",
            "minecraft:small_stripes": "ss",
            "minecraft:cross": "cr",
            "minecraft:straight_cross": "sc",
            "minecraft:triangle_bottom": "bt",
            "minecraft:triangle_top": "tt",
            "minecraft:triangles_bottom": "bts",
            "minecraft:triangles_top": "tts",
            "minecraft:diagonal_left": "ld",
            "minecraft:diagonal_right": "rd",
            "minecraft:diagonal_up_left": "lud",
            "minecraft:diagonal_up_right": "rud",
            "minecraft:square_bottom_left": "bl",
            "minecraft:square_bottom_right": "br",
            "minecraft:square_top_left": "tl",
            "minecraft:square_top_right": "tr",
            "minecraft:circle": "mc",
            "minecraft:rhombus": "mr",
            "minecraft:half_vertical": "vh",
            "minecraft:half_horizontal": "hh",
            "minecraft:half_vertical_right": "vhr",
            "minecraft:half_horizontal_bottom": "hhr",
            "minecraft:border": "bo",
            "minecraft:curly_border": "cbo",
            "minecraft:brick": "bri",
            "minecraft:gradient": "gra",
            "minecraft:gradient_up": "gru",
            "minecraft:creeper": "cre",
            "minecraft:skull": "sku",
            "minecraft:flower": "flo",
            "minecraft:mojang": "moj",
            "minecraft:globe": "glb",
            "minecraft:piglin": "pig",
            "minecraft:flow": "flw",
            "minecraft:guster": "gus"
        };
        return mapping[patternId] || "ts";
    },

    generateBanner(config, version) {
        const baseColor = config.baseColor || "white";
        const customName = config.name ? config.name.trim() : "";
        const patterns = config.patterns || [];
        const itemId = `minecraft:${baseColor}_banner`;
        const count = 1;

        if (version === "java_modern") {
            let components = [];
            if (customName) {
                components.push(`minecraft:custom_name='${this.textToJsonComponent(customName)}'`);
            }
            if (patterns.length > 0) {
                const patternsList = patterns.map(p => {
                    const cleanPat = p.pattern.includes(":") ? p.pattern : `minecraft:${p.pattern}`;
                    return `{pattern:"${cleanPat}",color:"${p.color}"}`;
                });
                components.push(`minecraft:banner_patterns=[${patternsList.join(",")}]`);
            }
            const compString = components.length > 0 ? `[${components.join(",")}]` : "";
            return `/give @p ${itemId}${compString} ${count}`;
        }

        if (version === "java_legacy") {
            let nbtTags = [];
            if (customName) {
                nbtTags.push(`display:{Name:'${this.textToJsonComponent(customName)}'}`);
            }
            if (patterns.length > 0) {
                const legacyPatterns = patterns.map(p => {
                    const code = this.patternToLegacyCode(p.pattern);
                    const colorVal = this.colorToLegacyCode(p.color);
                    return `{Pattern:"${code}",Color:${colorVal}}`;
                });
                nbtTags.push(`BlockEntityTag:{Patterns:[${legacyPatterns.join(",")}]}`);
            }
            const nbtString = nbtTags.length > 0 ? `{${nbtTags.join(",")}}` : "";
            return `/give @p ${itemId}${nbtString} ${count}`;
        }

        if (version === "bedrock") {
            const colorVal = this.colorToLegacyCode(baseColor);
            let commands = [];
            commands.push(`# WARNING: Bedrock Edition does not support custom banner patterns or names in /give commands.`);
            commands.push(`# Only a plain banner of the base color will be given.`);
            commands.push(`/give @p banner 1 ${colorVal}`);
            return commands.join("\n");
        }

        return "";
    },

    generateShield(config, version) {
        const baseColor = config.baseColor || "white";
        const customName = config.name ? config.name.trim() : "";
        const patterns = config.patterns || [];
        const itemId = "minecraft:shield";
        const count = 1;

        if (version === "java_modern") {
            let components = [];
            if (customName) {
                components.push(`minecraft:custom_name='${this.textToJsonComponent(customName)}'`);
            }
            components.push(`minecraft:base_color="${baseColor}"`);
            if (patterns.length > 0) {
                const patternsList = patterns.map(p => {
                    const cleanPat = p.pattern.includes(":") ? p.pattern : `minecraft:${p.pattern}`;
                    return `{pattern:"${cleanPat}",color:"${p.color}"}`;
                });
                components.push(`minecraft:banner_patterns=[${patternsList.join(",")}]`);
            }
            const compString = components.length > 0 ? `[${components.join(",")}]` : "";
            return `/give @p ${itemId}${compString} ${count}`;
        }

        if (version === "java_legacy") {
            let nbtTags = [];
            if (customName) {
                nbtTags.push(`display:{Name:'${this.textToJsonComponent(customName)}'}`);
            }
            const baseColorVal = this.colorToLegacyCode(baseColor);
            let blockEntityNbts = [`Base:${baseColorVal}`];
            if (patterns.length > 0) {
                const legacyPatterns = patterns.map(p => {
                    const code = this.patternToLegacyCode(p.pattern);
                    const colorVal = this.colorToLegacyCode(p.color);
                    return `{Pattern:"${code}",Color:${colorVal}}`;
                });
                blockEntityNbts.push(`Patterns:[${legacyPatterns.join(",")}]`);
            }
            nbtTags.push(`BlockEntityTag:{${blockEntityNbts.join(",")}}`);
            const nbtString = nbtTags.length > 0 ? `{${nbtTags.join(",")}}` : "";
            return `/give @p ${itemId}${nbtString} ${count}`;
        }

        if (version === "bedrock") {
            let commands = [];
            commands.push(`# WARNING: Bedrock Edition does not support custom decorated shields in /give commands.`);
            commands.push(`# A standard undecorated shield will be given.`);
            commands.push(`/give @p shield 1`);
            return commands.join("\n");
        }

        return "";
    }
};

if (typeof module !== 'undefined') {
    module.exports = Generator;
}

