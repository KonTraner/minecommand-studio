/* ==========================================================================
   MineCommand Studio - Game Data (Unified & Complete Database)
   ========================================================================== */

// 1. High-Fidelity rendered block and item icons CDN Mappings
function getMobIconPath(mobId) {
    const cleanName = mobId.replace("minecraft:", "").toUpperCase();
    return `https://cdn.jsdelivr.net/gh/Owen1212055/mc-assets@main/entity-assets/flat/${cleanName}.png`;
}

function getItemIconPath(itemId) {
    const cleanName = itemId.replace("minecraft:", "").toUpperCase();
    return `https://cdn.jsdelivr.net/gh/Owen1212055/mc-assets@main/item-assets/${cleanName}.png`;
}

const MC_DATA = {
    // Dynamic Mobs List (Complete living entities)
    mobs: [
        { id: "minecraft:ender_dragon", name: "Ender Dragon", category: "Boss", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:wither", name: "Wither", category: "Boss", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:blaze", name: "Blaze", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:cave_spider", name: "Cave Spider", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:creeper", name: "Creeper", category: "Hostile", special: "creeper", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:drowned", name: "Drowned", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:elder_guardian", name: "Elder Guardian", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:endermite", name: "Endermite", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:evoker", name: "Evoker", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:ghast", name: "Ghast", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:giant", name: "Giant", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:guardian", name: "Guardian", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:hoglin", name: "Hoglin", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:husk", name: "Husk", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:illusioner", name: "Illusioner", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:magma_cube", name: "Magma Cube", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:phantom", name: "Phantom", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:piglin_brute", name: "Piglin Brute", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:pillager", name: "Pillager", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:ravager", name: "Ravager", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:shulker", name: "Shulker", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:silverfish", name: "Silverfish", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:skeleton", name: "Skeleton", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:skeleton_horse", name: "Skeleton Horse", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:slime", name: "Slime", category: "Hostile", special: "slime", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:spider", name: "Spider", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:stray", name: "Stray", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:vex", name: "Vex", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:vindicator", name: "Vindicator", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:warden", name: "Warden", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:witch", name: "Witch", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:wither_skeleton", name: "Wither Skeleton", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:zoglin", name: "Zoglin", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:zombie", name: "Zombie", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:zombie_horse", name: "Zombie Horse", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:zombie_villager", name: "Zombie Villager", category: "Hostile", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:bee", name: "Bee", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:camel", name: "Camel", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:dolphin", name: "Dolphin", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:enderman", name: "Enderman", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:goat", name: "Goat", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:llama", name: "Llama", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:panda", name: "Panda", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:piglin", name: "Piglin", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:polar_bear", name: "Polar Bear", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:sniffer", name: "Sniffer", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:trader_llama", name: "Trader Llama", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:wolf", name: "Wolf", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:zombified_piglin", name: "Zombified Piglin", category: "Neutral", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:allay", name: "Allay", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:axolotl", name: "Axolotl", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:bat", name: "Bat", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:cat", name: "Cat", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:chicken", name: "Chicken", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:cod", name: "Cod", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:cow", name: "Cow", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:donkey", name: "Donkey", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:fox", name: "Fox", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:frog", name: "Frog", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:glow_squid", name: "Glow Squid", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:horse", name: "Horse", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:mooshroom", name: "Mooshroom", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:mule", name: "Mule", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:ocelot", name: "Ocelot", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:parrot", name: "Parrot", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:pig", name: "Pig", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:pufferfish", name: "Pufferfish", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:rabbit", name: "Rabbit", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:salmon", name: "Salmon", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:sheep", name: "Sheep", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:squid", name: "Squid", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:strider", name: "Strider", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:tadpole", name: "Tadpole", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:tropical_fish", name: "Tropical Fish", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:turtle", name: "Turtle", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:villager", name: "Villager", category: "Passive", special: "villager", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:wandering_trader", name: "Wandering Trader", category: "Passive", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:iron_golem", name: "Iron Golem", category: "Utility", get icon() { return getMobIconPath(this.id); } },
        { id: "minecraft:snow_golem", name: "Snow Golem", category: "Utility", get icon() { return getMobIconPath(this.id); } }
    ],

    // Complete Categorized Items Database
    items: {
        weapons: [
            { id: "minecraft:arrow", name: "Arrow", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bow", name: "Bow", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crossbow", name: "Crossbow", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_sword", name: "Diamond Sword", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_sword", name: "Golden Sword", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_sword", name: "Iron Sword", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_sword", name: "Netherite Sword", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shield", name: "Shield", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spectral_arrow", name: "Spectral Arrow", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_sword", name: "Stone Sword", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tipped_arrow", name: "Tipped Arrow", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:trident", name: "Trident", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wooden_sword", name: "Wooden Sword", get icon() { return getItemIconPath(this.id); } }
        ],
        helmets: [
            { id: "minecraft:chainmail_helmet", name: "Chainmail Helmet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_helmet", name: "Diamond Helmet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_helmet", name: "Golden Helmet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_helmet", name: "Iron Helmet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:leather_helmet", name: "Leather Cap", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_helmet", name: "Netherite Helmet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:turtle_helmet", name: "Turtle Shell", get icon() { return getItemIconPath(this.id); } }
        ],
        chestplates: [
            { id: "minecraft:chainmail_chestplate", name: "Chainmail Chestplate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_chestplate", name: "Diamond Chestplate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:elytra", name: "Elytra", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_chestplate", name: "Golden Chestplate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_chestplate", name: "Iron Chestplate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:leather_chestplate", name: "Leather Tunic", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_chestplate", name: "Netherite Chestplate", get icon() { return getItemIconPath(this.id); } }
        ],
        leggings: [
            { id: "minecraft:chainmail_leggings", name: "Chainmail Leggings", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_leggings", name: "Diamond Leggings", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_leggings", name: "Golden Leggings", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_leggings", name: "Iron Leggings", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:leather_leggings", name: "Leather Pants", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_leggings", name: "Netherite Leggings", get icon() { return getItemIconPath(this.id); } }
        ],
        boots: [
            { id: "minecraft:chainmail_boots", name: "Chainmail Boots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_boots", name: "Diamond Boots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_boots", name: "Golden Boots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_boots", name: "Iron Boots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:leather_boots", name: "Leather Boots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_boots", name: "Netherite Boots", get icon() { return getItemIconPath(this.id); } }
        ],
        tools: [
            { id: "minecraft:brush", name: "Brush", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bucket", name: "Bucket", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:axolotl_bucket", name: "Bucket of Axolotl", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cod_bucket", name: "Bucket of Cod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pufferfish_bucket", name: "Bucket of Pufferfish", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:salmon_bucket", name: "Bucket of Salmon", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tadpole_bucket", name: "Bucket of Tadpole", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tropical_fish_bucket", name: "Bucket of Tropical Fish", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:carrot_on_a_stick", name: "Carrot on a Stick", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:clock", name: "Clock", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:compass", name: "Compass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_axe", name: "Diamond Axe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_hoe", name: "Diamond Hoe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_pickaxe", name: "Diamond Pickaxe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_shovel", name: "Diamond Shovel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:firework_rocket", name: "Firework Rocket", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fishing_rod", name: "Fishing Rod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:flint_and_steel", name: "Flint and Steel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:goat_horn", name: "Goat Horn", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_axe", name: "Golden Axe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_hoe", name: "Golden Hoe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_pickaxe", name: "Golden Pickaxe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_shovel", name: "Golden Shovel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_axe", name: "Iron Axe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_hoe", name: "Iron Hoe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_pickaxe", name: "Iron Pickaxe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_shovel", name: "Iron Shovel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lava_bucket", name: "Lava Bucket", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lead", name: "Lead", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:milk_bucket", name: "Milk Bucket", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:name_tag", name: "Name Tag", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_axe", name: "Netherite Axe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_hoe", name: "Netherite Hoe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_pickaxe", name: "Netherite Pickaxe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_shovel", name: "Netherite Shovel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:powder_snow_bucket", name: "Powder Snow Bucket", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:recovery_compass", name: "Recovery Compass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:saddle", name: "Saddle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shears", name: "Shears", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spyglass", name: "Spyglass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_axe", name: "Stone Axe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_hoe", name: "Stone Hoe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_pickaxe", name: "Stone Pickaxe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_shovel", name: "Stone Shovel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_fungus_on_a_stick", name: "Warped Fungus on a Stick", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:water_bucket", name: "Water Bucket", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wooden_axe", name: "Wooden Axe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wooden_hoe", name: "Wooden Hoe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wooden_pickaxe", name: "Wooden Pickaxe", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wooden_shovel", name: "Wooden Shovel", get icon() { return getItemIconPath(this.id); } }
        ],
        blocks: [
            { id: "minecraft:acacia_button", name: "Acacia Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_door", name: "Acacia Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_fence", name: "Acacia Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_fence_gate", name: "Acacia Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_hanging_sign", name: "Acacia Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_leaves", name: "Acacia Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_log", name: "Acacia Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_planks", name: "Acacia Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_pressure_plate", name: "Acacia Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_sapling", name: "Acacia Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_sign", name: "Acacia Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_slab", name: "Acacia Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_stairs", name: "Acacia Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_trapdoor", name: "Acacia Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_wood", name: "Acacia Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:activator_rail", name: "Activator Rail", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:allium", name: "Allium", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:amethyst_cluster", name: "Amethyst Cluster", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ancient_debris", name: "Ancient Debris", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:andesite", name: "Andesite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:andesite_slab", name: "Andesite Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:andesite_stairs", name: "Andesite Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:andesite_wall", name: "Andesite Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:anvil", name: "Anvil", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:azalea", name: "Azalea", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:azalea_leaves", name: "Azalea Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:azure_bluet", name: "Azure Bluet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo", name: "Bamboo", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_button", name: "Bamboo Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_door", name: "Bamboo Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_fence", name: "Bamboo Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_fence_gate", name: "Bamboo Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_hanging_sign", name: "Bamboo Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_mosaic", name: "Bamboo Mosaic", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_mosaic_slab", name: "Bamboo Mosaic Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_mosaic_stairs", name: "Bamboo Mosaic Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_planks", name: "Bamboo Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_pressure_plate", name: "Bamboo Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_sign", name: "Bamboo Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_slab", name: "Bamboo Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_stairs", name: "Bamboo Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_trapdoor", name: "Bamboo Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:barrel", name: "Barrel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:barrier", name: "Barrier", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:basalt", name: "Basalt", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:beacon", name: "Beacon", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bedrock", name: "Bedrock", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bee_nest", name: "Bee Nest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:beehive", name: "Beehive", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bell", name: "Bell", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:big_dripleaf", name: "Big Dripleaf", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_button", name: "Birch Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_door", name: "Birch Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_fence", name: "Birch Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_fence_gate", name: "Birch Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_hanging_sign", name: "Birch Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_leaves", name: "Birch Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_log", name: "Birch Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_planks", name: "Birch Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_pressure_plate", name: "Birch Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_sapling", name: "Birch Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_sign", name: "Birch Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_slab", name: "Birch Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_stairs", name: "Birch Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_trapdoor", name: "Birch Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_wood", name: "Birch Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_banner", name: "Black Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_bed", name: "Black Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_candle", name: "Black Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_carpet", name: "Black Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_concrete", name: "Black Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_concrete_powder", name: "Black Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_glazed_terracotta", name: "Black Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_shulker_box", name: "Black Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_stained_glass", name: "Black Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_stained_glass_pane", name: "Black Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_terracotta", name: "Black Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_wool", name: "Black Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blackstone", name: "Blackstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blackstone_slab", name: "Blackstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blackstone_stairs", name: "Blackstone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blackstone_wall", name: "Blackstone Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blast_furnace", name: "Blast Furnace", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:amethyst_block", name: "Block of Amethyst", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_block", name: "Block of Bamboo", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:coal_block", name: "Block of Coal", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:copper_block", name: "Block of Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_block", name: "Block of Diamond", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:emerald_block", name: "Block of Emerald", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gold_block", name: "Block of Gold", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_block", name: "Block of Iron", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lapis_block", name: "Block of Lapis Lazuli", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_block", name: "Block of Netherite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:quartz_block", name: "Block of Quartz", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raw_copper_block", name: "Block of Raw Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raw_gold_block", name: "Block of Raw Gold", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raw_iron_block", name: "Block of Raw Iron", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:redstone_block", name: "Block of Redstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_bamboo_block", name: "Block of Stripped Bamboo", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_banner", name: "Blue Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_bed", name: "Blue Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_candle", name: "Blue Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_carpet", name: "Blue Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_concrete", name: "Blue Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_concrete_powder", name: "Blue Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_glazed_terracotta", name: "Blue Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_ice", name: "Blue Ice", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_orchid", name: "Blue Orchid", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_shulker_box", name: "Blue Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_stained_glass", name: "Blue Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_stained_glass_pane", name: "Blue Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_terracotta", name: "Blue Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_wool", name: "Blue Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bone_block", name: "Bone Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bookshelf", name: "Bookshelf", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brain_coral", name: "Brain Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brain_coral_block", name: "Brain Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brain_coral_fan", name: "Brain Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brewing_stand", name: "Brewing Stand", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brick_slab", name: "Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brick_stairs", name: "Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brick_wall", name: "Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bricks", name: "Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_banner", name: "Brown Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_bed", name: "Brown Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_candle", name: "Brown Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_carpet", name: "Brown Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_concrete", name: "Brown Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_concrete_powder", name: "Brown Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_glazed_terracotta", name: "Brown Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_mushroom", name: "Brown Mushroom", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_mushroom_block", name: "Brown Mushroom Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_shulker_box", name: "Brown Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_stained_glass", name: "Brown Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_stained_glass_pane", name: "Brown Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_terracotta", name: "Brown Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_wool", name: "Brown Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bubble_coral", name: "Bubble Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bubble_coral_block", name: "Bubble Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bubble_coral_fan", name: "Bubble Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:budding_amethyst", name: "Budding Amethyst", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cactus", name: "Cactus", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cake", name: "Cake", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:calcite", name: "Calcite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:calibrated_sculk_sensor", name: "Calibrated Sculk Sensor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:campfire", name: "Campfire", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:candle", name: "Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cartography_table", name: "Cartography Table", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:carved_pumpkin", name: "Carved Pumpkin", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cauldron", name: "Cauldron", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chain", name: "Chain", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chain_command_block", name: "Chain Command Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_button", name: "Cherry Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_door", name: "Cherry Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_fence", name: "Cherry Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_fence_gate", name: "Cherry Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_hanging_sign", name: "Cherry Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_leaves", name: "Cherry Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_log", name: "Cherry Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_planks", name: "Cherry Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_pressure_plate", name: "Cherry Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_sapling", name: "Cherry Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_sign", name: "Cherry Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_slab", name: "Cherry Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_stairs", name: "Cherry Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_trapdoor", name: "Cherry Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_wood", name: "Cherry Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chest", name: "Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chipped_anvil", name: "Chipped Anvil", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_bookshelf", name: "Chiseled Bookshelf", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_deepslate", name: "Chiseled Deepslate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_nether_bricks", name: "Chiseled Nether Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_polished_blackstone", name: "Chiseled Polished Blackstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_quartz_block", name: "Chiseled Quartz Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_red_sandstone", name: "Chiseled Red Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_sandstone", name: "Chiseled Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chiseled_stone_bricks", name: "Chiseled Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chorus_flower", name: "Chorus Flower", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chorus_plant", name: "Chorus Plant", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:clay", name: "Clay", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:coal_ore", name: "Coal Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:coarse_dirt", name: "Coarse Dirt", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobbled_deepslate", name: "Cobbled Deepslate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobbled_deepslate_slab", name: "Cobbled Deepslate Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobbled_deepslate_stairs", name: "Cobbled Deepslate Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobbled_deepslate_wall", name: "Cobbled Deepslate Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobblestone", name: "Cobblestone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobblestone_slab", name: "Cobblestone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobblestone_stairs", name: "Cobblestone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobblestone_wall", name: "Cobblestone Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cobweb", name: "Cobweb", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:command_block", name: "Command Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:composter", name: "Composter", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:conduit", name: "Conduit", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:copper_ore", name: "Copper Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cornflower", name: "Cornflower", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cracked_deepslate_bricks", name: "Cracked Deepslate Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cracked_deepslate_tiles", name: "Cracked Deepslate Tiles", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cracked_nether_bricks", name: "Cracked Nether Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cracked_polished_blackstone_bricks", name: "Cracked Polished Blackstone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cracked_stone_bricks", name: "Cracked Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crafting_table", name: "Crafting Table", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:creeper_head", name: "Creeper Head", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_button", name: "Crimson Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_door", name: "Crimson Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_fence", name: "Crimson Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_fence_gate", name: "Crimson Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_fungus", name: "Crimson Fungus", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_hanging_sign", name: "Crimson Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_hyphae", name: "Crimson Hyphae", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_nylium", name: "Crimson Nylium", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_planks", name: "Crimson Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_pressure_plate", name: "Crimson Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_roots", name: "Crimson Roots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_sign", name: "Crimson Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_slab", name: "Crimson Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_stairs", name: "Crimson Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_stem", name: "Crimson Stem", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crimson_trapdoor", name: "Crimson Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:crying_obsidian", name: "Crying Obsidian", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_copper", name: "Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_copper_slab", name: "Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_copper_stairs", name: "Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_red_sandstone", name: "Cut Red Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_red_sandstone_slab", name: "Cut Red Sandstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_sandstone", name: "Cut Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cut_sandstone_slab", name: "Cut Sandstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_banner", name: "Cyan Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_bed", name: "Cyan Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_candle", name: "Cyan Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_carpet", name: "Cyan Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_concrete", name: "Cyan Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_concrete_powder", name: "Cyan Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_glazed_terracotta", name: "Cyan Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_shulker_box", name: "Cyan Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_stained_glass", name: "Cyan Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_stained_glass_pane", name: "Cyan Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_terracotta", name: "Cyan Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_wool", name: "Cyan Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:damaged_anvil", name: "Damaged Anvil", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dandelion", name: "Dandelion", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_button", name: "Dark Oak Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_door", name: "Dark Oak Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_fence", name: "Dark Oak Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_fence_gate", name: "Dark Oak Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_hanging_sign", name: "Dark Oak Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_leaves", name: "Dark Oak Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_log", name: "Dark Oak Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_planks", name: "Dark Oak Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_pressure_plate", name: "Dark Oak Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_sapling", name: "Dark Oak Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_sign", name: "Dark Oak Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_slab", name: "Dark Oak Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_stairs", name: "Dark Oak Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_trapdoor", name: "Dark Oak Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_wood", name: "Dark Oak Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_prismarine", name: "Dark Prismarine", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_prismarine_slab", name: "Dark Prismarine Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_prismarine_stairs", name: "Dark Prismarine Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:daylight_detector", name: "Daylight Detector", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_brain_coral", name: "Dead Brain Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_brain_coral_block", name: "Dead Brain Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_brain_coral_fan", name: "Dead Brain Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_bubble_coral", name: "Dead Bubble Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_bubble_coral_block", name: "Dead Bubble Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_bubble_coral_fan", name: "Dead Bubble Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_bush", name: "Dead Bush", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_fire_coral", name: "Dead Fire Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_fire_coral_block", name: "Dead Fire Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_fire_coral_fan", name: "Dead Fire Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_horn_coral", name: "Dead Horn Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_horn_coral_block", name: "Dead Horn Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_horn_coral_fan", name: "Dead Horn Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_tube_coral", name: "Dead Tube Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_tube_coral_block", name: "Dead Tube Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dead_tube_coral_fan", name: "Dead Tube Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:decorated_pot", name: "Decorated Pot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate", name: "Deepslate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_brick_slab", name: "Deepslate Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_brick_stairs", name: "Deepslate Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_brick_wall", name: "Deepslate Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_bricks", name: "Deepslate Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_coal_ore", name: "Deepslate Coal Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_copper_ore", name: "Deepslate Copper Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_diamond_ore", name: "Deepslate Diamond Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_emerald_ore", name: "Deepslate Emerald Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_gold_ore", name: "Deepslate Gold Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_iron_ore", name: "Deepslate Iron Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_lapis_ore", name: "Deepslate Lapis Lazuli Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_redstone_ore", name: "Deepslate Redstone Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_tile_slab", name: "Deepslate Tile Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_tile_stairs", name: "Deepslate Tile Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_tile_wall", name: "Deepslate Tile Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:deepslate_tiles", name: "Deepslate Tiles", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:detector_rail", name: "Detector Rail", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_ore", name: "Diamond Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diorite", name: "Diorite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diorite_slab", name: "Diorite Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diorite_stairs", name: "Diorite Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diorite_wall", name: "Diorite Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dirt", name: "Dirt", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dirt_path", name: "Dirt Path", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dispenser", name: "Dispenser", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dragon_egg", name: "Dragon Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dragon_head", name: "Dragon Head", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dried_kelp_block", name: "Dried Kelp Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dripstone_block", name: "Dripstone Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dropper", name: "Dropper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:emerald_ore", name: "Emerald Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:enchanting_table", name: "Enchanting Table", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_portal_frame", name: "End Portal Frame", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_rod", name: "End Rod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_stone", name: "End Stone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_stone_brick_slab", name: "End Stone Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_stone_brick_stairs", name: "End Stone Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_stone_brick_wall", name: "End Stone Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_stone_bricks", name: "End Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ender_chest", name: "Ender Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:exposed_copper", name: "Exposed Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:exposed_cut_copper", name: "Exposed Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:exposed_cut_copper_slab", name: "Exposed Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:exposed_cut_copper_stairs", name: "Exposed Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:farmland", name: "Farmland", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fern", name: "Fern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fire_coral", name: "Fire Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fire_coral_block", name: "Fire Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fire_coral_fan", name: "Fire Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fletching_table", name: "Fletching Table", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:flower_pot", name: "Flower Pot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:flowering_azalea", name: "Flowering Azalea", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:flowering_azalea_leaves", name: "Flowering Azalea Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:frogspawn", name: "Frogspawn", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:furnace", name: "Furnace", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gilded_blackstone", name: "Gilded Blackstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glass", name: "Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glass_pane", name: "Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glow_lichen", name: "Glow Lichen", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glowstone", name: "Glowstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gold_ore", name: "Gold Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:granite", name: "Granite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:granite_slab", name: "Granite Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:granite_stairs", name: "Granite Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:granite_wall", name: "Granite Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:grass", name: "Grass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:grass_block", name: "Grass Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gravel", name: "Gravel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_banner", name: "Gray Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_bed", name: "Gray Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_candle", name: "Gray Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_carpet", name: "Gray Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_concrete", name: "Gray Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_concrete_powder", name: "Gray Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_glazed_terracotta", name: "Gray Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_shulker_box", name: "Gray Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_stained_glass", name: "Gray Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_stained_glass_pane", name: "Gray Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_terracotta", name: "Gray Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_wool", name: "Gray Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_banner", name: "Green Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_bed", name: "Green Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_candle", name: "Green Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_carpet", name: "Green Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_concrete", name: "Green Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_concrete_powder", name: "Green Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_glazed_terracotta", name: "Green Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_shulker_box", name: "Green Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_stained_glass", name: "Green Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_stained_glass_pane", name: "Green Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_terracotta", name: "Green Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_wool", name: "Green Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:grindstone", name: "Grindstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:hanging_roots", name: "Hanging Roots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:hay_block", name: "Hay Bale", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:heavy_weighted_pressure_plate", name: "Heavy Weighted Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:honey_block", name: "Honey Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:honeycomb_block", name: "Honeycomb Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:hopper", name: "Hopper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:horn_coral", name: "Horn Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:horn_coral_block", name: "Horn Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:horn_coral_fan", name: "Horn Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ice", name: "Ice", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_chiseled_stone_bricks", name: "Infested Chiseled Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_cobblestone", name: "Infested Cobblestone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_cracked_stone_bricks", name: "Infested Cracked Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_deepslate", name: "Infested Deepslate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_mossy_stone_bricks", name: "Infested Mossy Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_stone", name: "Infested Stone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:infested_stone_bricks", name: "Infested Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_bars", name: "Iron Bars", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_door", name: "Iron Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_ore", name: "Iron Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_trapdoor", name: "Iron Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jack_o_lantern", name: "Jack o'Lantern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jigsaw", name: "Jigsaw Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jukebox", name: "Jukebox", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_button", name: "Jungle Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_door", name: "Jungle Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_fence", name: "Jungle Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_fence_gate", name: "Jungle Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_hanging_sign", name: "Jungle Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_leaves", name: "Jungle Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_log", name: "Jungle Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_planks", name: "Jungle Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_pressure_plate", name: "Jungle Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_sapling", name: "Jungle Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_sign", name: "Jungle Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_slab", name: "Jungle Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_stairs", name: "Jungle Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_trapdoor", name: "Jungle Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_wood", name: "Jungle Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:kelp", name: "Kelp", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ladder", name: "Ladder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lantern", name: "Lantern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lapis_ore", name: "Lapis Lazuli Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:large_amethyst_bud", name: "Large Amethyst Bud", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:large_fern", name: "Large Fern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lectern", name: "Lectern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lever", name: "Lever", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light", name: "Light", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_banner", name: "Light Blue Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_bed", name: "Light Blue Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_candle", name: "Light Blue Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_carpet", name: "Light Blue Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_concrete", name: "Light Blue Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_concrete_powder", name: "Light Blue Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_glazed_terracotta", name: "Light Blue Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_shulker_box", name: "Light Blue Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_stained_glass", name: "Light Blue Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_stained_glass_pane", name: "Light Blue Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_terracotta", name: "Light Blue Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_wool", name: "Light Blue Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_banner", name: "Light Gray Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_bed", name: "Light Gray Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_candle", name: "Light Gray Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_carpet", name: "Light Gray Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_concrete", name: "Light Gray Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_concrete_powder", name: "Light Gray Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_glazed_terracotta", name: "Light Gray Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_shulker_box", name: "Light Gray Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_stained_glass", name: "Light Gray Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_stained_glass_pane", name: "Light Gray Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_terracotta", name: "Light Gray Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_wool", name: "Light Gray Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_weighted_pressure_plate", name: "Light Weighted Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lightning_rod", name: "Lightning Rod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lilac", name: "Lilac", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lily_of_the_valley", name: "Lily of the Valley", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lily_pad", name: "Lily Pad", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_banner", name: "Lime Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_bed", name: "Lime Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_candle", name: "Lime Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_carpet", name: "Lime Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_concrete", name: "Lime Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_concrete_powder", name: "Lime Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_glazed_terracotta", name: "Lime Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_shulker_box", name: "Lime Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_stained_glass", name: "Lime Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_stained_glass_pane", name: "Lime Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_terracotta", name: "Lime Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_wool", name: "Lime Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lodestone", name: "Lodestone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:loom", name: "Loom", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_banner", name: "Magenta Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_bed", name: "Magenta Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_candle", name: "Magenta Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_carpet", name: "Magenta Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_concrete", name: "Magenta Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_concrete_powder", name: "Magenta Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_glazed_terracotta", name: "Magenta Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_shulker_box", name: "Magenta Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_stained_glass", name: "Magenta Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_stained_glass_pane", name: "Magenta Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_terracotta", name: "Magenta Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_wool", name: "Magenta Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magma_block", name: "Magma Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_button", name: "Mangrove Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_door", name: "Mangrove Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_fence", name: "Mangrove Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_fence_gate", name: "Mangrove Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_hanging_sign", name: "Mangrove Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_leaves", name: "Mangrove Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_log", name: "Mangrove Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_planks", name: "Mangrove Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_pressure_plate", name: "Mangrove Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_propagule", name: "Mangrove Propagule", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_roots", name: "Mangrove Roots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_sign", name: "Mangrove Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_slab", name: "Mangrove Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_stairs", name: "Mangrove Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_trapdoor", name: "Mangrove Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_wood", name: "Mangrove Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:medium_amethyst_bud", name: "Medium Amethyst Bud", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:melon", name: "Melon", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spawner", name: "Monster Spawner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:moss_block", name: "Moss Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:moss_carpet", name: "Moss Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_cobblestone", name: "Mossy Cobblestone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_cobblestone_slab", name: "Mossy Cobblestone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_cobblestone_stairs", name: "Mossy Cobblestone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_cobblestone_wall", name: "Mossy Cobblestone Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_stone_brick_slab", name: "Mossy Stone Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_stone_brick_stairs", name: "Mossy Stone Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_stone_brick_wall", name: "Mossy Stone Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mossy_stone_bricks", name: "Mossy Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mud", name: "Mud", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mud_brick_slab", name: "Mud Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mud_brick_stairs", name: "Mud Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mud_brick_wall", name: "Mud Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mud_bricks", name: "Mud Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:muddy_mangrove_roots", name: "Muddy Mangrove Roots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mushroom_stem", name: "Mushroom Stem", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mycelium", name: "Mycelium", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_brick_fence", name: "Nether Brick Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_brick_slab", name: "Nether Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_brick_stairs", name: "Nether Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_brick_wall", name: "Nether Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_bricks", name: "Nether Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_gold_ore", name: "Nether Gold Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_quartz_ore", name: "Nether Quartz Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_sprouts", name: "Nether Sprouts", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_wart", name: "Nether Wart", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_wart_block", name: "Nether Wart Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherrack", name: "Netherrack", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:note_block", name: "Note Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_button", name: "Oak Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_door", name: "Oak Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_fence", name: "Oak Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_fence_gate", name: "Oak Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_hanging_sign", name: "Oak Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_leaves", name: "Oak Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_log", name: "Oak Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_planks", name: "Oak Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_pressure_plate", name: "Oak Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_sapling", name: "Oak Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_sign", name: "Oak Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_slab", name: "Oak Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_stairs", name: "Oak Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_trapdoor", name: "Oak Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_wood", name: "Oak Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:observer", name: "Observer", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:obsidian", name: "Obsidian", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ochre_froglight", name: "Ochre Froglight", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_banner", name: "Orange Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_bed", name: "Orange Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_candle", name: "Orange Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_carpet", name: "Orange Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_concrete", name: "Orange Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_concrete_powder", name: "Orange Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_glazed_terracotta", name: "Orange Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_shulker_box", name: "Orange Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_stained_glass", name: "Orange Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_stained_glass_pane", name: "Orange Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_terracotta", name: "Orange Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_tulip", name: "Orange Tulip", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_wool", name: "Orange Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oxeye_daisy", name: "Oxeye Daisy", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oxidized_copper", name: "Oxidized Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oxidized_cut_copper", name: "Oxidized Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oxidized_cut_copper_slab", name: "Oxidized Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oxidized_cut_copper_stairs", name: "Oxidized Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:packed_ice", name: "Packed Ice", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:packed_mud", name: "Packed Mud", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pearlescent_froglight", name: "Pearlescent Froglight", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:peony", name: "Peony", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:petrified_oak_slab", name: "Petrified Oak Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:piglin_head", name: "Piglin Head", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_banner", name: "Pink Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_bed", name: "Pink Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_candle", name: "Pink Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_carpet", name: "Pink Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_concrete", name: "Pink Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_concrete_powder", name: "Pink Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_glazed_terracotta", name: "Pink Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_petals", name: "Pink Petals", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_shulker_box", name: "Pink Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_stained_glass", name: "Pink Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_stained_glass_pane", name: "Pink Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_terracotta", name: "Pink Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_tulip", name: "Pink Tulip", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_wool", name: "Pink Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:piston", name: "Piston", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pitcher_plant", name: "Pitcher Plant", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:player_head", name: "Player Head", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:podzol", name: "Podzol", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pointed_dripstone", name: "Pointed Dripstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_andesite", name: "Polished Andesite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_andesite_slab", name: "Polished Andesite Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_andesite_stairs", name: "Polished Andesite Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_basalt", name: "Polished Basalt", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone", name: "Polished Blackstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_brick_slab", name: "Polished Blackstone Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_brick_stairs", name: "Polished Blackstone Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_brick_wall", name: "Polished Blackstone Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_bricks", name: "Polished Blackstone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_button", name: "Polished Blackstone Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_pressure_plate", name: "Polished Blackstone Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_slab", name: "Polished Blackstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_stairs", name: "Polished Blackstone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_blackstone_wall", name: "Polished Blackstone Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_deepslate", name: "Polished Deepslate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_deepslate_slab", name: "Polished Deepslate Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_deepslate_stairs", name: "Polished Deepslate Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_deepslate_wall", name: "Polished Deepslate Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_diorite", name: "Polished Diorite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_diorite_slab", name: "Polished Diorite Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_diorite_stairs", name: "Polished Diorite Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_granite", name: "Polished Granite", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_granite_slab", name: "Polished Granite Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polished_granite_stairs", name: "Polished Granite Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:poppy", name: "Poppy", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:powered_rail", name: "Powered Rail", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine", name: "Prismarine", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_brick_slab", name: "Prismarine Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_brick_stairs", name: "Prismarine Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_bricks", name: "Prismarine Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_slab", name: "Prismarine Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_stairs", name: "Prismarine Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_wall", name: "Prismarine Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pumpkin", name: "Pumpkin", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_banner", name: "Purple Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_bed", name: "Purple Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_candle", name: "Purple Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_carpet", name: "Purple Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_concrete", name: "Purple Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_concrete_powder", name: "Purple Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_glazed_terracotta", name: "Purple Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_shulker_box", name: "Purple Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_stained_glass", name: "Purple Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_stained_glass_pane", name: "Purple Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_terracotta", name: "Purple Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_wool", name: "Purple Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purpur_block", name: "Purpur Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purpur_pillar", name: "Purpur Pillar", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purpur_slab", name: "Purpur Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purpur_stairs", name: "Purpur Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:quartz_bricks", name: "Quartz Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:quartz_pillar", name: "Quartz Pillar", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:quartz_slab", name: "Quartz Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:quartz_stairs", name: "Quartz Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rail", name: "Rail", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_banner", name: "Red Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_bed", name: "Red Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_candle", name: "Red Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_carpet", name: "Red Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_concrete", name: "Red Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_concrete_powder", name: "Red Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_glazed_terracotta", name: "Red Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_mushroom", name: "Red Mushroom", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_mushroom_block", name: "Red Mushroom Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_nether_brick_slab", name: "Red Nether Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_nether_brick_stairs", name: "Red Nether Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_nether_brick_wall", name: "Red Nether Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_nether_bricks", name: "Red Nether Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_sand", name: "Red Sand", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_sandstone", name: "Red Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_sandstone_slab", name: "Red Sandstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_sandstone_stairs", name: "Red Sandstone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_sandstone_wall", name: "Red Sandstone Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_shulker_box", name: "Red Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_stained_glass", name: "Red Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_stained_glass_pane", name: "Red Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_terracotta", name: "Red Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_tulip", name: "Red Tulip", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_wool", name: "Red Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:comparator", name: "Redstone Comparator", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:redstone_lamp", name: "Redstone Lamp", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:redstone_ore", name: "Redstone Ore", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:repeater", name: "Redstone Repeater", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:redstone_torch", name: "Redstone Torch", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:reinforced_deepslate", name: "Reinforced Deepslate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:repeating_command_block", name: "Repeating Command Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:respawn_anchor", name: "Respawn Anchor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rooted_dirt", name: "Rooted Dirt", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rose_bush", name: "Rose Bush", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sand", name: "Sand", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sandstone", name: "Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sandstone_slab", name: "Sandstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sandstone_stairs", name: "Sandstone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sandstone_wall", name: "Sandstone Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:scaffolding", name: "Scaffolding", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sculk", name: "Sculk", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sculk_catalyst", name: "Sculk Catalyst", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sculk_sensor", name: "Sculk Sensor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sculk_shrieker", name: "Sculk Shrieker", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sculk_vein", name: "Sculk Vein", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sea_lantern", name: "Sea Lantern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sea_pickle", name: "Sea Pickle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:seagrass", name: "Seagrass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shroomlight", name: "Shroomlight", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shulker_box", name: "Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:skeleton_skull", name: "Skeleton Skull", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:slime_block", name: "Slime Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:small_amethyst_bud", name: "Small Amethyst Bud", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:small_dripleaf", name: "Small Dripleaf", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smithing_table", name: "Smithing Table", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smoker", name: "Smoker", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_basalt", name: "Smooth Basalt", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_quartz", name: "Smooth Quartz Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_quartz_slab", name: "Smooth Quartz Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_quartz_stairs", name: "Smooth Quartz Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_red_sandstone", name: "Smooth Red Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_red_sandstone_slab", name: "Smooth Red Sandstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_red_sandstone_stairs", name: "Smooth Red Sandstone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_sandstone", name: "Smooth Sandstone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_sandstone_slab", name: "Smooth Sandstone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_sandstone_stairs", name: "Smooth Sandstone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_stone", name: "Smooth Stone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:smooth_stone_slab", name: "Smooth Stone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sniffer_egg", name: "Sniffer Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:snow", name: "Snow", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:snow_block", name: "Snow Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:soul_campfire", name: "Soul Campfire", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:soul_lantern", name: "Soul Lantern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:soul_sand", name: "Soul Sand", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:soul_soil", name: "Soul Soil", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:soul_torch", name: "Soul Torch", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sponge", name: "Sponge", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spore_blossom", name: "Spore Blossom", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_button", name: "Spruce Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_door", name: "Spruce Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_fence", name: "Spruce Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_fence_gate", name: "Spruce Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_hanging_sign", name: "Spruce Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_leaves", name: "Spruce Leaves", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_log", name: "Spruce Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_planks", name: "Spruce Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_pressure_plate", name: "Spruce Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_sapling", name: "Spruce Sapling", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_sign", name: "Spruce Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_slab", name: "Spruce Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_stairs", name: "Spruce Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_trapdoor", name: "Spruce Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_wood", name: "Spruce Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sticky_piston", name: "Sticky Piston", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone", name: "Stone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_brick_slab", name: "Stone Brick Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_brick_stairs", name: "Stone Brick Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_brick_wall", name: "Stone Brick Wall", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_bricks", name: "Stone Bricks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_button", name: "Stone Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_pressure_plate", name: "Stone Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_slab", name: "Stone Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stone_stairs", name: "Stone Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stonecutter", name: "Stonecutter", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_acacia_log", name: "Stripped Acacia Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_acacia_wood", name: "Stripped Acacia Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_birch_log", name: "Stripped Birch Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_birch_wood", name: "Stripped Birch Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_cherry_log", name: "Stripped Cherry Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_cherry_wood", name: "Stripped Cherry Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_crimson_hyphae", name: "Stripped Crimson Hyphae", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_crimson_stem", name: "Stripped Crimson Stem", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_dark_oak_log", name: "Stripped Dark Oak Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_dark_oak_wood", name: "Stripped Dark Oak Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_jungle_log", name: "Stripped Jungle Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_jungle_wood", name: "Stripped Jungle Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_mangrove_log", name: "Stripped Mangrove Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_mangrove_wood", name: "Stripped Mangrove Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_oak_log", name: "Stripped Oak Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_oak_wood", name: "Stripped Oak Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_spruce_log", name: "Stripped Spruce Log", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_spruce_wood", name: "Stripped Spruce Wood", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_warped_hyphae", name: "Stripped Warped Hyphae", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stripped_warped_stem", name: "Stripped Warped Stem", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:structure_block", name: "Structure Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:structure_void", name: "Structure Void", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sugar_cane", name: "Sugar Cane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sunflower", name: "Sunflower", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:suspicious_gravel", name: "Suspicious Gravel", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:suspicious_sand", name: "Suspicious Sand", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tall_grass", name: "Tall Grass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:target", name: "Target", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:terracotta", name: "Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tinted_glass", name: "Tinted Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tnt", name: "TNT", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:torch", name: "Torch", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:torchflower", name: "Torchflower", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:trapped_chest", name: "Trapped Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tripwire_hook", name: "Tripwire Hook", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tube_coral", name: "Tube Coral", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tube_coral_block", name: "Tube Coral Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tube_coral_fan", name: "Tube Coral Fan", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tuff", name: "Tuff", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:turtle_egg", name: "Turtle Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:twisting_vines", name: "Twisting Vines", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:verdant_froglight", name: "Verdant Froglight", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:vine", name: "Vines", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_button", name: "Warped Button", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_door", name: "Warped Door", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_fence", name: "Warped Fence", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_fence_gate", name: "Warped Fence Gate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_fungus", name: "Warped Fungus", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_hanging_sign", name: "Warped Hanging Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_hyphae", name: "Warped Hyphae", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_nylium", name: "Warped Nylium", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_planks", name: "Warped Planks", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_pressure_plate", name: "Warped Pressure Plate", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_roots", name: "Warped Roots", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_sign", name: "Warped Sign", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_slab", name: "Warped Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_stairs", name: "Warped Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_stem", name: "Warped Stem", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_trapdoor", name: "Warped Trapdoor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warped_wart_block", name: "Warped Wart Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_copper_block", name: "Waxed Block of Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_cut_copper", name: "Waxed Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_cut_copper_slab", name: "Waxed Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_cut_copper_stairs", name: "Waxed Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_exposed_copper", name: "Waxed Exposed Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_exposed_cut_copper", name: "Waxed Exposed Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_exposed_cut_copper_slab", name: "Waxed Exposed Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_exposed_cut_copper_stairs", name: "Waxed Exposed Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_oxidized_copper", name: "Waxed Oxidized Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_oxidized_cut_copper", name: "Waxed Oxidized Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_oxidized_cut_copper_slab", name: "Waxed Oxidized Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_oxidized_cut_copper_stairs", name: "Waxed Oxidized Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_weathered_copper", name: "Waxed Weathered Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_weathered_cut_copper", name: "Waxed Weathered Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_weathered_cut_copper_slab", name: "Waxed Weathered Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:waxed_weathered_cut_copper_stairs", name: "Waxed Weathered Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:weathered_copper", name: "Weathered Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:weathered_cut_copper", name: "Weathered Cut Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:weathered_cut_copper_slab", name: "Weathered Cut Copper Slab", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:weathered_cut_copper_stairs", name: "Weathered Cut Copper Stairs", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:weeping_vines", name: "Weeping Vines", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wet_sponge", name: "Wet Sponge", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wheat", name: "Wheat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_banner", name: "White Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_bed", name: "White Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_candle", name: "White Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_carpet", name: "White Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_concrete", name: "White Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_concrete_powder", name: "White Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_glazed_terracotta", name: "White Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_shulker_box", name: "White Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_stained_glass", name: "White Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_stained_glass_pane", name: "White Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_terracotta", name: "White Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_tulip", name: "White Tulip", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_wool", name: "White Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wither_rose", name: "Wither Rose", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wither_skeleton_skull", name: "Wither Skeleton Skull", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_banner", name: "Yellow Banner", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_bed", name: "Yellow Bed", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_candle", name: "Yellow Candle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_carpet", name: "Yellow Carpet", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_concrete", name: "Yellow Concrete", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_concrete_powder", name: "Yellow Concrete Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_glazed_terracotta", name: "Yellow Glazed Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_shulker_box", name: "Yellow Shulker Box", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_stained_glass", name: "Yellow Stained Glass", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_stained_glass_pane", name: "Yellow Stained Glass Pane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_terracotta", name: "Yellow Terracotta", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_wool", name: "Yellow Wool", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:zombie_head", name: "Zombie Head", get icon() { return getItemIconPath(this.id); } }
        ],
        misc: [
            { id: "minecraft:acacia_boat", name: "Acacia Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:acacia_chest_boat", name: "Acacia Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:allay_spawn_egg", name: "Allay Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:amethyst_shard", name: "Amethyst Shard", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:angler_pottery_sherd", name: "Angler Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:apple", name: "Apple", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:archer_pottery_sherd", name: "Archer Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:armor_stand", name: "Armor Stand", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:arms_up_pottery_sherd", name: "Arms Up Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:axolotl_spawn_egg", name: "Axolotl Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:baked_potato", name: "Baked Potato", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_raft", name: "Bamboo Raft", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bamboo_chest_raft", name: "Bamboo Raft with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:flower_banner_pattern", name: "Banner Pattern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:creeper_banner_pattern", name: "Banner Pattern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:skull_banner_pattern", name: "Banner Pattern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mojang_banner_pattern", name: "Banner Pattern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:globe_banner_pattern", name: "Banner Pattern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:piglin_banner_pattern", name: "Banner Pattern", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bat_spawn_egg", name: "Bat Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bee_spawn_egg", name: "Bee Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:beetroot", name: "Beetroot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:beetroot_seeds", name: "Beetroot Seeds", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:beetroot_soup", name: "Beetroot Soup", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_boat", name: "Birch Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:birch_chest_boat", name: "Birch Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:black_dye", name: "Black Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blade_pottery_sherd", name: "Blade Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blaze_powder", name: "Blaze Powder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blaze_rod", name: "Blaze Rod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blaze_spawn_egg", name: "Blaze Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:blue_dye", name: "Blue Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bone", name: "Bone", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bone_meal", name: "Bone Meal", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:book", name: "Book", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:writable_book", name: "Book and Quill", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:experience_bottle", name: "Bottle o' Enchanting", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bowl", name: "Bowl", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bread", name: "Bread", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brewer_pottery_sherd", name: "Brewer Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brick", name: "Brick", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:brown_dye", name: "Brown Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:bundle", name: "Bundle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:burn_pottery_sherd", name: "Burn Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:camel_spawn_egg", name: "Camel Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:carrot", name: "Carrot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cat_spawn_egg", name: "Cat Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cave_spider_spawn_egg", name: "Cave Spider Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:charcoal", name: "Charcoal", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_boat", name: "Cherry Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cherry_chest_boat", name: "Cherry Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chicken_spawn_egg", name: "Chicken Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chorus_fruit", name: "Chorus Fruit", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:clay_ball", name: "Clay Ball", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:coal", name: "Coal", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cocoa_beans", name: "Cocoa Beans", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cod_spawn_egg", name: "Cod Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_chicken", name: "Cooked Chicken", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_cod", name: "Cooked Cod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_mutton", name: "Cooked Mutton", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_porkchop", name: "Cooked Porkchop", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_rabbit", name: "Cooked Rabbit", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_salmon", name: "Cooked Salmon", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cookie", name: "Cookie", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:copper_ingot", name: "Copper Ingot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cow_spawn_egg", name: "Cow Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:creeper_spawn_egg", name: "Creeper Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cyan_dye", name: "Cyan Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:danger_pottery_sherd", name: "Danger Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_boat", name: "Dark Oak Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dark_oak_chest_boat", name: "Dark Oak Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:debug_stick", name: "Debug Stick", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond", name: "Diamond", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:diamond_horse_armor", name: "Diamond Horse Armor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:disc_fragment_5", name: "Disc Fragment", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dolphin_spawn_egg", name: "Dolphin Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:donkey_spawn_egg", name: "Donkey Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dragon_breath", name: "Dragon's Breath", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dried_kelp", name: "Dried Kelp", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:drowned_spawn_egg", name: "Drowned Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:echo_shard", name: "Echo Shard", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:egg", name: "Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:elder_guardian_spawn_egg", name: "Elder Guardian Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:emerald", name: "Emerald", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:map", name: "Empty Map", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:enchanted_book", name: "Enchanted Book", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:enchanted_golden_apple", name: "Enchanted Golden Apple", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:end_crystal", name: "End Crystal", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ender_dragon_spawn_egg", name: "Ender Dragon Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ender_pearl", name: "Ender Pearl", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:enderman_spawn_egg", name: "Enderman Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:endermite_spawn_egg", name: "Endermite Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:evoker_spawn_egg", name: "Evoker Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:explorer_pottery_sherd", name: "Explorer Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ender_eye", name: "Eye of Ender", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:feather", name: "Feather", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fermented_spider_eye", name: "Fermented Spider Eye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fire_charge", name: "Fire Charge", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:firework_star", name: "Firework Star", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:flint", name: "Flint", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:fox_spawn_egg", name: "Fox Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:friend_pottery_sherd", name: "Friend Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:frog_spawn_egg", name: "Frog Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ghast_spawn_egg", name: "Ghast Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ghast_tear", name: "Ghast Tear", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glass_bottle", name: "Glass Bottle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glistering_melon_slice", name: "Glistering Melon Slice", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glow_berries", name: "Glow Berries", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glow_ink_sac", name: "Glow Ink Sac", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glow_item_frame", name: "Glow Item Frame", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glow_squid_spawn_egg", name: "Glow Squid Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:glowstone_dust", name: "Glowstone Dust", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:goat_spawn_egg", name: "Goat Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gold_ingot", name: "Gold Ingot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gold_nugget", name: "Gold Nugget", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_apple", name: "Golden Apple", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_carrot", name: "Golden Carrot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:golden_horse_armor", name: "Golden Horse Armor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gray_dye", name: "Gray Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:green_dye", name: "Green Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:guardian_spawn_egg", name: "Guardian Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:gunpowder", name: "Gunpowder", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:heart_of_the_sea", name: "Heart of the Sea", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:heart_pottery_sherd", name: "Heart Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:heartbreak_pottery_sherd", name: "Heartbreak Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:hoglin_spawn_egg", name: "Hoglin Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:honey_bottle", name: "Honey Bottle", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:honeycomb", name: "Honeycomb", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:horse_spawn_egg", name: "Horse Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:howl_pottery_sherd", name: "Howl Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:husk_spawn_egg", name: "Husk Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ink_sac", name: "Ink Sac", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_golem_spawn_egg", name: "Iron Golem Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_horse_armor", name: "Iron Horse Armor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_ingot", name: "Iron Ingot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:iron_nugget", name: "Iron Nugget", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:item_frame", name: "Item Frame", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_boat", name: "Jungle Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:jungle_chest_boat", name: "Jungle Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:knowledge_book", name: "Knowledge Book", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lapis_lazuli", name: "Lapis Lazuli", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:leather", name: "Leather", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:leather_horse_armor", name: "Leather Horse Armor", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_blue_dye", name: "Light Blue Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:light_gray_dye", name: "Light Gray Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lime_dye", name: "Lime Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:lingering_potion", name: "Lingering Potion", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:llama_spawn_egg", name: "Llama Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magenta_dye", name: "Magenta Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magma_cream", name: "Magma Cream", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:magma_cube_spawn_egg", name: "Magma Cube Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_boat", name: "Mangrove Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mangrove_chest_boat", name: "Mangrove Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:filled_map", name: "Map", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:melon_seeds", name: "Melon Seeds", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:melon_slice", name: "Melon Slice", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:minecart", name: "Minecart", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chest_minecart", name: "Minecart with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:command_block_minecart", name: "Minecart with Command Block", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:furnace_minecart", name: "Minecart with Furnace", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:hopper_minecart", name: "Minecart with Hopper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tnt_minecart", name: "Minecart with TNT", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:miner_pottery_sherd", name: "Miner Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mooshroom_spawn_egg", name: "Mooshroom Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mourner_pottery_sherd", name: "Mourner Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mule_spawn_egg", name: "Mule Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mushroom_stew", name: "Mushroom Stew", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_13", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_cat", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_blocks", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_chirp", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_far", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_mall", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_mellohi", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_stal", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_strad", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_ward", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_11", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_wait", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_otherside", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_relic", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_5", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:music_disc_pigstep", name: "Music Disc", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nautilus_shell", name: "Nautilus Shell", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_brick", name: "Nether Brick", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:quartz", name: "Nether Quartz", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:nether_star", name: "Nether Star", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_ingot", name: "Netherite Ingot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_scrap", name: "Netherite Scrap", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_boat", name: "Oak Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:oak_chest_boat", name: "Oak Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ocelot_spawn_egg", name: "Ocelot Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:orange_dye", name: "Orange Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:painting", name: "Painting", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:panda_spawn_egg", name: "Panda Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:paper", name: "Paper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:parrot_spawn_egg", name: "Parrot Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:phantom_membrane", name: "Phantom Membrane", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:phantom_spawn_egg", name: "Phantom Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pig_spawn_egg", name: "Pig Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:piglin_brute_spawn_egg", name: "Piglin Brute Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:piglin_spawn_egg", name: "Piglin Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pillager_spawn_egg", name: "Pillager Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pink_dye", name: "Pink Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pitcher_pod", name: "Pitcher Pod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:plenty_pottery_sherd", name: "Plenty Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:poisonous_potato", name: "Poisonous Potato", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:polar_bear_spawn_egg", name: "Polar Bear Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:popped_chorus_fruit", name: "Popped Chorus Fruit", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:potato", name: "Potato", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:potion", name: "Potion", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_crystals", name: "Prismarine Crystals", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prismarine_shard", name: "Prismarine Shard", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:prize_pottery_sherd", name: "Prize Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pufferfish", name: "Pufferfish", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pufferfish_spawn_egg", name: "Pufferfish Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pumpkin_pie", name: "Pumpkin Pie", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:pumpkin_seeds", name: "Pumpkin Seeds", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:purple_dye", name: "Purple Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rabbit_hide", name: "Rabbit Hide", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rabbit_spawn_egg", name: "Rabbit Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rabbit_stew", name: "Rabbit Stew", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rabbit_foot", name: "Rabbit's Foot", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ravager_spawn_egg", name: "Ravager Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:beef", name: "Raw Beef", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:chicken", name: "Raw Chicken", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cod", name: "Raw Cod", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raw_copper", name: "Raw Copper", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raw_gold", name: "Raw Gold", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raw_iron", name: "Raw Iron", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:mutton", name: "Raw Mutton", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:porkchop", name: "Raw Porkchop", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rabbit", name: "Raw Rabbit", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:salmon", name: "Raw Salmon", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:red_dye", name: "Red Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:redstone", name: "Redstone Dust", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rotten_flesh", name: "Rotten Flesh", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:salmon_spawn_egg", name: "Salmon Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:scute", name: "Scute", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sheaf_pottery_sherd", name: "Sheaf Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sheep_spawn_egg", name: "Sheep Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shelter_pottery_sherd", name: "Shelter Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shulker_shell", name: "Shulker Shell", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shulker_spawn_egg", name: "Shulker Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:silverfish_spawn_egg", name: "Silverfish Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:skeleton_horse_spawn_egg", name: "Skeleton Horse Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:skeleton_spawn_egg", name: "Skeleton Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:skull_pottery_sherd", name: "Skull Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:slime_spawn_egg", name: "Slime Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:slime_ball", name: "Slimeball", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:netherite_upgrade_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sentry_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:dune_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:coast_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wild_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:ward_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:eye_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:vex_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tide_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:snout_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:rib_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spire_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wayfinder_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:shaper_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:silence_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:raiser_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:host_armor_trim_smithing_template", name: "Smithing Template", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sniffer_spawn_egg", name: "Sniffer Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:snort_pottery_sherd", name: "Snort Pottery Sherd", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:snow_golem_spawn_egg", name: "Snow Golem Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:snowball", name: "Snowball", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spider_eye", name: "Spider Eye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spider_spawn_egg", name: "Spider Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:splash_potion", name: "Splash Potion", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_boat", name: "Spruce Boat", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:spruce_chest_boat", name: "Spruce Boat with Chest", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:squid_spawn_egg", name: "Squid Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:cooked_beef", name: "Steak", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stick", name: "Stick", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:stray_spawn_egg", name: "Stray Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:strider_spawn_egg", name: "Strider Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:string", name: "String", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sugar", name: "Sugar", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:suspicious_stew", name: "Suspicious Stew", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:sweet_berries", name: "Sweet Berries", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tadpole_spawn_egg", name: "Tadpole Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:torchflower_seeds", name: "Torchflower Seeds", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:totem_of_undying", name: "Totem of Undying", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:trader_llama_spawn_egg", name: "Trader Llama Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tropical_fish", name: "Tropical Fish", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:tropical_fish_spawn_egg", name: "Tropical Fish Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:turtle_spawn_egg", name: "Turtle Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:vex_spawn_egg", name: "Vex Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:villager_spawn_egg", name: "Villager Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:vindicator_spawn_egg", name: "Vindicator Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wandering_trader_spawn_egg", name: "Wandering Trader Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:warden_spawn_egg", name: "Warden Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wheat_seeds", name: "Wheat Seeds", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:white_dye", name: "White Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:witch_spawn_egg", name: "Witch Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wither_skeleton_spawn_egg", name: "Wither Skeleton Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wither_spawn_egg", name: "Wither Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:wolf_spawn_egg", name: "Wolf Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:written_book", name: "Written Book", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:yellow_dye", name: "Yellow Dye", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:zoglin_spawn_egg", name: "Zoglin Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:zombie_horse_spawn_egg", name: "Zombie Horse Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:zombie_spawn_egg", name: "Zombie Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:zombie_villager_spawn_egg", name: "Zombie Villager Spawn Egg", get icon() { return getItemIconPath(this.id); } },
            { id: "minecraft:zombified_piglin_spawn_egg", name: "Zombified Piglin Spawn Egg", get icon() { return getItemIconPath(this.id); } }
        ]
    },

    // Preserved Enchantments List
    enchantments: [
        {
                "id": "sharpness",
                "name": "Sharpness",
                "max": 5,
                "type": "weapon"
        },
        {
                "id": "smite",
                "name": "Smite",
                "max": 5,
                "type": "weapon"
        },
        {
                "id": "bane_of_arthropods",
                "name": "Bane of Arthropods",
                "max": 5,
                "type": "weapon"
        },
        {
                "id": "fire_aspect",
                "name": "Fire Aspect",
                "max": 2,
                "type": "weapon"
        },
        {
                "id": "knockback",
                "name": "Knockback",
                "max": 2,
                "type": "weapon"
        },
        {
                "id": "looting",
                "name": "Looting",
                "max": 3,
                "type": "weapon"
        },
        {
                "id": "sweeping_edge",
                "name": "Sweeping Edge",
                "max": 3,
                "type": "weapon"
        },
        {
                "id": "protection",
                "name": "Protection",
                "max": 4,
                "type": "armor"
        },
        {
                "id": "fire_protection",
                "name": "Fire Protection",
                "max": 4,
                "type": "armor"
        },
        {
                "id": "feather_falling",
                "name": "Feather Falling",
                "max": 4,
                "type": "armor"
        },
        {
                "id": "blast_protection",
                "name": "Blast Protection",
                "max": 4,
                "type": "armor"
        },
        {
                "id": "projectile_protection",
                "name": "Projectile Protection",
                "max": 4,
                "type": "armor"
        },
        {
                "id": "thorns",
                "name": "Thorns",
                "max": 3,
                "type": "armor"
        },
        {
                "id": "respiration",
                "name": "Respiration",
                "max": 3,
                "type": "armor"
        },
        {
                "id": "aqua_affinity",
                "name": "Aqua Affinity",
                "max": 1,
                "type": "armor"
        },
        {
                "id": "depth_strider",
                "name": "Depth Strider",
                "max": 3,
                "type": "armor"
        },
        {
                "id": "frost_walker",
                "name": "Frost Walker",
                "max": 2,
                "type": "armor"
        },
        {
                "id": "soul_speed",
                "name": "Soul Speed",
                "max": 3,
                "type": "armor"
        },
        {
                "id": "swift_sneak",
                "name": "Swift Sneak",
                "max": 3,
                "type": "armor"
        },
        {
                "id": "efficiency",
                "name": "Efficiency",
                "max": 5,
                "type": "tool"
        },
        {
                "id": "silk_touch",
                "name": "Silk Touch",
                "max": 1,
                "type": "tool"
        },
        {
                "id": "fortune",
                "name": "Fortune",
                "max": 3,
                "type": "tool"
        },
        {
                "id": "power",
                "name": "Power",
                "max": 5,
                "type": "bow"
        },
        {
                "id": "punch",
                "name": "Punch",
                "max": 2,
                "type": "bow"
        },
        {
                "id": "flame",
                "name": "Flame",
                "max": 1,
                "type": "bow"
        },
        {
                "id": "infinity",
                "name": "Infinity",
                "max": 1,
                "type": "bow"
        },
        {
                "id": "multishot",
                "name": "Multishot",
                "max": 1,
                "type": "crossbow"
        },
        {
                "id": "piercing",
                "name": "Piercing",
                "max": 4,
                "type": "crossbow"
        },
        {
                "id": "quick_charge",
                "name": "Quick Charge",
                "max": 3,
                "type": "crossbow"
        },
        {
                "id": "loyalty",
                "name": "Loyalty",
                "max": 3,
                "type": "trident"
        },
        {
                "id": "impaling",
                "name": "Impaling",
                "max": 5,
                "type": "trident"
        },
        {
                "id": "riptide",
                "name": "Riptide",
                "max": 3,
                "type": "trident"
        },
        {
                "id": "channeling",
                "name": "Channeling",
                "max": 1,
                "type": "trident"
        },
        {
                "id": "unbreaking",
                "name": "Unbreaking",
                "max": 3,
                "type": "all"
        },
        {
                "id": "mending",
                "name": "Mending",
                "max": 1,
                "type": "all"
        },
        {
                "id": "binding_curse",
                "name": "Curse of Binding",
                "max": 1,
                "type": "all"
        },
        {
                "id": "vanishing_curse",
                "name": "Curse of Vanishing",
                "max": 1,
                "type": "all"
        }
],

    // Preserved Trolls List
    trolls: [
        {
                "level": 1,
                "id": "cave_spook",
                "name": "Cave Ambient Spook",
                "type": "harmless",
                "desc": "Plays spooky ambient cave noises directly to the victim to trigger sudden paranoia.",
                "java_modern": "/playsound minecraft:ambient.cave ambient [TARGET] ~ ~ ~ 1 1 1",
                "java_legacy": "/playsound minecraft:ambient.cave ambient [TARGET] ~ ~ ~ 1 1 1",
                "bedrock": "/playsound ambient.cave [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "fake_join",
                "name": "Fake User Join Notification",
                "type": "harmless",
                "desc": "Outputs a yellow system announcement claiming a famous entity logged into the server.",
                "java_modern": "/tellraw @a {\"text\":\"Herobrine joined the game\",\"color\":\"yellow\"}",
                "java_legacy": "/tellraw @a {\"text\":\"Herobrine joined the game\",\"color\":\"yellow\"}",
                "bedrock": "/tellraw @a {\"rawtext\":[{\"text\":\"§eHerobrine joined the game\"}]}",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "dizzy_spell",
                "name": "Dizzy Spell",
                "type": "harmless",
                "desc": "Applies short Blindness and Nausea effects to disorient the player with zero damage.",
                "java_modern": "/effect give [TARGET] minecraft:blindness 6 1\n/effect give [TARGET] minecraft:nausea 8 1",
                "java_legacy": "/effect give [TARGET] blindness 6 1\n/effect give [TARGET] nausea 8 1",
                "bedrock": "/effect [TARGET] blindness 6 1\n/effect [TARGET] nausea 8 1",
                "requires_command_block": true
        },
        {
                "level": 1,
                "id": "fake_msg_spam",
                "name": "Butterfingers Speak",
                "type": "harmless",
                "desc": "Forces the target to drop a funny chat slip-up claiming they accidentally dropped their sandwich.",
                "java_modern": "/execute as [TARGET] run me dropped their sandwich in the dirt! ...oops",
                "java_legacy": "/execute as [TARGET] run me dropped their sandwich in the dirt! ...oops",
                "bedrock": "/execute as [TARGET] run me dropped their sandwich in the dirt! ...oops",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "inv_clutter",
                "name": "Cobblestone Clutter",
                "type": "grief",
                "desc": "Gives them a full stack of Cobblestone blocks to pack active inventory hotbar spaces.",
                "java_modern": "/give [TARGET] minecraft:cobblestone 64",
                "java_legacy": "/give [TARGET] cobblestone 64",
                "bedrock": "/give [TARGET] cobblestone 64",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "slowpoke",
                "name": "Sluggish Potion",
                "type": "grief",
                "desc": "Inflicts severe Slowness effect, forcing them to crawl for 10 seconds.",
                "java_modern": "/effect give [TARGET] minecraft:slowness 10 5",
                "java_legacy": "/effect give [TARGET] slowness 10 5",
                "bedrock": "/effect [TARGET] slowness 10 5",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "crit_sound",
                "name": "Constant Whack Sound",
                "type": "harmless",
                "desc": "Plays sharp critical player hit sounds directly to the player, making them think they are being hit.",
                "java_modern": "/playsound minecraft:entity.player.attack.crit master [TARGET] ~ ~ ~ 1 0.5",
                "java_legacy": "/playsound entity.player.attack.crit master [TARGET] ~ ~ ~ 1 0.5",
                "bedrock": "/playsound game.player.hurt [TARGET] ~ ~ ~ 1 0.5",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "lava_hiss",
                "name": "Lava Extinguish Paranoia",
                "type": "harmless",
                "desc": "Plays the lava extinguishing hiss sound constantly in their ears, making them think their build is on fire.",
                "java_modern": "/playsound minecraft:block.lava.extinguish master [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound block.lava.extinguish master [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound random.fizz [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "ghost_creeper_hiss",
                "name": "Creeper Hiss Spook",
                "type": "harmless",
                "desc": "Plays the terrifying Creeper fuse warning sound directly at the victim's location.",
                "java_modern": "/playsound minecraft:entity.creeper.primed host [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound entity.creeper.primed host [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound random.fuse [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "ghost_chicken",
                "name": "Clucking Head Crown",
                "type": "harmless",
                "desc": "Summons a completely invisible chicken at their feet, clucking in their ears.",
                "java_modern": "/execute at [TARGET] run summon minecraft:chicken ~ ~ ~ {Silent:0b,active_effects:[{id:'minecraft:invisibility',amplifier:0,duration:-1,show_particles:0b}]}",
                "java_legacy": "/execute at [TARGET] run summon chicken ~ ~ ~ {Silent:0b,ActiveEffects:[{Id:14,Amplifier:0,Duration:19999,ShowParticles:0b}]}",
                "bedrock": "/execute at [TARGET] run summon chicken ~ ~ ~ minecraft:become_invisible",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "fake_op",
                "name": "Fake Operator Alert",
                "type": "harmless",
                "desc": "Fakes the standard server console OP notice directly to the target's chat screen.",
                "java_modern": "/tellraw [TARGET] {\"text\":\"You are now an operator! Type /help for help.\",\"color\":\"gray\",\"italic\":true}",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"You are now an operator! Type /help for help.\",\"color\":\"gray\",\"italic\":true}",
                "bedrock": "/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§7§oYou are now an operator! Type /help for help.\"}]}",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "disco_floor",
                "name": "Villager Sparkles",
                "type": "harmless",
                "desc": "Summons continuous happy green emerald sparkles under their feet.",
                "java_modern": "/execute at [TARGET] run particle minecraft:happy_villager ~ ~ ~ 0.5 0.1 0.5 0 25",
                "java_legacy": "/execute at [TARGET] run particle happyVillager ~ ~ ~ 0.5 0.1 0.5 0 25",
                "bedrock": "/execute at [TARGET] run particle minecraft:villager_happy ~ ~ ~",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "reverse_speech",
                "name": "Reverse Chat Output",
                "type": "harmless",
                "desc": "Forces the player to output backwards text in public chat, confusing other members.",
                "java_modern": "/execute as [TARGET] run say !ti t'nac I ,gugilb gugilb",
                "java_legacy": "/execute as [TARGET] run say !ti t'nac I ,gugilb gugilb",
                "bedrock": "/execute as [TARGET] run say !ti t'nac I ,gugilb gugilb",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "levitate",
                "name": "Float Away Prank",
                "type": "harmless",
                "desc": "Gives levitation for 3 seconds followed by slow falling for safety.",
                "java_modern": "/effect give [TARGET] minecraft:levitation 3 10\n/effect give [TARGET] minecraft:slow_falling 10 1",
                "java_legacy": "/effect give [TARGET] levitation 3 10\n/effect give [TARGET] slow_falling 10 1",
                "bedrock": "/effect [TARGET] levitation 3 10\n/effect [TARGET] slow_falling 10 1",
                "requires_command_block": true
        },
        {
                "level": 2,
                "id": "ground_gravel",
                "name": "Head Gravel Block",
                "type": "grief",
                "desc": "Places a loose gravel block above their head that drops directly onto them.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~2 ~ minecraft:gravel",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~2 ~ gravel",
                "bedrock": "/execute at [TARGET] run setblock ~ ~2 ~ gravel",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "butterfingers",
                "name": "Poison Potato Hand",
                "type": "grief",
                "desc": "Swaps their active mainhand weapon with a useless poisonous potato.",
                "java_modern": "/item replace entity [TARGET] weapon.mainhand with minecraft:poisonous_potato",
                "java_legacy": "/replaceitem entity [TARGET] slot.weapon.mainhand minecraft:poisonous_potato",
                "bedrock": "/replaceitem entity [TARGET] slot.weapon.mainhand 0 poisonous_potato",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "cobweb_trapper",
                "name": "Cobweb Stiction",
                "type": "grief",
                "desc": "Places a sticky Cobweb block directly at their leg level, slowing them to a crawl.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~ ~ minecraft:cobweb",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~ ~ cobweb",
                "bedrock": "/execute at [TARGET] run setblock ~ ~ ~ cobweb",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "bee_swarm",
                "name": "Angry Bee Swarm",
                "type": "harmless",
                "desc": "Summons a furious, angry bee directly above the target's head that immediately attacks.",
                "java_modern": "/summon minecraft:bee ~ ~3 ~ {AngerTime:1200,AngryAt:[TARGET]}",
                "java_legacy": "/summon bee ~ ~3 ~ {Anger:1200}",
                "bedrock": "/summon bee ~ ~3 ~ minecraft:become_angry",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "fake_diamond_ore",
                "name": "Feet Diamond Bait",
                "type": "grief",
                "desc": "Replaces the block directly beneath their feet with a Diamond Ore block as instant bait.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~-1 ~ minecraft:diamond_ore",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~-1 ~ diamond_ore",
                "bedrock": "/execute at [TARGET] run setblock ~ ~-1 ~ diamond_ore",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "water_cage",
                "name": "Instant Water Cage",
                "type": "grief",
                "desc": "Spawns a block of running water exactly at their head height to slow them down.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~1 ~ minecraft:water",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~1 ~ water",
                "bedrock": "/execute at [TARGET] run setblock ~ ~1 ~ water",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "slow_dig",
                "name": "Mining Fatigue Curse",
                "type": "grief",
                "desc": "Inflicts severe Mining Fatigue for 20 seconds, grinding block breaking to a halt.",
                "java_modern": "/effect give [TARGET] minecraft:mining_fatigue 20 2",
                "java_legacy": "/effect give [TARGET] mining_fatigue 20 2",
                "bedrock": "/effect [TARGET] mining_fatigue 20 2",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "soil_swap",
                "name": "Dirt Hand Curse",
                "type": "grief",
                "desc": "Swaps their active hand held item with a basic block of dirt.",
                "java_modern": "/item replace entity [TARGET] weapon.mainhand with minecraft:dirt",
                "java_legacy": "/replaceitem entity [TARGET] slot.weapon.mainhand minecraft:dirt",
                "bedrock": "/replaceitem entity [TARGET] slot.weapon.mainhand 0 dirt",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "inv_stalker",
                "name": "Invisible Hiss Stalker",
                "type": "harmless",
                "desc": "Summons a fully invisible, silent Creeper that sits right behind them, triggering fake hisses.",
                "java_modern": "/summon minecraft:creeper ~ ~ ~ {Silent:1b,active_effects:[{id:'minecraft:invisibility',amplifier:0,duration:-1,show_particles:0b}]}",
                "java_legacy": "/summon creeper ~ ~ ~ {Silent:1b,ActiveEffects:[{Id:14,Amplifier:0,Duration:19998,ShowParticles:0b}]}",
                "bedrock": "/summon creeper ~ ~ ~ minecraft:become_invisible",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "size_shifter_small",
                "name": "Micro Shrink (0.2x)",
                "type": "harmless",
                "desc": "Shrinks their character model to 20% normal scale (Requires Java 1.20.5+).",
                "java_modern": "/attribute [TARGET] minecraft:generic.scale base set 0.2",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"[Scale pranks are only supported on modern Minecraft 1.20.5+]\",\"color\":\"red\"}",
                "bedrock": "/playanimation [TARGET] animation.player.sleeping scale 0.2",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "size_shifter_big",
                "name": "Titan Grow (4.0x)",
                "type": "harmless",
                "desc": "Grows their character model into a massive 4-block tall behemoth (Requires Java 1.20.5+).",
                "java_modern": "/attribute [TARGET] minecraft:generic.scale base set 4.0",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"[Scale pranks are only supported on modern Minecraft 1.20.5+]\",\"color\":\"red\"}",
                "bedrock": "/playanimation [TARGET] animation.player.sleeping scale 4.0",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "zeus_lightning",
                "name": "Zeus's Bolt Strike",
                "type": "grief",
                "desc": "Strikes an instant lightning bolt directly on their coordinates, setting fires.",
                "java_modern": "/execute at [TARGET] run summon minecraft:lightning_bolt ~ ~ ~",
                "java_legacy": "/execute at [TARGET] run summon lightning_bolt ~ ~ ~",
                "bedrock": "/execute at [TARGET] run summon lightning_bolt ~ ~ ~",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "water_leak",
                "name": "Ceiling Water Leak",
                "type": "grief",
                "desc": "Places running water above their head, washing away nearby torches and redstones.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~2 ~ minecraft:water",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~2 ~ water",
                "bedrock": "/execute at [TARGET] run setblock ~ ~2 ~ water",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "obsidian_cage",
                "name": "Obsidian Coffin",
                "type": "grief",
                "desc": "Wraps their coordinates entirely inside an indestructible 3x3 solid Obsidian block shell.",
                "java_modern": "/execute at [TARGET] run fill ~-1 ~ ~-1 ~1 ~2 ~1 minecraft:obsidian outline\n/execute at [TARGET] run fill ~ ~ ~ ~ ~1 ~ minecraft:air",
                "java_legacy": "/execute at [TARGET] run fill ~-1 ~ ~-1 ~1 ~2 ~1 obsidian outline\n/execute at [TARGET] run fill ~ ~ ~ ~ ~1 ~ air",
                "bedrock": "/execute at [TARGET] run fill ~-1 ~ ~-1 ~1 ~2 ~1 obsidian outline\n/execute at [TARGET] run fill ~ ~ ~ ~ ~1 ~ air",
                "requires_command_block": true
        },
        {
                "level": 3,
                "id": "slime_head",
                "name": "Double Slime Head Helmet",
                "type": "harmless",
                "desc": "Spawns a small double-stacked slime passenger tower directly on top of the player.",
                "java_modern": "/summon minecraft:slime ~ ~2 ~ {Size:1,Passengers:[{id:\"minecraft:slime\",Size:1}]}",
                "java_legacy": "/summon slime ~ ~2 ~ {Size:1,Passengers:[{id:\"slime\",Size:1}]}",
                "bedrock": "/summon slime ~ ~2 ~",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "phantom_steed",
                "name": "Zombie Flying Phantom",
                "type": "grief",
                "desc": "Summons a Flying Phantom high in the sky carrying an aggressive, fully armed Zombie passenger.",
                "java_modern": "/summon minecraft:phantom ~ ~10 ~ {Size:2,Passengers:[{id:\"minecraft:zombie\"}]}",
                "java_legacy": "/summon phantom ~ ~10 ~ {Size:2,Passengers:[{id:\"zombie\"}]}",
                "bedrock": "/summon phantom ~ ~10 ~",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "guardian_scare",
                "name": "Elder Guardian Ghost Scare",
                "type": "harmless",
                "desc": "Flashes the giant Elder Guardian face overlay jump scare on their screen.",
                "java_modern": "/particle minecraft:elder_guardian ~ ~ ~ 0 0 0 0 1 force [TARGET]\n/playsound minecraft:entity.elder_guardian.curse ambient [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/particle elder_guardian ~ ~ ~ 0 0 0 0 1 force [TARGET]\n/playsound entity.elder_guardian.curse ambient [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound mob.elderguardian.curse [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": true
        },
        {
                "level": 3,
                "id": "bedrock_floor",
                "name": "Bedrock Floor Anchor",
                "type": "grief",
                "desc": "Instantly replaces the single block directly beneath their feet with unbreakable Bedrock.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~-1 ~ minecraft:bedrock",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~-1 ~ bedrock",
                "bedrock": "/execute at [TARGET] run setblock ~ ~-1 ~ bedrock",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "angry_wolf",
                "name": "Rabid Wolf Spawner",
                "type": "grief",
                "desc": "Summons an extremely aggressive, angry wild Wolf right next to the target.",
                "java_modern": "/execute at [TARGET] run summon minecraft:wolf ~ ~ ~ {Angry:1b,AngerTime:1200,AngryAt:[TARGET]}",
                "java_legacy": "/execute at [TARGET] run summon wolf ~ ~ ~ {Angry:1b,AngryAt:[TARGET]}",
                "bedrock": "/execute at [TARGET] run summon wolf ~ ~ ~ minecraft:become_angry",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "herobrine_spook",
                "name": "Herobrine Haunting",
                "type": "harmless",
                "desc": "Spawns a glowing skull-wearing armor stand, sounds a ghast shriek, and deletes it.",
                "java_modern": "/execute at [TARGET] run summon minecraft:armor_stand ~ ~1 ~2 {CustomName:'\"Herobrine\"',CustomNameVisible:1b,Glowing:1b,ArmorItems:[{},{},{},{id:'minecraft:player_head'}]}\n/playsound minecraft:entity.ghast.scream ambient [TARGET] ~ ~ ~ 1 0.5",
                "java_legacy": "/execute at [TARGET] run summon armor_stand ~ ~1 ~2 {CustomName:\"Herobrine\",CustomNameVisible:1b,Glowing:1b,ArmorItems:[{},{},{},{id:\"skull\",Damage:3,tag:{SkullOwner:\"Herobrine\"}}]}\n/playsound entity.ghast.scream ambient [TARGET] ~ ~ ~ 1 0.5",
                "bedrock": "/execute at [TARGET] run summon armor_stand ~ ~1 ~2 Herobrine\n/playsound mob.ghast.affectionate_scream [TARGET] ~ ~ ~ 1 0.5",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "fake_diamonds",
                "name": "Fake Diamond Broadcaster",
                "type": "harmless",
                "desc": "Fakes a server-wide system message declaring they got the 'Diamonds!' advancement.",
                "java_modern": "/tellraw @a [{\"selector\":\"[TARGET]\",\"color\":\"white\"},{\"text\":\" has made the advancement \"},{\"text\":\"[Diamonds!]\",\"color\":\"green\",\"bold\":true}]\n/tellraw [TARGET] {\"text\":\"Pranked! Actually zero diamonds!\",\"color\":\"red\"}",
                "java_legacy": "/tellraw @a [{\"selector\":\"[TARGET]\",\"color\":\"white\"},{\"text\":\" has made the advancement \"},{\"text\":\"[Diamonds!]\",\"color\":\"green\",\"bold\":true}]\n/tellraw [TARGET] {\"text\":\"Pranked! Actually zero diamonds!\",\"color\":\"red\"}",
                "bedrock": "/tellraw @a {\"rawtext\":[{\"selector\":\"[TARGET]\"},{\"text\":\" has made the advancement §a§l[Diamonds!]\"}]}\n/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§cPranked! Actually zero diamonds!\"}]}",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "inverse_gravity",
                "name": "Inverse Gravity Chamber",
                "type": "harmless",
                "desc": "Levitates them 15 blocks in the air, holds them suspended, and ambient bats screech around them.",
                "java_modern": "/effect give [TARGET] minecraft:levitation 3 15\n/playsound minecraft:entity.bat.ambient ambient [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/effect give [TARGET] levitation 3 15\n/playsound entity.bat.ambient ambient [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/effect [TARGET] levitation 3 15\n/playsound mob.bat.say [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "anvil_storm",
                "name": "Heavy Anvil Shower",
                "type": "grief",
                "desc": "Summons 2 heavy falling metal Anvils 15 blocks in the sky above their head to crash down.",
                "java_modern": "/execute at [TARGET] run summon minecraft:falling_block ~ ~15 ~ {BlockState:{Name:\"minecraft:anvil\"},Time:1}\n/execute at [TARGET] run summon minecraft:falling_block ~1 ~15 ~ {BlockState:{Name:\"minecraft:anvil\"},Time:1}",
                "java_legacy": "/execute at [TARGET] run summon falling_block ~ ~15 ~ {Block:\"anvil\",Time:1}\n/execute at [TARGET] run summon falling_block ~1 ~15 ~ {Block:\"anvil\",Time:1}",
                "bedrock": "/execute at [TARGET] run summon falling_block ~ ~15 ~ anvil\n/execute at [TARGET] run summon falling_block ~1 ~15 ~ anvil",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "lava_bath",
                "name": "Lava Footbath",
                "type": "grief",
                "desc": "Swaps the single block they are standing on into a burning fluid pool of hot Lava.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~-1 ~ minecraft:lava",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~-1 ~ lava",
                "bedrock": "/execute at [TARGET] run setblock ~ ~-1 ~ lava",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "hotbar_wipe",
                "name": "Hotbar Inventory Wipe",
                "type": "grief",
                "desc": "Clears their active inventory hotbar entirely using the sweeping clear command.",
                "java_modern": "/clear [TARGET]",
                "java_legacy": "/clear [TARGET]",
                "bedrock": "/clear [TARGET]",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "anvil_dropper",
                "name": "Single-Anvil Pinpoint Drop",
                "type": "grief",
                "desc": "Summons a single heavy falling anvil exactly 6 blocks in the air directly above their head.",
                "java_modern": "/execute at [TARGET] run summon minecraft:falling_block ~ ~6 ~ {BlockState:{Name:\"minecraft:anvil\"},Time:1}",
                "java_legacy": "/execute at [TARGET] run summon falling_block ~ ~6 ~ {Block:\"anvil\",Time:1}",
                "bedrock": "/execute at [TARGET] run summon falling_block ~ ~6 ~ anvil",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "giant_phantom",
                "name": "Colossal Phantom Grow",
                "type": "harmless",
                "desc": "Scales flying phantoms near the target to colossal scales.",
                "java_modern": "/execute as @e[type=minecraft:phantom] run data merge entity @s {Size:15}",
                "java_legacy": "/execute as @e[type=phantom] run data merge entity @s {Size:15}",
                "bedrock": "/playanimation @e[type=phantom] animation.ghast.scale scale 8",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "lava_coffin",
                "name": "Lava Shower Trap",
                "type": "grief",
                "desc": "Summons a block of burning lava exactly 3 blocks above their head, causing it to drip down.",
                "java_modern": "/execute at [TARGET] run setblock ~ ~3 ~ minecraft:lava",
                "java_legacy": "/execute at [TARGET] run setblock ~ ~3 ~ lava",
                "bedrock": "/execute at [TARGET] run setblock ~ ~3 ~ lava",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "pumpkin_head",
                "name": "Pumpkin Blindness",
                "type": "grief",
                "desc": "Forces a carved pumpkin onto their head armor slot, severely blocking their screen view.",
                "java_modern": "/item replace entity [TARGET] armor.head with minecraft:carved_pumpkin",
                "java_legacy": "/replaceitem entity [TARGET] slot.armor.head minecraft:carved_pumpkin",
                "bedrock": "/replaceitem entity [TARGET] slot.armor.head 0 carved_pumpkin",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "wither_spawn_sound",
                "name": "Wither Spawn Panic",
                "type": "harmless",
                "desc": "Plays the terrifying Wither Boss spawn sound globally to the target, creating mass panic.",
                "java_modern": "/playsound minecraft:entity.wither.spawn master [TARGET] ~ ~ ~ 1 1 1",
                "java_legacy": "/playsound entity.wither.spawn master [TARGET] ~ ~ ~ 1 1 1",
                "bedrock": "/playsound mob.wither.spawn [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "kbd_freeze",
                "name": "Gravity Freeze Ring",
                "type": "harmless",
                "desc": "Forces player to continuously teleport to their current spot, completely locking movement.",
                "java_modern": "/execute as [TARGET] run tp ~ ~ ~",
                "java_legacy": "/execute as [TARGET] run tp ~ ~ ~",
                "bedrock": "/execute as [TARGET] run tp ~ ~ ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "fake_admin_ban",
                "name": "Fake Admin Ban Screen",
                "type": "harmless",
                "desc": "Flashes an official-looking kicked system tellraw in public chat while sending a private April Fools message.",
                "java_modern": "/tellraw @a {\"text\":\"[System] Connection lost: Kicked by Admin (Violation: FlyHack)\",\"color\":\"red\"}\n/tellraw [TARGET] {\"text\":\"Pranked! You are not banned!\",\"color\":\"green\"}",
                "java_legacy": "/tellraw @a {\"text\":\"[System] Connection lost: Kicked by Admin (Violation: FlyHack)\",\"color\":\"red\"}\n/tellraw [TARGET] {\"text\":\"Pranked! You are not banned!\",\"color\":\"green\"}",
                "bedrock": "/tellraw @a {\"rawtext\":[{\"text\":\"§c[System] Connection lost: Kicked by Admin (Violation: FlyHack)\"}]}\n/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§aPranked! You are not banned!\"}]}",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "mob_singularity",
                "name": "Chicken Stack Apocalypse",
                "type": "grief",
                "desc": "Summons a stacked vertical tower of 6 chickens riding each other in a single chat-compatible line.",
                "java_modern": "/summon minecraft:chicken ~ ~ ~ {Passengers:[{id:\"minecraft:chicken\",Passengers:[{id:\"minecraft:chicken\",Passengers:[{id:\"minecraft:chicken\",Passengers:[{id:\"minecraft:chicken\",Passengers:[{id:\"minecraft:chicken\"}]}]}]}]}]}",
                "java_legacy": "/summon chicken ~ ~ ~ {Passengers:[{id:\"chicken\",Passengers:[{id:\"chicken\",Passengers:[{id:\"chicken\",Passengers:[{id:\"chicken\",Passengers:[{id:\"chicken\"}]}]}]}]}]}",
                "bedrock": "/summon chicken ~ ~ ~\n/summon chicken ~ ~ ~\n/summon chicken ~ ~ ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "bedrock_box",
                "name": "Bedrock Jail Box",
                "type": "grief",
                "desc": "Encapsulates the target inside a hollow 3x3 solid Bedrock tomb that cannot be mined.",
                "java_modern": "/execute at [TARGET] run fill ~-1 ~ ~-1 ~1 ~2 ~1 minecraft:bedrock outline\n/execute at [TARGET] run fill ~ ~ ~ ~ ~1 ~ minecraft:air",
                "java_legacy": "/execute at [TARGET] run fill ~-1 ~ ~-1 ~1 ~2 ~1 bedrock outline\n/execute at [TARGET] run fill ~ ~ ~ ~ ~1 ~ air",
                "bedrock": "/execute at [TARGET] run fill ~-1 ~ ~-1 ~1 ~2 ~1 bedrock outline\n/execute at [TARGET] run fill ~ ~ ~ ~ ~1 ~ air",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "tnt_cluster",
                "name": "Nuclear TNT Riding Stack",
                "type": "grief",
                "desc": "Summons a single-line riding stack of 3 primed TNT blocks that explode instantly in a rapid chain.",
                "java_modern": "/summon minecraft:tnt ~ ~3 ~ {Fuse:15,Passengers:[{id:\"minecraft:tnt\",Fuse:15},{id:\"minecraft:tnt\",Fuse:15}]}",
                "java_legacy": "/summon tnt ~ ~3 ~ {Fuse:15,Passengers:[{id:\"tnt\",Fuse:15},{id:\"tnt\",Fuse:15}]}",
                "bedrock": "/summon tnt ~ ~3 ~",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "mob_magnet",
                "name": "Hostile Mob Magnet",
                "type": "grief",
                "desc": "Instantly teleports all aggressive zombies, skeletons, and creepers within 100 blocks directly onto them.",
                "java_modern": "/execute as [TARGET] run tp @e[type=minecraft:zombie,distance=..100] ~ ~ ~\n/execute as [TARGET] run tp @e[type=minecraft:skeleton,distance=..100] ~ ~ ~",
                "java_legacy": "/execute as [TARGET] run tp @e[type=zombie,distance=..100] ~ ~ ~\n/execute as [TARGET] run tp @e[type=skeleton,distance=..100] ~ ~ ~",
                "bedrock": "/execute as [TARGET] run tp @e[type=zombie] ~ ~ ~\n/execute as [TARGET] run tp @e[type=skeleton] ~ ~ ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "runner_items",
                "name": "Items Run Away Trap",
                "type": "grief",
                "desc": "Pushes any dropped block items away from the target whenever they walk within 3 blocks, making item pickups impossible.",
                "java_modern": "/execute as @e[type=minecraft:item] at @s if entity @p[distance=..3] run tp @s ~ ~0.25 ~",
                "java_legacy": "/execute as @e[type=item] at @s if entity @p[distance=3] run tp @s ~ ~0.25 ~",
                "bedrock": "/execute as @e[type=item] at @s run tp @s ~ ~0.2 ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "forced_spin",
                "name": "Continuous Camera Spin",
                "type": "harmless",
                "desc": "Constantly spins the victim's camera direction in micro-angles, making movement or mining impossible.",
                "java_modern": "/execute as [TARGET] at @s run tp @s ~ ~ ~ ~20 ~",
                "java_legacy": "/execute as [TARGET] at @s run tp @s ~ ~ ~ ~20 ~",
                "bedrock": "/execute as [TARGET] at @s run tp @s ~ ~ ~ ~20 ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "bed_bomb",
                "name": "Bed Explosive Trap",
                "type": "grief",
                "desc": "Summons instant TNT explosions the second the target walks on or sleeps in a bed.",
                "java_modern": "/execute as [TARGET] at @s if block ~ ~-1 ~ #minecraft:beds run summon minecraft:tnt ~ ~ ~",
                "java_legacy": "/execute as [TARGET] at @s if block ~ ~-1 ~ #minecraft:beds run summon tnt ~ ~ ~",
                "bedrock": "/execute as [TARGET] at @s if block ~ ~-1 ~ bed run summon tnt ~ ~ ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "ping_lag",
                "name": "Rubberband Fake Ping Stutter",
                "type": "harmless",
                "desc": "Constantly teleports the player backwards by fractions of a block to simulate an extremely high-ping 1500ms lag.",
                "java_modern": "/execute as [TARGET] at @s run tp @s ~-0.05 ~ ~0.05",
                "java_legacy": "/execute as [TARGET] at @s run tp @s ~-0.05 ~ ~0.05",
                "bedrock": "/execute as [TARGET] at @s run tp @s ~-0.05 ~ ~0.05",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "sky_fall",
                "name": "Terminal Sky Drop (200m)",
                "type": "grief",
                "desc": "Teleports the target 200 blocks straight up into the air, forcing a high-altitude freefall.",
                "java_modern": "/tp [TARGET] ~ ~200 ~",
                "java_legacy": "/tp [TARGET] ~ ~200 ~",
                "bedrock": "/tp [TARGET] ~ ~200 ~",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "diamond_burn",
                "name": "Anti-Diamond Deletion",
                "type": "grief",
                "desc": "Continuously vaporizes any dropped Diamond items near the player, rendering diamond drops impossible.",
                "java_modern": "/execute as @e[type=minecraft:item] at @s if entity @s[nbt={Item:{id:\"minecraft:diamond\"}}] run kill @s",
                "java_legacy": "/execute as @e[type=item] at @s if entity @s[nbt={Item:{id:\"minecraft:diamond\"}}] run kill @s",
                "bedrock": "/kill @e[type=item,name=diamond]",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "exploding_arrows",
                "name": "Arrow TNT Proximity",
                "type": "grief",
                "desc": "Causes every fired arrow to instantly summon a primed exploding TNT block wherever it travels.",
                "java_modern": "/execute at @e[type=minecraft:arrow] run summon minecraft:tnt ~ ~ ~ {Fuse:0}",
                "java_legacy": "/execute at @e[type=arrow] run summon tnt ~ ~ ~ {Fuse:0}",
                "bedrock": "/execute at @e[type=arrow] run summon tnt ~ ~ ~",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "silverfish_spawner",
                "name": "Silverfish Swarm",
                "type": "grief",
                "desc": "Spawns 5 high-speed, aggressive Silverfish directly on top of the target's head.",
                "java_modern": "/execute at [TARGET] run summon minecraft:silverfish ~ ~ ~",
                "java_legacy": "/execute at [TARGET] run summon silverfish ~ ~ ~",
                "bedrock": "/execute at [TARGET] run summon silverfish ~ ~ ~",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "blindness_strike",
                "name": "Extreme Blindness Spike",
                "type": "grief",
                "desc": "Applies high-duration server-wide blindness (30 seconds) to completely black out their vision.",
                "java_modern": "/effect give [TARGET] minecraft:blindness 30 1",
                "java_legacy": "/effect give [TARGET] blindness 30 1",
                "bedrock": "/effect [TARGET] blindness 30 1",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "fake_timeout",
                "name": "Fake Disconnect Screen",
                "type": "harmless",
                "desc": "Sends a fake network disconnect/timeout system message in red font to spark connection panic.",
                "java_modern": "/tellraw [TARGET] {\"text\":\"Connection timed out: server is shutting down.\",\"color\":\"red\"}",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"Connection timed out: server is shutting down.\",\"color\":\"red\"}",
                "bedrock": "/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§cConnection timed out: server is shutting down.\"}]}",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "slow_motion",
                "name": "Slow Motion Trap",
                "type": "grief",
                "desc": "Inflicts absolute extreme slowness and mining fatigue, making their gameplay crawl in slow-motion.",
                "java_modern": "/effect give [TARGET] minecraft:slowness 20 10\n/effect give [TARGET] minecraft:mining_fatigue 20 10",
                "java_legacy": "/effect give [TARGET] slowness 20 10\n/effect give [TARGET] mining_fatigue 20 10",
                "bedrock": "/effect [TARGET] slowness 20 10\n/effect [TARGET] mining_fatigue 20 10",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "levitation_void",
                "name": "Anti-Gravity Void",
                "type": "grief",
                "desc": "Shoots the target into the stratosphere with extreme levitation and locks them high above the ground.",
                "java_modern": "/effect give [TARGET] minecraft:levitation 10 20",
                "java_legacy": "/effect give [TARGET] levitation 10 20",
                "bedrock": "/effect [TARGET] levitation 10 20",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "wood_pecker",
                "name": "Subtle Wood Pecker",
                "type": "harmless",
                "desc": "Plays a very quiet wood hit sound in the target's ears, simulating a woodpecker on their base.",
                "java_modern": "/playsound minecraft:block.wood.hit player [TARGET] ~ ~ ~ 0.2 1.5",
                "java_legacy": "/playsound block.wood.hit player [TARGET] ~ ~ ~ 0.2 1.5",
                "bedrock": "/playsound hit.wood [TARGET] ~ ~ ~ 0.2 1.5",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "bat_flutter",
                "name": "Subtle Bat Wings",
                "type": "harmless",
                "desc": "Simulates bat wing flutter noises in their immediate proximity to make them think one is trapped in their walls.",
                "java_modern": "/playsound minecraft:entity.bat.loop player [TARGET] ~ ~ ~ 0.3 1.1",
                "java_legacy": "/playsound entity.bat.loop player [TARGET] ~ ~ ~ 0.3 1.1",
                "bedrock": "/playsound mob.bat.takeoff [TARGET] ~ ~ ~ 0.3 1.1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "fake_chat_lag",
                "name": "Fake Server Connection Lag",
                "type": "harmless",
                "desc": "Fakes a grey system message warning them of extremely high server latency spikes.",
                "java_modern": "/tellraw [TARGET] {\"text\":\"[Server] Warning: Latency spike detected (842ms)\",\"color\":\"gray\"}",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"[Server] Warning: Latency spike detected (842ms)\",\"color\":\"gray\"}",
                "bedrock": "/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§7[Server] Warning: Latency spike detected (842ms)\"}]}",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "camera_drift",
                "name": "Subtle Mouse Drift",
                "type": "harmless",
                "desc": "Slightly rotates the player's camera pitch and yaw by a fraction of a degree, simulating mouse dust.",
                "java_modern": "/execute as [TARGET] at @s run tp @s ~ ~ ~ ~0.25 ~0.2",
                "java_legacy": "/execute as [TARGET] at @s run tp @s ~ ~ ~ ~0.25 ~0.2",
                "bedrock": "/execute as [TARGET] at @s run tp @s ~ ~ ~ ~0.25 ~0.2",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "item_repulsion",
                "name": "Hovering Item Repulsion",
                "type": "grief",
                "desc": "Constantly teleports dropped block items 0.1 blocks upwards whenever the target tries to pick them up.",
                "java_modern": "/execute as @e[type=minecraft:item,distance=..2.5] at @s run tp @s ~ ~0.1 ~",
                "java_legacy": "/execute as @e[type=item,distance=..2.5] at @s run tp @s ~ ~0.1 ~",
                "bedrock": "/execute as @e[type=item,r=2] run tp @s ~ ~0.1 ~",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "silent_footstep",
                "name": "Fake Grass Footstep",
                "type": "harmless",
                "desc": "Plays soft grass stepping sounds behind them while they are actually walking on solid stone.",
                "java_modern": "/execute as [TARGET] at @s if block ~ ~-1 ~ #minecraft:base_stone_overworld run playsound minecraft:block.grass.step player @s ~ ~-1 ~ 0.4 1",
                "java_legacy": "/execute as [TARGET] at @s run playsound block.grass.step player @s ~ ~-1 ~ 0.4 1",
                "bedrock": "/execute as [TARGET] at @s run playsound step.grass [TARGET] ~ ~-1 ~ 0.4",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "warden_dim",
                "name": "Subtle Screen Dimming",
                "type": "harmless",
                "desc": "Applies a short Warden darkness overlay pulse without showing any potion particle effects.",
                "java_modern": "/effect give [TARGET] minecraft:darkness 3 0 true",
                "java_legacy": "/effect give [TARGET] darkness 3 0 true",
                "bedrock": "/effect [TARGET] darkness 3 0 true",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "fake_fall",
                "name": "Spooky Ceiling Thud",
                "type": "harmless",
                "desc": "Plays a heavy rock impact landing sound right above their head to make them think a block fell.",
                "java_modern": "/playsound minecraft:block.stone.fall player [TARGET] ~ ~ ~ 0.5 0.7",
                "java_legacy": "/playsound block.stone.fall player [TARGET] ~ ~ ~ 0.5 0.7",
                "bedrock": "/playsound fall.stone [TARGET] ~ ~ ~ 0.5 0.7",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "torch_snuffer",
                "name": "Subtle Torch Snuffer",
                "type": "grief",
                "desc": "Extinguishes and deletes any placed wall/floor Torches within 2 blocks of the target player.",
                "java_modern": "/execute at [TARGET] run fill ~-2 ~-1 ~-2 ~2 ~1 ~2 minecraft:air replace minecraft:torch",
                "java_legacy": "/execute at [TARGET] run fill ~-2 ~-1 ~-2 ~2 ~1 ~2 air replace torch",
                "bedrock": "/execute at [TARGET] run fill ~-2 ~-1 ~-2 ~2 ~1 ~2 air replace torch",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "phantom_raid",
                "name": "Silent Phantom Swarm",
                "type": "grief",
                "desc": "Summons 2 completely silent Flying Phantoms in the high cloud level directly above them.",
                "java_modern": "/summon minecraft:phantom ~ ~15 ~ {Silent:1b,Size:1}\n/summon minecraft:phantom ~ ~16 ~ {Silent:1b,Size:1}",
                "java_legacy": "/summon phantom ~ ~15 ~ {Silent:1b,Size:1}\n/summon phantom ~ ~16 ~ {Silent:1b,Size:1}",
                "bedrock": "/summon phantom ~ ~15 ~\n/summon phantom ~ ~16 ~",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "fake_dragon_death",
                "name": "Ender Dragon Death Panic",
                "type": "harmless",
                "desc": "Sounds the booming global sound of the Ender Dragon dying directly to the target's coordinates.",
                "java_modern": "/playsound minecraft:entity.ender_dragon.death master [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound entity.ender_dragon.death master [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound mob.enderdragon.death [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "lava_paranoia",
                "name": "Quiet Lava Popping",
                "type": "harmless",
                "desc": "Plays the quiet crackle pop sounds of hot lava pools directly inside their ears.",
                "java_modern": "/playsound minecraft:block.lava.pop player [TARGET] ~ ~ ~ 0.4 1",
                "java_legacy": "/playsound block.lava.pop player [TARGET] ~ ~ ~ 0.4 1",
                "bedrock": "/playsound block.lava.lava [TARGET] ~ ~ ~ 0.4",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "biome_swamp",
                "name": "Swamp Biome Shifter",
                "type": "grief",
                "desc": "Converts the local 10x10 chunk biome coordinates to Swamp, permanently muddying grass/water.",
                "java_modern": "/fillbiome ~-5 ~-5 ~-5 ~5 ~5 ~5 minecraft:swamp",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"[Biome shifting requires modern Java 1.20+]\",\"color\":\"red\"}",
                "bedrock": "/fillbiome ~-5 ~-5 ~-5 ~5 ~5 ~5 swamp",
                "requires_command_block": true
        },
        {
                "level": 5,
                "id": "ghost_tnt_primed",
                "name": "primed TNT Panic Trigger",
                "type": "grief",
                "desc": "Summons a primed TNT block with a very long 10-second fuse right next to them, causing instant panic.",
                "java_modern": "/execute at [TARGET] run summon minecraft:tnt ~ ~ ~ {Fuse:200}",
                "java_legacy": "/execute at [TARGET] run summon tnt ~ ~ ~ {Fuse:200}",
                "bedrock": "/execute at [TARGET] run summon tnt ~ ~ ~",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "infinite_xp_ding",
                "name": "XP Pickup Loop Noise",
                "type": "harmless",
                "desc": "Plays the loud ding sound of experience orb pickups repeatedly in their ears.",
                "java_modern": "/execute at [TARGET] run playsound minecraft:entity.experience_orb.pickup player [TARGET] ~ ~ ~ 0.5 1",
                "java_legacy": "/execute at [TARGET] run playsound entity.experience_orb.pickup player [TARGET] ~ ~ ~ 0.5 1",
                "bedrock": "/execute at [TARGET] run playsound random.levelup [TARGET] ~ ~ ~ 0.5 1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "phantom_swoop",
                "name": "Ghost Phantom Swoop",
                "type": "harmless",
                "desc": "Plays the terrifying swoop sound of an attacking phantom directly above their head, prompting them to look up in panic.",
                "java_modern": "/playsound minecraft:entity.phantom.swoop master [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound entity.phantom.swoop master [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound mob.phantom.swoop [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "bat_takeoff",
                "name": "Bat Flight Flutter",
                "type": "harmless",
                "desc": "Plays a quick burst of fluttering bat wings and bat squeaks near their head, simulating a roosting bat nesting in their hair.",
                "java_modern": "/playsound minecraft:entity.bat.takeoff master [TARGET] ~ ~ ~ 1 1.2\n/playsound minecraft:entity.bat.ambient master [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound entity.bat.takeoff master [TARGET] ~ ~ ~ 1 1.2\n/playsound entity.bat.ambient master [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound mob.bat.takeoff [TARGET] ~ ~ ~ 1 1.2\n/playsound mob.bat.say [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": true
        },
        {
                "level": 1,
                "id": "damp_torch",
                "name": "Damp Torch Fizzle",
                "type": "harmless",
                "desc": "Plays the realistic fizzle sound of a flame or torch getting extinguished with water directly under their feet.",
                "java_modern": "/playsound minecraft:block.fire.extinguish master [TARGET] ~ ~ ~ 0.8 1",
                "java_legacy": "/playsound block.fire.extinguish master [TARGET] ~ ~ ~ 0.8 1",
                "bedrock": "/playsound random.fizz [TARGET] ~ ~ ~ 0.8 1",
                "requires_command_block": false
        },
        {
                "level": 1,
                "id": "witch_chuckle",
                "name": "Ghostly Witch Giggle",
                "type": "harmless",
                "desc": "Plays a faint, spooky witch giggle sound 5 blocks behind them, suggesting an invisible witch is nearby.",
                "java_modern": "/execute at [TARGET] run playsound minecraft:entity.witch.ambient ambient [TARGET] ^ ^ ^-5 0.5 1",
                "java_legacy": "/execute at [TARGET] run playsound entity.witch.ambient ambient [TARGET] ^ ^ ^-5 0.5 1",
                "bedrock": "/execute at [TARGET] run playsound mob.witch.ambient [TARGET] ^ ^ ^-5 0.5 1",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "arrow_whiz",
                "name": "Phantom Sniper Shot",
                "type": "harmless",
                "desc": "Simulates a nearby arrow whizzing right past their ear with a high-pitched bow release sound.",
                "java_modern": "/playsound minecraft:entity.arrow.shoot master [TARGET] ~ ~1 ~ 1 1.6",
                "java_legacy": "/playsound entity.arrow.shoot master [TARGET] ~ ~1 ~ 1 1.6",
                "bedrock": "/playsound random.bow [TARGET] ~ ~1 ~ 1 1.6",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "totem_pop_sound",
                "name": "Fake Totem Pop",
                "type": "harmless",
                "desc": "Plays the distinctive golden crackling chime of a Totem of Undying popping, sending them into immediate inventory panic.",
                "java_modern": "/playsound minecraft:item.totem.use master [TARGET] ~ ~ ~ 0.9 0.9",
                "java_legacy": "/playsound item.totem.use master [TARGET] ~ ~ ~ 0.9 0.9",
                "bedrock": "/playsound random.totem [TARGET] ~ ~ ~ 0.9 0.9",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "creeper_fuse_distant",
                "name": "Distant Creeper Hiss",
                "type": "harmless",
                "desc": "Plays a slightly muffled Creeper fuse countdown sound 4 blocks behind them, creating a split-second jump scare.",
                "java_modern": "/execute at [TARGET] run playsound minecraft:entity.creeper.primed master [TARGET] ^ ^ ^-4 0.6 0.8",
                "java_legacy": "/execute at [TARGET] run playsound entity.creeper.primed master [TARGET] ^ ^ ^-4 0.6 0.8",
                "bedrock": "/execute at [TARGET] run playsound random.fuse [TARGET] ^ ^ ^-4 0.6 0.8",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "anvil_drop_distant",
                "name": "Falling Anvil Thud",
                "type": "harmless",
                "desc": "Plays a heavy falling anvil impact thud 4 blocks above them, triggering their shield and look-up reflex.",
                "java_modern": "/playsound minecraft:block.anvil.land master [TARGET] ~ ~4 ~ 0.4 1",
                "java_legacy": "/playsound block.anvil.land master [TARGET] ~ ~4 ~ 0.4 1",
                "bedrock": "/playsound random.anvil_land [TARGET] ~ ~4 ~ 0.4",
                "requires_command_block": false
        },
        {
                "level": 2,
                "id": "item_pusher",
                "name": "Inventory Repulsion Field",
                "type": "harmless",
                "desc": "Teleports dropped items nearby slightly away from the target, making it incredibly tedious to collect loot.",
                "java_modern": "/execute at [TARGET] run tp @e[type=minecraft:item,distance=..2.5] ~1 ~ ~1",
                "java_legacy": "/execute at [TARGET] run tp @e[type=item,r=2.5] ~1 ~ ~1",
                "bedrock": "/execute at [TARGET] run tp @e[type=item,r=2.5] ~1 ~ ~1",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "bee_swarm",
                "name": "Ghost Bee Swarm",
                "type": "harmless",
                "desc": "Simulates an angry hive of bees buzzing persistently in their ears, causing extreme auditory distraction.",
                "java_modern": "/playsound minecraft:entity.bee.loop master [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound entity.bee.loop master [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound mob.bee.loop [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "silverfish_crawl",
                "name": "Silverfish Infestation Sound",
                "type": "harmless",
                "desc": "Plays scurrying silverfish crawling footsteps and minor hisses directly under their feet.",
                "java_modern": "/playsound minecraft:entity.silverfish.step master [TARGET] ~ ~ ~ 0.8 1.2\n/playsound minecraft:entity.silverfish.ambient master [TARGET] ~ ~ ~ 0.8 1",
                "java_legacy": "/playsound entity.silverfish.step master [TARGET] ~ ~ ~ 0.8 1.2\n/playsound entity.silverfish.ambient master [TARGET] ~ ~ ~ 0.8 1",
                "bedrock": "/playsound mob.silverfish.step [TARGET] ~ ~ ~ 0.8 1.2\n/playsound mob.silverfish.say [TARGET] ~ ~ ~ 0.8 1",
                "requires_command_block": true
        },
        {
                "level": 3,
                "id": "ghast_screamer",
                "name": "Overworld Ghast Alert",
                "type": "harmless",
                "desc": "Plays a loud Ghast warning shriek and firing blast directly in their ears, simulating a portal spillover.",
                "java_modern": "/playsound minecraft:entity.ghast.warn master [TARGET] ~ ~ ~ 1 1\n/playsound minecraft:entity.ghast.shoot master [TARGET] ~ ~ ~ 1 1",
                "java_legacy": "/playsound entity.ghast.warn master [TARGET] ~ ~ ~ 1 1\n/playsound entity.ghast.shoot master [TARGET] ~ ~ ~ 1 1",
                "bedrock": "/playsound mob.ghast.charge [TARGET] ~ ~ ~ 1 1\n/playsound mob.ghast.fireball [TARGET] ~ ~ ~ 1 1",
                "requires_command_block": true
        },
        {
                "level": 3,
                "id": "chest_creaker",
                "name": "Creaking Chest Shadow",
                "type": "harmless",
                "desc": "Plays a slow creaking chest open sound right behind them, simulating a ghost opening storage vaults.",
                "java_modern": "/execute at [TARGET] run playsound minecraft:block.chest.open block [TARGET] ^ ^ ^-2 0.7 0.7",
                "java_legacy": "/execute at [TARGET] run playsound block.chest.open block [TARGET] ^ ^ ^-2 0.7 0.7",
                "bedrock": "/execute at [TARGET] run playsound random.chestopen [TARGET] ^ ^ ^-2 0.7 0.7",
                "requires_command_block": false
        },
        {
                "level": 3,
                "id": "sculk_shrieker_ambient",
                "name": "Sculk Vibration Scare",
                "type": "harmless",
                "desc": "Plays the clicking vibration of a sculk sensor followed by a distant shrieker cry, triggering Warden fears.",
                "java_modern": "/playsound minecraft:block.sculk_sensor.clicking master [TARGET] ~ ~ ~ 0.8 1\n/playsound minecraft:entity.warden.nearby_close master [TARGET] ~ ~ ~ 0.5 1",
                "java_legacy": "/playsound block.sculk_sensor.clicking master [TARGET] ~ ~ ~ 0.8 1\n/playsound entity.warden.nearby_close master [TARGET] ~ ~ ~ 0.5 1",
                "bedrock": "/playsound block.sculk_shrieker.shriek [TARGET] ~ ~ ~ 0.6 1",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "elder_guardian_curse",
                "name": "Elder Guardian jumpscare",
                "type": "harmless",
                "desc": "Plays the elder guardian curse chime and applies 1 second mining fatigue, flash-projecting the giant ghostly fish on their screen.",
                "java_modern": "/playsound minecraft:entity.elder_guardian.curse master [TARGET] ~ ~ ~ 1 1\n/effect give [TARGET] minecraft:mining_fatigue 1 0 true",
                "java_legacy": "/playsound entity.elder_guardian.curse master [TARGET] ~ ~ ~ 1 1\n/effect give [TARGET] mining_fatigue 1 0 true",
                "bedrock": "/playsound mob.elderguardian.curse [TARGET] ~ ~ ~ 1 1\n/effect [TARGET] mining_fatigue 1 0",
                "requires_command_block": true
        },
        {
                "level": 4,
                "id": "fake_diamond_advancement",
                "name": "Fake Dedication Achievement",
                "type": "harmless",
                "desc": "Sends a fake chat broadcast announcing the victim just completed a top-tier legendary netherite advancement.",
                "java_modern": "/tellraw @a [{\"selector\":\"[TARGET]\"},{\"text\":\" has made the advancement \",\"color\":\"white\"},{\"text\":\"[Cover Me in Debris]\",\"color\":\"purple\",\"hoverEvent\":{\"action\":\"show_text\",\"contents\":{\"text\":\"Complete Netherite armor set\"}}}]",
                "java_legacy": "/tellraw @a [{\"selector\":\"[TARGET]\"},{\"text\":\" has made the advancement \",\"color\":\"white\"},{\"text\":\"[Cover Me in Debris]\",\"color\":\"purple\"}]",
                "bedrock": "/tellraw @a {\"rawtext\":[{\"selector\":\"[TARGET]\"},{\"text\":\" has made the advancement §d[Cover Me in Debris]\"}]}",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "fake_op_whisper",
                "name": "Operator Status Revoked",
                "type": "harmless",
                "desc": "Spams a gray server system chat notifying them that they have been de-opped and can no longer command.",
                "java_modern": "/tellraw [TARGET] {\"text\":\"You are no longer server operator\",\"color\":\"gray\",\"italic\":true}",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"You are no longer server operator\",\"color\":\"gray\",\"italic\":true}",
                "bedrock": "/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§7§oYou are no longer server operator\"}]}",
                "requires_command_block": false
        },
        {
                "level": 4,
                "id": "lightning_strike_fake",
                "name": "Silent Lightning Bolt",
                "type": "harmless",
                "desc": "Spawns a massive lightning strike directly on their body but silences the damage, generating a brilliant screen flash.",
                "java_modern": "/execute at [TARGET] run summon minecraft:lightning_bolt ~ ~ ~ {Silent:1b}",
                "java_legacy": "/execute at [TARGET] run summon lightning_bolt ~ ~ ~ {Silent:1b}",
                "bedrock": "/execute at [TARGET] run summon lightning_bolt ~ ~ ~",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "item_void",
                "name": "Offhand Void Eraser",
                "type": "grief",
                "desc": "Clears their active offhand slot instantly, removing shields or weapons in the heat of combat.",
                "java_modern": "/item replace entity [TARGET] weapon.offhand with minecraft:air",
                "java_legacy": "/replaceitem entity [TARGET] slot.weapon.offhand 0 minecraft:air",
                "bedrock": "/replaceitem entity [TARGET] slot.weapon.offhand 0 air",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "fake_crash",
                "name": "Fake Connection Exception",
                "type": "harmless",
                "desc": "Sends a dark-red system message mimicking a severe Java IOException server connection reset.",
                "java_modern": "/tellraw [TARGET] {\"text\":\"Internal Exception: java.io.IOException: An existing connection was forcibly closed by the remote host.\",\"color\":\"dark_red\"}",
                "java_legacy": "/tellraw [TARGET] {\"text\":\"Internal Exception: java.io.IOException: An existing connection was forcibly closed by the remote host.\",\"color\":\"dark_red\"}",
                "bedrock": "/tellraw [TARGET] {\"rawtext\":[{\"text\":\"§4Internal Exception: java.io.IOException: Connection reset by peer.\"}]}",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "portal_spill",
                "name": "Nether Portal Hallucinations",
                "type": "harmless",
                "desc": "Plays continuous dark nether portal loop portals inside their ears, driving them to find the ghost portal.",
                "java_modern": "/playsound minecraft:block.portal.ambient master [TARGET] ~ ~ ~ 0.5 1",
                "java_legacy": "/playsound block.portal.ambient master [TARGET] ~ ~ ~ 0.5 1",
                "bedrock": "/playsound portal.portal [TARGET] ~ ~ ~ 0.5 1",
                "requires_command_block": false
        },
        {
                "level": 5,
                "id": "sudden_void",
                "name": "End Void Fall Simulator",
                "type": "harmless",
                "desc": "Applies a split-second darkness effect and plays a massive falling impact rush to mimic dropping into the End void.",
                "java_modern": "/effect give [TARGET] minecraft:darkness 1 0 true\n/playsound minecraft:entity.player.hurt_on_fire master [TARGET] ~ ~ ~ 0.5 1.5",
                "java_legacy": "/effect give [TARGET] darkness 1 0 true\n/playsound entity.player.hurt_on_fire master [TARGET] ~ ~ ~ 0.5 1.5",
                "bedrock": "/effect [TARGET] darkness 1 0\n/playsound damage.fallbig [TARGET] ~ ~ ~ 0.5 1.5",
                "requires_command_block": true
        }
],

    // Preserved Trolls Chains List
    trolls_chains: [
        {
                "id": "chain_antigravity",
                "name": "⛓️ Anti-Gravity Zone Sensor",
                "desc": "Constructs a repeating proximity block chain that traps the target in a zero-gravity levitating vortex with flap sounds.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:cloud ~ ~1 ~ 0.5 0.5 0.5 0.05 10"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/effect give [TARGET] minecraft:levitation 1 4 true"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/playsound minecraft:entity.phantom.flap ambient [TARGET] ~ ~ ~ 0.6 1"
                        }
                ]
        },
        {
                "id": "chain_obsidian_coffin",
                "name": "⛓️ Step-on-Grass Coffin Trap",
                "desc": "Deploys a repeating trigger block chain that instantly traps the victim inside a solid Obsidian block coffin the second they step on grass.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] if block ~ ~-1 ~ minecraft:grass_block run fill ~-1 ~-1 ~-1 ~1 ~2 ~1 minecraft:obsidian outline"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Conditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run fill ~ ~-1 ~ ~ ~ ~ minecraft:water"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Conditional",
                                "active": "Always Active",
                                "cmd": "/tellraw @a {\"text\":\"[TARGET] stepped on grass and was entombed!\",\"color\":\"red\"}"
                        }
                ]
        },
        {
                "id": "chain_stalker_creeper",
                "name": "⛓️ Invisible Creeper Stalker",
                "desc": "Sets up an active repeating block chain that keeps tele-transporting a silent invisible Creeper 2 blocks directly behind the player's head.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run tp @e[type=minecraft:creeper,tag=stalker,limit=1] ^ ^ ^-2"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run playsound minecraft:entity.creeper.primed ambient @p ~ ~ ~ 0.3 1"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute as [TARGET] run particle minecraft:smoke ~ ~1 ~ 0.2 0.2 0.2 0.02 5"
                        }
                ]
        },
        {
                "id": "chain_magnetic_void",
                "name": "⛓️ Drop Item Magnetic Void",
                "desc": "Lays down an active repeating block chain that pulls dropped weapons directly into the sky and vaporizes them instantly.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run tp @e[type=minecraft:item,distance=..6] ~ ~5 ~"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:portal ~ ~1 ~ 0.5 0.5 0.5 0.1 20"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run kill @e[type=minecraft:item,distance=..6]"
                        }
                ]
        },
        {
                "id": "chain_warden_heartbeat",
                "name": "⛓️ Warden Heartbeat Hunt",
                "desc": "Simulates the Warden hunting them down: pulse low darkness visual effects, emit loud thumping heartbeat plays, emit kinetic sonic blasts, and end with an echoing warden scream.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/playsound minecraft:entity.warden.heartbeat master [TARGET] ~ ~ ~ 1.2 0.8"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/effect give [TARGET] minecraft:darkness 4 0 true"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1"
                        },
                        {
                                "step": 4,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run playsound minecraft:entity.warden.roar master [TARGET] ~ ~ ~ 0.8 0.6"
                        }
                ]
        },
        {
                "id": "chain_lightning_magnet",
                "name": "⛓️ Sprinting Thunder Magnet",
                "desc": "Detonates silent thunder bolts directly behind them whenever they run, spawning glowing sparks and giving a dynamic kinetic speed buff.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run summon minecraft:lightning_bolt ^ ^ ^-4 {Silent:1b}"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:electric_spark ~ ~1 ~ 0.4 0.4 0.4 0.1 12"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/playsound minecraft:entity.lightning_bolt.thunder master [TARGET] ~ ~ ~ 0.5 1"
                        },
                        {
                                "step": 4,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/effect give [TARGET] minecraft:speed 2 4 true"
                        }
                ]
        },
        {
                "id": "chain_glitch_tp",
                "name": "⛓️ Packet Loss Glitch Drift",
                "desc": "Rotates and slips their position slightly back whenever they trigger the loop, emitting void enderman portals and fake console sync logs.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run tp [TARGET] ~ ~ ~ ~3 ~"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/playsound minecraft:entity.enderman.teleport master [TARGET] ~ ~ ~ 0.3 1.4"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:portal ~ ~1 ~ 0.3 0.3 0.3 0.05 6"
                        },
                        {
                                "step": 4,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/tellraw [TARGET] {\"text\":\"[System] Warning: High packet loss detected. Synced coordinate drift.\",\"color\":\"gray\"}"
                        }
                ]
        },
        {
                "id": "chain_floor_decay",
                "name": "⛓️ Stepping-Stone Floor Decay",
                "desc": "Causes standard Stone blocks directly beneath their feet to decay into Gravel blocks, play thud block hit warnings, then crumble to Sand and spawn heavy sand dust particles.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] if block ~ ~-1 ~ minecraft:stone run setblock ~ ~-1 ~ minecraft:gravel"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Conditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run playsound minecraft:block.gravel.hit master [TARGET] ~ ~-1 ~ 1 0.8"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] if block ~ ~-2 ~ minecraft:grass_block run setblock ~ ~-2 ~ minecraft:sand"
                        },
                        {
                                "step": 4,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:dust 0.6 0.5 0.4 1 ~ ~-1 ~ 0.3 0.1 0.3 0.01 10"
                        }
                ]
        },
        {
                "id": "chain_herobrine_ghost",
                "name": "⛓️ Herobrine Stalker Sighting",
                "desc": "Constructs a repeating chain that spawns a silent, invulnerable Herobrine figure (armor stand with custom skull) behind them. Rings ambient cave notes, emits dark soot, and safely kills it when they turn around.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] unless entity @e[tag=herobrine,distance=..15] run summon minecraft:armor_stand ^ ^1 ^-4 {Tags:[\"herobrine\"],Invisible:1b,ArmorItems:[{},{},{},{id:\"minecraft:player_head\",Count:1b,tag:{SkullOwner:\"MHF_Herobrine\"}}],DisabledSlots:2039583}"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] as @e[tag=herobrine] run tp @s ^ ^1 ^-4"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] if entity @e[tag=herobrine,age=..20] run playsound minecraft:ambient.cave master [TARGET] ~ ~ ~ 1 0.7"
                        },
                        {
                                "step": 4,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at @e[tag=herobrine] run particle minecraft:large_smoke ~ ~1.5 ~ 0.1 0.1 0.1 0.01 3"
                        },
                        {
                                "step": 5,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run kill @e[tag=herobrine,distance=..2.2]"
                        }
                ]
        },
        {
                "id": "chain_potato_clutter",
                "name": "⛓️ Poisonous Potato Clutterer",
                "desc": "Constantly spams poisonous potatoes into their inventory slots: forces their offhand item out of existence, plays squishing sounds, feeds hotbar slots, and releases toxic green particles.",
                "blocks": [
                        {
                                "step": 1,
                                "type": "Repeat",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/item replace entity [TARGET] weapon.offhand with minecraft:poisonous_potato"
                        },
                        {
                                "step": 2,
                                "type": "Chain",
                                "cond": "Conditional",
                                "active": "Always Active",
                                "cmd": "/playsound minecraft:entity.slime.squish master [TARGET] ~ ~ ~ 0.8 1"
                        },
                        {
                                "step": 3,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/give [TARGET] minecraft:poisonous_potato 1"
                        },
                        {
                                "step": 4,
                                "type": "Chain",
                                "cond": "Unconditional",
                                "active": "Always Active",
                                "cmd": "/execute at [TARGET] run particle minecraft:spore_blossom_air ~ ~1 ~ 0.4 0.4 0.4 0 5"
                        }
                ]
        }
],

    // Preserved Effects List
    effects: [
        {
                "id": "minecraft:speed",
                "name": "Speed",
                "numeric_id": 1,
                "icon": "🧪"
        },
        {
                "id": "minecraft:slowness",
                "name": "Slowness",
                "numeric_id": 2,
                "icon": "🧪"
        },
        {
                "id": "minecraft:haste",
                "name": "Haste",
                "numeric_id": 3,
                "icon": "🧪"
        },
        {
                "id": "minecraft:mining_fatigue",
                "name": "Mining Fatigue",
                "numeric_id": 4,
                "icon": "🧪"
        },
        {
                "id": "minecraft:strength",
                "name": "Strength",
                "numeric_id": 5,
                "icon": "🧪"
        },
        {
                "id": "minecraft:instant_health",
                "name": "Instant Health",
                "numeric_id": 6,
                "icon": "🧪"
        },
        {
                "id": "minecraft:instant_damage",
                "name": "Instant Damage",
                "numeric_id": 7,
                "icon": "🧪"
        },
        {
                "id": "minecraft:jump_boost",
                "name": "Jump Boost",
                "numeric_id": 8,
                "icon": "🧪"
        },
        {
                "id": "minecraft:nausea",
                "name": "Nausea",
                "numeric_id": 9,
                "icon": "🧪"
        },
        {
                "id": "minecraft:regeneration",
                "name": "Regeneration",
                "numeric_id": 10,
                "icon": "🧪"
        },
        {
                "id": "minecraft:resistance",
                "name": "Resistance",
                "numeric_id": 11,
                "icon": "🧪"
        },
        {
                "id": "minecraft:fire_resistance",
                "name": "Fire Resistance",
                "numeric_id": 12,
                "icon": "🧪"
        },
        {
                "id": "minecraft:water_breathing",
                "name": "Water Breathing",
                "numeric_id": 13,
                "icon": "🧪"
        },
        {
                "id": "minecraft:invisibility",
                "name": "Invisibility",
                "numeric_id": 14,
                "icon": "🧪"
        },
        {
                "id": "minecraft:blindness",
                "name": "Blindness",
                "numeric_id": 15,
                "icon": "🧪"
        },
        {
                "id": "minecraft:night_vision",
                "name": "Night Vision",
                "numeric_id": 16,
                "icon": "🧪"
        },
        {
                "id": "minecraft:hunger",
                "name": "Hunger",
                "numeric_id": 17,
                "icon": "🧪"
        },
        {
                "id": "minecraft:weakness",
                "name": "Weakness",
                "numeric_id": 18,
                "icon": "🧪"
        },
        {
                "id": "minecraft:poison",
                "name": "Poison",
                "numeric_id": 19,
                "icon": "🧪"
        },
        {
                "id": "minecraft:wither",
                "name": "Wither",
                "numeric_id": 20,
                "icon": "🧪"
        },
        {
                "id": "minecraft:health_boost",
                "name": "Health Boost",
                "numeric_id": 21,
                "icon": "🧪"
        },
        {
                "id": "minecraft:absorption",
                "name": "Absorption",
                "numeric_id": 22,
                "icon": "🧪"
        },
        {
                "id": "minecraft:saturation",
                "name": "Saturation",
                "numeric_id": 23,
                "icon": "🧪"
        },
        {
                "id": "minecraft:glowing",
                "name": "Glowing",
                "numeric_id": 24,
                "icon": "🧪"
        },
        {
                "id": "minecraft:levitation",
                "name": "Levitation",
                "numeric_id": 25,
                "icon": "🧪"
        },
        {
                "id": "minecraft:luck",
                "name": "Luck",
                "numeric_id": 26,
                "icon": "🧪"
        },
        {
                "id": "minecraft:bad_luck",
                "name": "Bad Luck",
                "numeric_id": 27,
                "icon": "🧪"
        },
        {
                "id": "minecraft:slow_falling",
                "name": "Slow Falling",
                "numeric_id": 28,
                "icon": "🧪"
        },
        {
                "id": "minecraft:conduit_power",
                "name": "Conduit Power",
                "numeric_id": 29,
                "icon": "🧪"
        },
        {
                "id": "minecraft:dolphins_grace",
                "name": "Dolphin's Grace",
                "numeric_id": 30,
                "icon": "🧪"
        },
        {
                "id": "minecraft:bad_omen",
                "name": "Bad Omen",
                "numeric_id": 31,
                "icon": "🧪"
        },
        {
                "id": "minecraft:hero_of_the_village",
                "name": "Hero of the Village",
                "numeric_id": 32,
                "icon": "🧪"
        },
        {
                "id": "minecraft:darkness",
                "name": "Darkness",
                "numeric_id": 33,
                "icon": "🧪"
        }
],

    // Preserved Particles List
    particles: [
        {
                "id": "minecraft:ambient_entity_effect",
                "name": "Ambient Entity Effect",
                "icon": "✨"
        },
        {
                "id": "minecraft:angry_villager",
                "name": "Angry Villager",
                "icon": "✨"
        },
        {
                "id": "minecraft:ash",
                "name": "Ash",
                "icon": "✨"
        },
        {
                "id": "minecraft:bubble",
                "name": "Bubble",
                "icon": "✨"
        },
        {
                "id": "minecraft:cherry_leaves",
                "name": "Cherry Leaves",
                "icon": "✨"
        },
        {
                "id": "minecraft:cloud",
                "name": "Cloud Dust",
                "icon": "✨"
        },
        {
                "id": "minecraft:compost",
                "name": "Compost",
                "icon": "✨"
        },
        {
                "id": "minecraft:crimson_spore",
                "name": "Crimson Spore",
                "icon": "✨"
        },
        {
                "id": "minecraft:damage_indicator",
                "name": "Damage Indicator",
                "icon": "✨"
        },
        {
                "id": "minecraft:dolphin",
                "name": "Dolphin",
                "icon": "✨"
        },
        {
                "id": "minecraft:dragon_breath",
                "name": "Dragon's Breath",
                "icon": "✨"
        },
        {
                "id": "minecraft:dripping_dripstone_lava",
                "name": "Dripping Lava",
                "icon": "✨"
        },
        {
                "id": "minecraft:dripping_dripstone_water",
                "name": "Dripping Water",
                "icon": "✨"
        },
        {
                "id": "minecraft:dripping_lava",
                "name": "Dripping Lava Stream",
                "icon": "✨"
        },
        {
                "id": "minecraft:dripping_water",
                "name": "Dripping Water Stream",
                "icon": "✨"
        },
        {
                "id": "minecraft:dust",
                "name": "Dust",
                "icon": "✨"
        },
        {
                "id": "minecraft:electric_spark",
                "name": "Electric Spark",
                "icon": "✨"
        },
        {
                "id": "minecraft:enchanted_hit",
                "name": "Enchanted Hit",
                "icon": "✨"
        },
        {
                "id": "minecraft:end_rod",
                "name": "End Rod",
                "icon": "✨"
        },
        {
                "id": "minecraft:entity_effect",
                "name": "Entity Effect",
                "icon": "✨"
        },
        {
                "id": "minecraft:explosion",
                "name": "Explosion",
                "icon": "✨"
        },
        {
                "id": "minecraft:explosion_emitter",
                "name": "Huge Explosion",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_dripstone_lava",
                "name": "Falling Lava",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_dripstone_water",
                "name": "Falling Water",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_dust",
                "name": "Falling Dust",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_honey",
                "name": "Falling Honey",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_lava",
                "name": "Falling Lava Stream",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_nectar",
                "name": "Falling Nectar",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_spore_blossom",
                "name": "Falling Spore Blossom",
                "icon": "✨"
        },
        {
                "id": "minecraft:falling_water",
                "name": "Falling Water Stream",
                "icon": "✨"
        },
        {
                "id": "minecraft:firework",
                "name": "Firework Spark",
                "icon": "✨"
        },
        {
                "id": "minecraft:fishing",
                "name": "Fishing Line",
                "icon": "✨"
        },
        {
                "id": "minecraft:flame",
                "name": "Fire Flame",
                "icon": "✨"
        },
        {
                "id": "minecraft:glow",
                "name": "Glow",
                "icon": "✨"
        },
        {
                "id": "minecraft:glow_squid_ink",
                "name": "Glow Squid Ink",
                "icon": "✨"
        },
        {
                "id": "minecraft:happy_villager",
                "name": "Happy Villager",
                "icon": "✨"
        },
        {
                "id": "minecraft:heart",
                "name": "Red Hearts",
                "icon": "✨"
        },
        {
                "id": "minecraft:instant_effect",
                "name": "Instant Effect",
                "icon": "✨"
        },
        {
                "id": "minecraft:item_slime",
                "name": "Slime Bits",
                "icon": "✨"
        },
        {
                "id": "minecraft:item_snowball",
                "name": "Snowball Bits",
                "icon": "✨"
        },
        {
                "id": "minecraft:large_smoke",
                "name": "Large Smoke",
                "icon": "✨"
        },
        {
                "id": "minecraft:lava",
                "name": "Lava Spark",
                "icon": "✨"
        },
        {
                "id": "minecraft:mycelium",
                "name": "Mycelium spores",
                "icon": "✨"
        },
        {
                "id": "minecraft:nautilus",
                "name": "Nautilus Spores",
                "icon": "✨"
        },
        {
                "id": "minecraft:note",
                "name": "Music Note",
                "icon": "✨"
        },
        {
                "id": "minecraft:poof",
                "name": "Poof Dust",
                "icon": "✨"
        },
        {
                "id": "minecraft:portal",
                "name": "Portal Particle",
                "icon": "✨"
        },
        {
                "id": "minecraft:rain",
                "name": "Rain Splashes",
                "icon": "✨"
        },
        {
                "id": "minecraft:sculk_charge",
                "name": "Sculk Charge",
                "icon": "✨"
        },
        {
                "id": "minecraft:sculk_charge_pop",
                "name": "Sculk Charge Pop",
                "icon": "✨"
        },
        {
                "id": "minecraft:sculk_soul",
                "name": "Sculk Soul",
                "icon": "✨"
        },
        {
                "id": "minecraft:shriek",
                "name": "Sonic Shriek",
                "icon": "✨"
        },
        {
                "id": "minecraft:small_flame",
                "name": "Small Flame",
                "icon": "✨"
        },
        {
                "id": "minecraft:snowflake",
                "name": "Snowflake",
                "icon": "✨"
        },
        {
                "id": "minecraft:sonic_boom",
                "name": "Sonic Boom Wave",
                "icon": "✨"
        },
        {
                "id": "minecraft:soul",
                "name": "Soul Sparkle",
                "icon": "✨"
        },
        {
                "id": "minecraft:soul_fire_flame",
                "name": "Soul Fire Flame",
                "icon": "✨"
        },
        {
                "id": "minecraft:spit",
                "name": "Llama Spit",
                "icon": "✨"
        },
        {
                "id": "minecraft:spore_blossom_air",
                "name": "Spore Blossom Air",
                "icon": "✨"
        },
        {
                "id": "minecraft:squid_ink",
                "name": "Squid Ink",
                "icon": "✨"
        },
        {
                "id": "minecraft:sweep_attack",
                "name": "Sword Sweep Attack",
                "icon": "✨"
        },
        {
                "id": "minecraft:totem_of_undying",
                "name": "Totem Sparkles",
                "icon": "✨"
        },
        {
                "id": "minecraft:underwater",
                "name": "Underwater Bubbles",
                "icon": "✨"
        },
        {
                "id": "minecraft:warped_spore",
                "name": "Warped Spore",
                "icon": "✨"
        },
        {
                "id": "minecraft:wax_off",
                "name": "Wax Off",
                "icon": "✨"
        },
        {
                "id": "minecraft:wax_on",
                "name": "Wax On",
                "icon": "✨"
        },
        {
                "id": "minecraft:white_ash",
                "name": "White Ash",
                "icon": "✨"
        },
        {
                "id": "minecraft:witch",
                "name": "Witch Magic Sparkles",
                "icon": "✨"
        }
],

    // Preserved Sounds List
    sounds: [
        {
                "id": "minecraft:entity.creeper.primed",
                "name": "Creeper Primed (Fuse)",
                "icon": "🔊"
        },
        {
                "id": "minecraft:ambient.cave",
                "name": "Cave Ambient Spook",
                "icon": "🔊"
        },
        {
                "id": "minecraft:block.anvil.land",
                "name": "Anvil Impact",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.ghast.warn",
                "name": "Ghast Scream",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.lightning_bolt.thunder",
                "name": "Thunder Bolt",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.ender_dragon.death",
                "name": "Ender Dragon Death",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.warden.heartbeat",
                "name": "Warden Heartbeat",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.phantom.swoop",
                "name": "Phantom Swoop",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.witch.ambient",
                "name": "Witch Ambient Giggle",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.enderman.teleport",
                "name": "Enderman Teleport",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.enderman.scream",
                "name": "Enderman Angry Scream",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.zombie.ambient",
                "name": "Zombie Groan",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.skeleton.ambient",
                "name": "Skeleton Bone Rattle",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.wolf.growl",
                "name": "Wolf Growl",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.warden.sonic_boom",
                "name": "Warden Sonic Boom Charge",
                "icon": "🔊"
        },
        {
                "id": "minecraft:block.tnt.primed",
                "name": "TNT Primed Hiss",
                "icon": "🔊"
        },
        {
                "id": "minecraft:entity.player.hurt",
                "name": "Player Hurt Sound",
                "icon": "🔊"
        }
],

    // Preserved Execute Slots List
    execute_slots: [
        {
                "id": "weapon.mainhand",
                "name": "Main Hand (Weapon)",
                "icon": "⚔️"
        },
        {
                "id": "weapon.offhand",
                "name": "Offhand Slot",
                "icon": "🛡️"
        },
        {
                "id": "armor.head",
                "name": "Helmet Slot",
                "icon": "🪖"
        },
        {
                "id": "armor.chest",
                "name": "Chestplate Slot",
                "icon": "👕"
        },
        {
                "id": "armor.legs",
                "name": "Leggings Slot",
                "icon": "👖"
        },
        {
                "id": "armor.feet",
                "name": "Boots Slot",
                "icon": "🥾"
        }
],

    // Preserved Biomes List
    biomes: [
        {
                "id": "minecraft:plains",
                "name": "Plains",
                "icon": "🌱",
                "desc": "Grassland biome with open views, passive mobs, and occasional oak/birch trees."
        },
        {
                "id": "minecraft:desert",
                "name": "Desert",
                "icon": "🌵",
                "desc": "Dry, sandy biome with cacti, dead bushes, sandstone structures, and husk spawn overrides."
        },
        {
                "id": "minecraft:forest",
                "name": "Forest",
                "icon": "🌳",
                "desc": "Dense tree biome featuring oak and birch trees, wolves, and mushrooms."
        },
        {
                "id": "minecraft:taiga",
                "name": "Taiga",
                "icon": "🌲",
                "desc": "Cold biome with spruce trees, sweet berry bushes, foxes, and wolves."
        },
        {
                "id": "minecraft:snowy_plains",
                "name": "Snowy Plains",
                "icon": "❄️",
                "desc": "Vast snowy fields spawning strays, polar bears, and rabbits."
        },
        {
                "id": "minecraft:swamp",
                "name": "Swamp",
                "icon": "🐊",
                "desc": "Murky waters spawning slime at night, boggy trees, blue orchids, and witch huts."
        },
        {
                "id": "minecraft:jungle",
                "name": "Jungle",
                "icon": "🌴",
                "desc": "Lush tropical jungle with towering trees, cocoa beans, ocelots, parrots, and pandas."
        },
        {
                "id": "minecraft:savanna",
                "name": "Savanna",
                "icon": "🦁",
                "desc": "Dry grassland featuring acacia trees, llamas, horses, and villages."
        },
        {
                "id": "minecraft:badlands",
                "name": "Badlands",
                "icon": "🏜️",
                "desc": "Colorful terracotta mounds with extra gold ore generation and mineshafts."
        },
        {
                "id": "minecraft:meadow",
                "name": "Meadow",
                "icon": "🌸",
                "desc": "Grassy plateau filled with flowers, sheep, and bees."
        },
        {
                "id": "minecraft:grove",
                "name": "Grove",
                "icon": "❄️",
                "desc": "Spruce forest covered in snow, wolves, and rabbits."
        },
        {
                "id": "minecraft:snowy_slopes",
                "name": "Snowy Slopes",
                "icon": "🏔️",
                "desc": "Slopes covered in snow and ice, spawning goats."
        },
        {
                "id": "minecraft:jagged_peaks",
                "name": "Jagged Peaks",
                "icon": "🏔️",
                "desc": "Tall mountains capped with snow, stone, and goats."
        },
        {
                "id": "minecraft:frozen_peaks",
                "name": "Frozen Peaks",
                "icon": "🏔️",
                "desc": "Ice-covered mountain peaks spawning goats."
        },
        {
                "id": "minecraft:stony_peaks",
                "name": "Stony Peaks",
                "icon": "⛰️",
                "desc": "Mountain tops containing stone, calcite, and no snow."
        },
        {
                "id": "minecraft:cherry_grove",
                "name": "Cherry Grove",
                "icon": "🌸",
                "desc": "Mountain biome covered in pink cherry blossom petals and sheep."
        },
        {
                "id": "minecraft:birch_forest",
                "name": "Birch Forest",
                "icon": "🌳",
                "desc": "Pure birch trees, flowers, and peaceful animals."
        },
        {
                "id": "minecraft:dark_forest",
                "name": "Dark Forest",
                "icon": "🍄",
                "desc": "Dense dark oak forest spawning hostile mobs even during daytime, containing Woodland Mansions."
        },
        {
                "id": "minecraft:mangrove_swamp",
                "name": "Mangrove Swamp",
                "icon": "🐊",
                "desc": "Warm swamp featuring mangrove trees, mud blocks, and frogs."
        },
        {
                "id": "minecraft:snowy_taiga",
                "name": "Snowy Taiga",
                "icon": "❄️",
                "desc": "Cold spruce forest covered in snow."
        },
        {
                "id": "minecraft:old_growth_pine_taiga",
                "name": "Old Growth Pine Taiga",
                "icon": "🌲",
                "desc": "Spruce biome with giant pine trees, podzol, and mossy cobblestone."
        },
        {
                "id": "minecraft:old_growth_birch_forest",
                "name": "Old Growth Birch Forest",
                "icon": "🌳",
                "desc": "Forest with tall birch trees."
        },
        {
                "id": "minecraft:ocean",
                "name": "Ocean",
                "icon": "🌊",
                "desc": "Standard ocean containing kelp, fish, and dolphins."
        },
        {
                "id": "minecraft:warm_ocean",
                "name": "Warm Ocean",
                "icon": "🐠",
                "desc": "Shallow, warm water biome with coral reefs and sea pickles."
        },
        {
                "id": "minecraft:lukewarm_ocean",
                "name": "Lukewarm Ocean",
                "icon": "🐬",
                "desc": "Deep, greenish waters with seagrass and fish."
        },
        {
                "id": "minecraft:cold_ocean",
                "name": "Cold Ocean",
                "icon": "🐟",
                "desc": "Deep, cold waters with cod and salmon."
        },
        {
                "id": "minecraft:frozen_ocean",
                "name": "Frozen Ocean",
                "icon": "🧊",
                "desc": "Ice sheet covered ocean spawning polar bears and strays."
        },
        {
                "id": "minecraft:mushroom_fields",
                "name": "Mushroom Fields",
                "icon": "🍄",
                "desc": "Rare biome covered in mycelium, giant mushrooms, and mooshrooms. No hostile mobs can spawn here."
        },
        {
                "id": "minecraft:deep_dark",
                "name": "Deep Dark",
                "icon": "👁️",
                "desc": "Deep cavern biome filled with sculk blocks, sculk sensors, and the Warden."
        },
        {
                "id": "minecraft:nether_wastes",
                "name": "Nether Wastes",
                "icon": "🔥",
                "desc": "The primary Nether biome of netherrack, magma blocks, ghasts, and piglins."
        },
        {
                "id": "minecraft:soul_sand_valley",
                "name": "Soul Sand Valley",
                "icon": "💀",
                "desc": "Nether valley covered in soul sand, soul soil, basalt pillars, skeletons, and ghasts."
        },
        {
                "id": "minecraft:crimson_forest",
                "name": "Crimson Forest",
                "icon": "🍄",
                "desc": "Red Nether forest containing crimson fungi, hoglins, and piglins."
        },
        {
                "id": "minecraft:warped_forest",
                "name": "Warped Forest",
                "icon": "🍄",
                "desc": "Blue Nether forest containing warped fungi, endermen, and no hostile piglins."
        },
        {
                "id": "minecraft:basalt_deltas",
                "name": "Basalt Deltas",
                "icon": "🌋",
                "desc": "Volcanic Nether biome filled with basalt, blackstone, ash particles, and magma cubes."
        },
        {
                "id": "minecraft:the_end",
                "name": "The End",
                "icon": "🌌",
                "desc": "The barren dimension of end stone, obsidian towers, endermen, and the Ender Dragon."
        }
],

    // Preserved Structures List
    structures: [
        {
                "id": "minecraft:ancient_city",
                "name": "Ancient City",
                "icon": "🏛️",
                "desc": "Mammoth underground ruins in the Deep Dark containing sculk shriekers and high-loot chest rooms."
        },
        {
                "id": "minecraft:bastion_remnant",
                "name": "Bastion Remnant",
                "icon": "🏰",
                "desc": "Large obsidian and blackstone castles in the Nether guarded by Piglin Brutes."
        },
        {
                "id": "minecraft:buried_treasure",
                "name": "Buried Treasure",
                "icon": "🪙",
                "desc": "Hidden chests containing Heart of the Sea and gold, located on beaches."
        },
        {
                "id": "minecraft:desert_pyramid",
                "name": "Desert Pyramid",
                "icon": "🏜️",
                "desc": "Sandstone temple containing a treasure chamber with a TNT trap."
        },
        {
                "id": "minecraft:end_city",
                "name": "End City",
                "icon": "🏰",
                "desc": "Tall towers in the outer islands of the End containing Shulkers, Elytras, and dragon heads."
        },
        {
                "id": "minecraft:fortress",
                "name": "Nether Fortress",
                "icon": "🌉",
                "desc": "Nether bridge network filled with Blaze spawners and Wither Skeletons."
        },
        {
                "id": "minecraft:igloo",
                "name": "Igloo",
                "icon": "❄️",
                "desc": "Snow huts containing a bed and occasionally a basement with a zombie cure lab."
        },
        {
                "id": "minecraft:jungle_pyramid",
                "name": "Jungle Pyramid",
                "icon": "🏺",
                "desc": "Mossy cobblestone temple containing tripwire traps and puzzle chests."
        },
        {
                "id": "minecraft:mansion",
                "name": "Woodland Mansion",
                "icon": "🏠",
                "desc": "Large woodland estate filled with Evokers, Vindicators, and hidden rooms."
        },
        {
                "id": "minecraft:mineshaft",
                "name": "Abandoned Mineshaft",
                "icon": "🕸️",
                "desc": "Abandoned mine tunnels containing rails, cave spider spawners, and loot chest minecarts."
        },
        {
                "id": "minecraft:monument",
                "name": "Ocean Monument",
                "icon": "🔱",
                "desc": "Submerged ocean temple filled with Guardians, Elder Guardians, and gold blocks."
        },
        {
                "id": "minecraft:nether_fossil",
                "name": "Nether Fossil",
                "icon": "🦴",
                "desc": "Skeletal bone structures found throughout Soul Sand Valleys in the Nether."
        },
        {
                "id": "minecraft:ocean_ruin",
                "name": "Ocean Ruin",
                "icon": "🌊",
                "desc": "Submerged stone or sandstone structures containing Drowned and sniffer eggs in suspicious sand."
        },
        {
                "id": "minecraft:pillager_outpost",
                "name": "Pillager Outpost",
                "icon": "🏹",
                "desc": "Cobblestone tower manned by Pillagers, containing an iron cage and loot chest."
        },
        {
                "id": "minecraft:ruined_portal",
                "name": "Ruined Portal",
                "icon": "🔥",
                "desc": "Damaged obsidian portals surrounded by netherrack and magma blocks in both dimensions."
        },
        {
                "id": "minecraft:shipwreck",
                "name": "Shipwreck",
                "icon": "⛵",
                "desc": "Sunken oak or spruce vessels containing map chests, treasure chests, and supply chests."
        },
        {
                "id": "minecraft:stronghold",
                "name": "Stronghold",
                "icon": "🗝️",
                "desc": "Underground stone brick fortresses containing libraries, chest rooms, and the End Portal."
        },
        {
                "id": "minecraft:swamp_hut",
                "name": "Swamp Hut (Witch Hut)",
                "icon": "🧹",
                "desc": "Raised wooden huts occupied by a Witch and a black Cat."
        },
        {
                "id": "minecraft:trail_ruins",
                "name": "Trail Ruins",
                "icon": "🧱",
                "desc": "Partially buried ancient structures composed of gravel, terracotta, and suspicious clay."
        },
        {
                "id": "minecraft:village",
                "name": "Village",
                "icon": "🏡",
                "desc": "Settlement containing houses, job blocks, Villagers, and Iron Golems. Available in plains, desert, savanna, taiga, and snowy plains."
        }
],

    // Preserved Commands List
    commands: [
        {
                "id": "/give",
                "name": "/give",
                "icon": "📜",
                "desc": "Grants specific items with custom NBT / components to players.",
                "meta": "/give <player> <item> [count]"
        },
        {
                "id": "/summon",
                "name": "/summon",
                "icon": "📜",
                "desc": "Spawns a custom living mob or object at specified coordinates.",
                "meta": "/summon <entity> [pos] [nbt]"
        },
        {
                "id": "/execute",
                "name": "/execute",
                "icon": "📜",
                "desc": "Conditional compiler that executes commands on behalf of other entities or under environmental tests.",
                "meta": "/execute <subcommands> run <command>"
        },
        {
                "id": "/effect",
                "name": "/effect",
                "icon": "📜",
                "desc": "Modifies active potion effects and amplifiers on players or mobs.",
                "meta": "/effect <give|clear> <player> <effect> [seconds] [amplifier]"
        },
        {
                "id": "/tp",
                "name": "/tp",
                "icon": "📜",
                "desc": "Teleports players or entities to coordinates or another target.",
                "meta": "/tp [target] <destination>"
        },
        {
                "id": "/setblock",
                "name": "/setblock",
                "icon": "📜",
                "desc": "Changes a single block at specified coordinates to another block type.",
                "meta": "/setblock <pos> <block> [destroy|keep|replace]"
        },
        {
                "id": "/fill",
                "name": "/fill",
                "icon": "📜",
                "desc": "Fills a cubic region of blocks with a specified block type.",
                "meta": "/fill <from> <to> <block> [replace|destroy|keep]"
        },
        {
                "id": "/gamerule",
                "name": "/gamerule",
                "icon": "📜",
                "desc": "Toggles global server configuration parameters like daylight cycle, mob griefing, and inventory keeping.",
                "meta": "/gamerule <rule> [value]"
        },
        {
                "id": "/kill",
                "name": "/kill",
                "icon": "📜",
                "desc": "Instantly inflicts lethal damage to players or selected living mobs.",
                "meta": "/kill [target]"
        },
        {
                "id": "/gamemode",
                "name": "/gamemode",
                "icon": "📜",
                "desc": "Sets the target player's gameplay interaction mode.",
                "meta": "/gamemode <survival|creative|adventure|spectator> [player]"
        },
        {
                "id": "/attribute",
                "name": "/attribute",
                "icon": "📜",
                "desc": "Gets or modifies attribute modifiers (like base health or movement speed) of entities in real time.",
                "meta": "/attribute <target> <attribute> <get|base|modifier> ..."
        },
        {
                "id": "/clear",
                "name": "/clear",
                "icon": "📜",
                "desc": "Empties items matching filters from target players' inventories.",
                "meta": "/clear [player] [item] [maxCount]"
        },
        {
                "id": "/difficulty",
                "name": "/difficulty",
                "icon": "📜",
                "desc": "Modifies global combat challenge parameters and mob aggressiveness.",
                "meta": "/difficulty <peaceful|easy|normal|hard>"
        },
        {
                "id": "/enchant",
                "name": "/enchant",
                "icon": "📜",
                "desc": "Applies compatible enchantments directly to the item held in the player's main hand.",
                "meta": "/enchant <player> <enchantment> [level]"
        },
        {
                "id": "/particle",
                "name": "/particle",
                "icon": "📜",
                "desc": "Spawns custom cosmetic visual particles in the environment.",
                "meta": "/particle <name> [pos] [speed] [count]"
        },
        {
                "id": "/playsound",
                "name": "/playsound",
                "icon": "📜",
                "desc": "Plays a sound effect to selected players from a coordinate source.",
                "meta": "/playsound <sound> <source> <targets> [pos]"
        },
        {
                "id": "/seed",
                "name": "/seed",
                "icon": "📜",
                "desc": "Displays the world's generation integer seed in the chat console.",
                "meta": "/seed"
        },
        {
                "id": "/time",
                "name": "/time",
                "icon": "📜",
                "desc": "Changes or queries the daylight time cycle of the current world.",
                "meta": "/time <set|add|query> <value>"
        },
        {
                "id": "/weather",
                "name": "/weather",
                "icon": "📜",
                "desc": "Alters weather states of the world for a set time.",
                "meta": "/weather <clear|rain|thunder> [duration]"
        },
        {
                "id": "/xp",
                "name": "/xp",
                "icon": "📜",
                "desc": "Grants or queries player experience points and levels.",
                "meta": "/experience <add|set|query> <player> <amount> [points|levels]"
        }
]
};

// Expose backward-compatible aliases for app / generator dropdown layers
MC_DATA.all_items = Object.values(MC_DATA.items).flat();
MC_DATA.execute_items = MC_DATA.all_items;
MC_DATA.execute_blocks = MC_DATA.items.blocks;
MC_DATA.execute_effects = MC_DATA.effects;
MC_DATA.execute_particles = MC_DATA.particles;
MC_DATA.execute_sounds = MC_DATA.sounds;
